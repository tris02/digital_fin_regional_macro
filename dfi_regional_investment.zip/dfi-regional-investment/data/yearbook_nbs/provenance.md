# Provincial statistics from the China Statistical Yearbook

All files come from the online China Statistical Yearbook (CSY) of the National Bureau of Statistics of China,
https://www.stats.gov.cn/sj/ndsj/ (edition year in the path). Each edition reports the preceding year. The tables were
retrieved on 11 and 14 October 2026. Values are in the units printed in the yearbook.

| File | Content | Source tables and transcription |
|---|---|---|
| `fai_total_2010_2017.csv` | Total fixed-asset investment, 100 million yuan, 31 provinces | 2010–2013: CSY2011–CSY2014 tables 5-3 / 10-3, read from the yearbook spreadsheets. 2014–2017: CSY2015–CSY2018 table 10-3, published as images and read by optical character recognition (Tesseract 5, digits only). |
| `gdp_2011_2019.csv` | Regional GDP, 100 million yuan | 2011–2012: CSY2014 table 3-14 (spreadsheet). 2013–2015: CSY2016 table 3-9 (image, OCR). 2016–2019: CSY2017–CSY2020 table 3-9 (image, OCR). |
| `population_2010_2013.csv` | Year-end population, 10,000 persons | CSY2014 table 2-5 (spreadsheet). |
| `population_2013_2019.csv` | Year-end population, 10,000 persons (integers) | CSY2020 table 2-6 (image), transcribed manually. |
| `fai_growth_first_release_2018_2020.csv` | Growth of fixed-asset investment excluding rural households over the preceding year, percent | CSY2019–CSY2021 table 10-5 (image), transcribed manually. |
| `national_gdp_2018.csv` | National GDP for 2018, 100 million yuan: preliminary (900,309) and revised after the Fourth National Economic Census (919,281) | NBS, Bulletin on the Revision of GDP Data in 2018, 22 November 2019, https://www.stats.gov.cn/english/PressRelease/201911/t20191122_1710941.html. |

## Checks of the transcriptions

Checks made during transcription (not reproduced by the code, because they use yearbook rows that the package does not
store):
- Investment, OCR years: the national total minus the sum of the 31 provinces and the unallocated row is 0.1–0.3
  (100 million yuan) in 2014–2017, consistent with rounding to one decimal. Cells for which two OCR passes disagreed
  were resolved against the published image and this identity.
- GDP, OCR years: for 2016–2019 each provincial GDP agrees with the sum of its three reported sectors to within 0.02.
  The 2013–2015 values were read in two passes at different resolutions; the passes agree except in one cell, which a
  further reading resolved.

Checks reproduced by the code:
- `yearbook.py`: deposited investment intensity equals transcribed investment divided by GDP to within 0.0001 in all
  217 province-years of 2011–2017.
- `population.py` and `construction.py`: deposited investment growth equals the growth of yearbook investment per head
  in 2011–2017 and published growth per head in 61 of 62 province-years of 2018–2019. The exception is Hainan 2018
  (Appendix A.3 of the article).

## Limitations

- GDP for 2018 and 2019 comes from editions on different bases, so GDP levels are not compared after 2017.
- Population for 2014–2019 is printed as integers (10,000 persons). Per-capita growth computed from it carries rounding error of up to about 0.3 percentage points in the smallest provinces.
- Values transcribed from images are checked as above but are not an official machine-readable release.
