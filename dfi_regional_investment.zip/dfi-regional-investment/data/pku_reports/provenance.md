# Peking University Digital Financial Inclusion Index: report tables

Source: Institute of Digital Finance, Peking University. Peking University Digital Financial Inclusion Index of China.
Cite Guo et al. (2020) and the report edition used. The reports state no licence; they are public research reports.

| File | Source report | Content |
|---|---|---|
| `provincial_aggregate_2011_2023.csv` | 6th release (2011–2023), report cover dated October 2024, Table 1, https://www.idf.pku.edu.cn/docs/2026-03/064a456918cf4cb789d33d6e49952e5a.pdf | Overall index, 31 provinces, 2011–2023 |
| `provincial_subindex_2011.csv` | 6th release, appendix table 1 | 2011: overall index, coverage breadth, usage depth, digitization |
| `provincial_subindex_2012_2015_partial.csv` | 6th release, appendix tables 2–5 | 2012–2014 for all 31 provinces; 2015 for the first 22 provinces in table order (Beijing to Chongqing) |

Units are index points as printed (not divided by 100). Province names are in Chinese as printed. The values were
transcribed from the report tables and checked as follows.

## Checks

- `code/validate_index.py` compares the deposited dataset (multiplied by 100) with these tables and writes `index_validation.csv`: the overall index agrees in all 309 retained province-years and the components in all 438 values available for comparison.
