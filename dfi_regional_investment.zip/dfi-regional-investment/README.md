# Replication package

**Article:** Digital Financial Inclusion and Regional Investment: Limits of Provincial Evidence

## Overview

The package reproduces every table (Tables 1–5, A.1–A.3 and B.1–B.3), Figure 1 and the numbers quoted in the text of
the article. One command runs the full analysis. A full run takes about 10 minutes on one processor core.

```bash
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python code/replicate.py --out output
```

To check the results against a copy of the article file:

```bash
python code/replicate.py --out output --skip-pipeline --manuscript path/to/article.docx
```

The check confirms three things. Every printed table cell, caption and note appears in the article. Every quoted number
in `output/manuscript_numbers.csv` appears in the text. Every decimal number in the body text can be located in the
computed outputs (`output/manuscript_number_trace.csv` lists the output files for each number). The check allows for
typographic differences (thin spaces, en dashes, spacing around "=").

No result is typed into the code. Table entries, sample sizes, degrees of freedom and every number in the table notes
and in `manuscript_numbers.csv` are computed from the outputs of the analysis modules. Captions and the wording of the
notes follow the article.

## Data availability and provenance

All data are publicly available. No restricted or proprietary data are used.

| Data | Location in package | Source | Licence |
|---|---|---|---|
| Provincial research dataset, 2011–2020 | `data/dataset.xlsx` | Dataset that accompanies Zhan, Li and Wu (2023), Mendeley Data, Version 1, https://doi.org/10.17632/jcvhjhnz4h.1 | CC BY 4.0 |
| Peking University Digital Financial Inclusion Index, provincial values | `data/pku_reports/` | Report tables of the Institute of Digital Finance, Peking University (see `provenance.md`) | No licence stated; cite Guo et al. (2020) and the edition used |
| Provincial statistics (investment, GDP, population, investment growth) | `data/yearbook_nbs/` | China Statistical Yearbook, editions 2011–2021, National Bureau of Statistics of China (see `provenance.md`) | Public statistics; cite the yearbook |

`data/dataset.xlsx` is the copy used in the analysis. Its cell contents are unchanged. Each data folder contains a
`provenance.md` file with the source tables, the transcription method and the checks of each file.

## Computational requirements

- Python 3.11 or later. The archived outputs were produced with Python 3.13 on Linux x86_64 with the package versions in
  `requirements.txt`.
- One processor core. `replicate.py` sets one thread for the numerical libraries and uses fixed random seeds. Other
  library versions or processors can change results at floating-point precision, so outputs should be compared at a
  tolerance.
- Run time: about 10 minutes, most of it in the bootstrap and simulation modules (`jackknife_simulation.py`,
  `observed.py`, `inference_additional.py`).

## Description of programs

`code/replicate.py` runs 24 analysis modules in a fixed order, each in its own Python process, and writes all outputs
to the folder given by `--out`. Later modules read the outputs of earlier ones. `robustness.py` and `pku_names.py` are
libraries imported by other modules. The docstring of each module states what it computes and its outputs.

| Module | Use in the article |
|---|---|
| `analysis.py` | Data cleaning (Section 3.1, Table A.1); shared estimation routines |
| `inference_additional.py` | Wild-cluster bootstrap and CR2 p-values (Table B.2); residual variation of the published index over all windows (Section 5.1); check of the 2020 records (Appendix A.2) |
| `observed.py` | Primary estimates (Table 2); static sensitivity checks (Tables 3 and B.1); placebo simulations (Section 5.2); dynamic and lagged-outcome models (Tables 4 and B.3) |
| `yearbook.py`, `population.py` | Comparison of the dataset with yearbook statistics (Appendix A.1, A.3); outcomes built from yearbook data (Table B.1) |
| `sensitivity.py`, `concentration.py` | Residual exposure variation, approximate MDEs and concentration (Section 5.1, Figure 1) |
| `construction.py`, `construction_checks.py` | 2018–2019 research variables and alternative constructions (Appendix A.3, A.4; Tables A.2 and A.3) |
| `control_subsets.py`, `dynamic_checks.py`, `jackknife_simulation.py` | Control subsets; single-year exclusions and half-panel estimates; split-panel-jackknife simulation (Appendix B.2) |
| `residual_corr.py` | Correlations of the residualised index across adjacent years (Section 5.5) |
| `influence_2011.py`, `influence_2011_provinces.py` | Role of 2011 in the investment-intensity estimate (Section 5.4) |
| `se_recovery.py`, `direct_se.py`, `direct_se_dynamic.py` | Standard errors in Tables 3 and 4 |
| `by_adjust.py`, `twoway_intersection.py` | Benjamini–Yekutieli values and the alternative two-way convention (Table B.2) |
| `reconcile_conference.py` | Step-by-step reconciliation with the conference specification of Guan et al. (2025) (Section 5.6, Table 5) |
| `scaling_check.py` | Check of the exposure scaling (Sections 4.1 and 4.3) |
| `validate_index.py` | Check of the dataset's index values against the published report tables (Section 3.1, Appendix A.1) |
| `figure1.py` | Figure 1 |

## Outputs

| Path in `output/` | Content |
|---|---|
| `manuscript_tables/Table_*.csv` | Tables 1–5, A.1–A.3 and B.1–B.3 as printed, with captions and notes |
| `figure1_mde.png`, `.pdf`, `.eps` | Figure 1 |
| `manuscript_numbers.csv` | Numbers quoted in the text, with computed values and printed form |
| `manuscript_number_trace.csv` | With `--manuscript`: each decimal number in the body text and the outputs that contain it |
| other `*.csv`, `misc_results.json` | Outputs of the analysis modules |

## List of tables and figures

| Exhibit | Program | Output |
|---|---|---|
| Table 1 | `analysis.py`, `replicate.py` | `manuscript_tables/Table_1.csv` |
| Table 2 | `observed.py`, `replicate.py` | `manuscript_tables/Table_2.csv` |
| Table 3 | `observed.py`, `construction.py`, `construction_checks.py`, `direct_se.py`, `se_recovery.py` | `manuscript_tables/Table_3.csv` |
| Table 4 | `construction.py`, `direct_se_dynamic.py`, `observed.py` | `manuscript_tables/Table_4.csv` |
| Table 5 | `reconcile_conference.py` | `manuscript_tables/Table_5.csv` |
| Tables A.1–A.3 | `analysis.py`, `construction.py`, `construction_checks.py` | `manuscript_tables/Table_A1.csv` to `Table_A3.csv` |
| Tables B.1–B.3 | `observed.py`, `inference_additional.py`, `by_adjust.py`, `twoway_intersection.py`, `dynamic_checks.py` | `manuscript_tables/Table_B1.csv` to `Table_B3.csv` |
| Figure 1 | `sensitivity.py`, `figure1.py` | `figure1_mde.png`, `.pdf`, `.eps` |

## References

Guo, F., Wang, J., Wang, F., Kong, T., Zhang, X., & Cheng, Z. (2020). Measuring China's digital financial inclusion: Index compilation and spatial characteristics. *China Economic Quarterly*, 19(4), 1401–1418.

National Bureau of Statistics of China. (2011–2021). *China statistical yearbook* (editions 2011 to 2021). China Statistics Press. https://www.stats.gov.cn/sj/ndsj/

Zhan, M., Li, S., & Wu, Z. (2023). Can digital finance development improve balanced regional investment allocations in developing countries? The evidence from China. *Emerging Markets Review*, 56, Article 101035. https://doi.org/10.1016/j.ememar.2023.101035

## Licence

Code: MIT (`LICENSE`). Data: see the table above and each `provenance.md`.
