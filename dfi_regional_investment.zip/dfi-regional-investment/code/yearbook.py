"""Comparison of the deposited investment variables with China Statistical Yearbook tables.

Usage:  python yearbook.py --data ../data/dataset.xlsx --nbs ../data/yearbook_nbs --out ../output
Run after observed.py.

  1. Investment intensity: deposited value against yearbook total fixed-asset investment divided by regional GDP,
     2011-2017 (Appendix A.1). Levels are not compared after 2017 because the dataset uses a different GDP series.
  2. Primary models re-estimated with outcomes built from yearbook data (Appendix Table B.1): investment intensity
     as yearbook investment over GDP, 2011-2017; and total investment growth, 2011-2019, from yearbook levels for
     2011-2017 and published growth rates for 2018-2019.
Outputs: yearbook_reconstruction.csv (item 1), yearbook_outcomes.csv (item 2).
"""
import argparse, os
import numpy as np
import pandas as pd
from scipy import stats
from analysis import load_and_clean, cleaned_panel, standardise, design, twoway_resid_sd, EXPOSURES, PRIMARY, SPECS
from observed import twoway

TOL = 1e-4


def main():
    ap = argparse.ArgumentParser()
    for k in ('data', 'nbs', 'out'):
        ap.add_argument('--' + k, required=True)
    a = ap.parse_args()
    d, log = load_and_clean(a.data); c = cleaned_panel(d, log)
    F = pd.read_csv(os.path.join(a.nbs, 'fai_total_2010_2017.csv')).rename(columns={'province': 'prov_name', 'fai_total_100m_yuan': 'fai'})
    G = pd.read_csv(os.path.join(a.nbs, 'gdp_2011_2019.csv')).rename(columns={'province': 'prov_name', 'gdp_100m_yuan': 'gdp'})
    R = pd.read_csv(os.path.join(a.nbs, 'fai_growth_first_release_2018_2020.csv')).rename(columns={'province': 'prov_name'})
    F = F.sort_values(['prov_name', 'year'])
    F['g_total'] = F.groupby('prov_name').fai.pct_change()
    m = c.merge(F[['year', 'prov_name', 'fai', 'g_total']], on=['year', 'prov_name'], how='left') \
         .merge(G[['year', 'prov_name', 'gdp']], on=['year', 'prov_name'], how='left') \
         .merge(R[['year', 'prov_name', 'fai_growth_pct']], on=['year', 'prov_name'], how='left')
    m['off_ratio'] = m.fai / m.gdp
    m['first_release'] = m.fai_growth_pct / 100
    m = m.sort_values(['prov_name', 'year'])

    rows = []
    def add(item, year, n, n_match, stat, value, note=''):
        rows.append(dict(item=item, year=year, N=n, n_within_tol=n_match, statistic=stat, value=value, note=note))
    for y in range(2011, 2018):
        g = m[(m.year == y) & m.off_ratio.notna()]; dd = (g.inv_gdp - g.off_ratio).abs()
        add('Investment/GDP = yearbook total FAI / GDP', y, len(g), int((dd < TOL).sum()), 'max abs difference', dd.max())
    pd.DataFrame(rows).to_csv(os.path.join(a.out, 'yearbook_reconstruction.csv'), index=False)

    # 2. primary models with outcomes built from yearbook data
    z = standardise(c, c)
    ratio = {v: twoway_resid_sd(c, v) / c[v].std(ddof=1) for v in EXPOSURES}
    z = z.merge(m[['year', 'prov_name', 'g_total', 'first_release', 'off_ratio']], on=['year', 'prov_name'], how='left')
    z['growth_official'] = np.where(z.year <= 2017, z.g_total, z.first_release)
    samples = [('Investment/GDP, yearbook FAI/GDP', 'off_ratio', (z.year <= 2017)),
               ('Investment growth, official total (2011-2017 levels; 2018-2019 first release)', 'growth_official', (z.year <= 2019))]
    OUT = []
    for lab, y, mask in samples:
        df = z[mask & z[y].notna()].reset_index(drop=True)
        for focal, regs in SPECS:
            X = design(df, regs + PRIMARY); j = list(X.columns).index(focal)
            b, se1, se2, dfy = twoway(df, df[y].values, X, j); k = ratio[focal]; dfp = df.prov_name.nunique() - 1
            OUT.append(dict(outcome=lab, variable=y, exposure=focal, N=len(df), window=f'{df.year.min()}-{df.year.max()}',
                            coef_res=b * k, cr1s_p=2 * stats.t.sf(abs(b / se1), dfp), tw_p=2 * stats.t.sf(abs(b / se2), dfy),
                            cr1s_lo=(b - stats.t.ppf(.975, dfp) * se1) * k, cr1s_hi=(b + stats.t.ppf(.975, dfp) * se1) * k))
    pd.DataFrame(OUT).to_csv(os.path.join(a.out, 'yearbook_outcomes.csv'), index=False)
    print('done')


if __name__ == '__main__':
    main()
