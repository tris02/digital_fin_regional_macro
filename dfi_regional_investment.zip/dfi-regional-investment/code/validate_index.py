"""Check the deposited digital-finance values against the published report tables (article Section 3.1, Appendix A.1).

Usage: python validate_index.py --data ../data/dataset.xlsx --pku ../data/pku_reports --out ../output
Compares the overall index of the cleaned panel (2011-2020) with Table 1 of the 2011-2023 report, and the three
components with the report's appendix tables (2011-2014 for all provinces, 2015 for the provinces printed in table
order). Values agree when the deposited value times 100 equals the printed value to two decimals.
Output: index_validation.csv (one row per comparison: values compared, values that agree, provinces covered by year).
"""
import argparse, os
import pandas as pd
from pku_names import ZH2EN
from analysis import load_and_clean, cleaned_panel

ap = argparse.ArgumentParser()
ap.add_argument('--data', required=True); ap.add_argument('--pku', required=True); ap.add_argument('--out', required=True)
a = ap.parse_args()
d, log = load_and_clean(a.data); c = cleaned_panel(d, log)
P = lambda f: os.path.join(a.pku, f)
rows = []
agg = pd.read_csv(P('provincial_aggregate_2011_2023.csv')); agg['prov_name'] = agg.province.map(ZH2EN)
L = agg.drop(columns='province').melt('prov_name', var_name='year', value_name='published'); L['year'] = L.year.astype(int)
m = c.merge(L, on=['prov_name', 'year'])
ok = ((m.dfi * 100).round(2) - m.published).abs().lt(0.006)
rows.append({'comparison': 'overall index', 'compared': len(m), 'agree': int(ok.sum()), 'provinces_by_year': ''})
s1 = pd.read_csv(P('provincial_subindex_2011.csv')); s1['year'] = 2011
s2 = pd.read_csv(P('provincial_subindex_2012_2015_partial.csv'))
o = pd.concat([s1, s2]); o['prov_name'] = o.province.map(ZH2EN)
m = c.merge(o, on=['prov_name', 'year'])
tot = agree = 0
for dep, pub in [('cov', 'coverage_breadth'), ('use', 'usage_depth'), ('dig', 'digitization')]:
    diff = ((m[dep] * 100).round(2) - m[pub]).abs()
    tot += len(m); agree += int(diff.lt(0.006).sum())
    for _, r in m[diff >= 0.006].iterrows():
        print(f'  differs: {pub} {r.prov_name} {r.year}: deposit {r[dep] * 100:.2f}, published {r[pub]}')
byyear = m.groupby('year').prov_name.nunique()
rows.append({'comparison': 'components', 'compared': tot, 'agree': agree, 'provinces_by_year': '; '.join(f'{y}:{n}' for y, n in byyear.items())})
R = pd.DataFrame(rows); R.to_csv(os.path.join(a.out, 'index_validation.csv'), index=False)
print(R.to_string(index=False))
