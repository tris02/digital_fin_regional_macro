"""Data cleaning and the shared estimation routines (article Section 3.1, Appendix A.1, Table A.1).

The module holds the variable map, the documented cleaning (load_and_clean,
cleaned_panel), standardisation, the fixed-effects design, the CR1S estimator, the restricted wild-cluster bootstrap,
the baseline residual SD and the Benjamini-Hochberg adjustment, which the other modules import. Run as a script, it
writes the cleaned panel (cleaned_panel.csv) and misc_results.json, which records the cleaning log, the residual-SD
scale factors and the number of rows in which the three investment components sum to investment intensity.
Usage:  python analysis.py --data ../data/dataset.xlsx --out ../output
"""
import argparse, json, os, re
import numpy as np
import pandas as pd
from scipy import stats

# ----------------------------------------------------------------------------
# Variable map (deposit label -> short name)
# ----------------------------------------------------------------------------
RENAME = {
    'investment to GDP': 'inv_gdp',
    'per capita investment growth rate': 'inv_growth',
    'investment return rate': 'inv_return',
    'digital finance development': 'dfi',
    'coverage breadth': 'cov',
    'usage depth': 'use',
    'digitization level': 'dig',
    'the saving to GDP ratio': 'saving',
    'the quality of the credit market': 'credit',
    'labor cost': 'labor',
    'regional income size': 'size',
    'regional income volatility': 'vol',
    'regional fiscal support': 'fiscal',
    'sectoral structure': 'sectoral',
    'public investment': 'pub_inv',
    'domestic private investment': 'priv_inv',
    'foreign investment': 'for_inv',
    'financial depth': 'fin_depth',
    'financial width': 'fin_width',
    'financial structure': 'fin_struct',
    'Regional capital flows': 'cap_flows',
}
OUTCOMES = ['inv_gdp', 'inv_growth']
EXPOSURES = ['dfi', 'cov', 'use', 'dig']
COMPONENTS = ['cov', 'use', 'dig']
PRIMARY = ['labor', 'size', 'vol', 'fiscal']
EXPANDED = PRIMARY + ['inv_return', 'saving', 'credit']
SPECS = [('dfi', ['dfi']), ('cov', COMPONENTS), ('use', COMPONENTS), ('dig', COMPONENTS)]
B = 1999

# NBS four-region classification (National Bureau of Statistics)
REGION = {
    'Beijing': 'Eastern', 'Tianjin': 'Eastern', 'Hebei': 'Eastern', 'Shanghai': 'Eastern',
    'Jiangsu': 'Eastern', 'Zhejiang': 'Eastern', 'Fujian': 'Eastern', 'Shandong': 'Eastern',
    'Guangdong': 'Eastern', 'Hainan': 'Eastern',
    'Shanxi': 'Central', 'Anhui': 'Central', 'Jiangxi': 'Central', 'Henan': 'Central',
    'Hubei': 'Central', 'Hunan': 'Central',
    'Inner Mongolia': 'Western', 'Guangxi': 'Western', 'Chongqing': 'Western',
    'Sichuan': 'Western', 'Guizhou': 'Western', 'Yunnan': 'Western', 'Tibet': 'Western',
    'Shaanxi': 'Western', 'Gansu': 'Western', 'Qinghai': 'Western', 'Ningxia': 'Western',
    'Xinjiang': 'Western',
    'Liaoning': 'Northeast', 'Jilin': 'Northeast', 'Heilongjiang': 'Northeast',
}


# ----------------------------------------------------------------------------
# 1. Cleaning (Table 1)
# ----------------------------------------------------------------------------
def load_and_clean(path):
    raw = pd.read_excel(path)
    d = raw.rename(columns=RENAME).copy()
    log = {'raw_rows': int(len(d))}

    # (a) Malformed fiscal value: keep the leading numeric value
    bad = d['fiscal'].apply(lambda v: isinstance(v, str))
    log['malformed_fiscal'] = d.loc[bad, ['prov_name', 'year', 'fiscal']].astype(str).values.tolist()
    d['fiscal'] = d['fiscal'].apply(
        lambda v: float(re.match(r'[-+]?\d*\.?\d+(?:[eE][-+]?\d+)?', v).group(0))
        if isinstance(v, str) else float(v))

    # (b) Mixed 2020 record: two 'Hubei' rows, no 'Hebei'. The mixed row is the one
    # whose DFI values are closer to Hebei 2019 than to Hubei 2019.
    dup = d[(d.year == 2020) & (d.prov_name == 'Hubei')]
    assert len(dup) == 2 and not ((d.year == 2020) & (d.prov_name == 'Hebei')).any()
    he19 = d[(d.year == 2019) & (d.prov_name == 'Hebei')][EXPOSURES].values[0]
    hu19 = d[(d.year == 2019) & (d.prov_name == 'Hubei')][EXPOSURES].values[0]
    dist = {i: (np.abs(r[EXPOSURES].values - he19).sum(), np.abs(r[EXPOSURES].values - hu19).sum())
            for i, r in dup.iterrows()}
    mixed = [i for i, (dhe, dhu) in dist.items() if dhe < dhu]
    assert len(mixed) == 1
    log['mixed_row_removed'] = {'excel_row': int(mixed[0]) + 2,
                                'dfi': float(d.loc[mixed[0], 'dfi'])}
    log['_mixed_index'] = int(mixed[0])
    alt_index = [i for i in dup.index if i != mixed[0]][0]
    log['_alt_index'] = int(alt_index)
    return d, log


def cleaned_panel(d, log, drop='mixed'):
    idx = log['_mixed_index'] if drop == 'mixed' else log['_alt_index']
    c = d.drop(index=idx).copy()
    if drop != 'mixed':          # counterfactual: relabel nothing, keep mixed row as 'Hubei'
        pass
    c = c.sort_values(['prov_name', 'year']).reset_index(drop=True)
    return c


# ----------------------------------------------------------------------------
# 2. Estimation helpers
# ----------------------------------------------------------------------------
def standardise(c, ref):
    """Standardise exposures and continuous covariates with ref-sample mean/SD."""
    z = c.copy()
    cols = EXPOSURES + EXPANDED
    for v in cols:
        z[v] = (c[v] - ref[v].mean()) / ref[v].std(ddof=1)
    return z


def dummies(s, prefix):
    return pd.get_dummies(s, prefix=prefix, drop_first=True, dtype=float)


def design(df, regs, fe=('prov', 'year'), trends=False, const=True):
    parts = [df[regs].astype(float)]
    if 'prov' in fe:
        parts.append(dummies(df['prov_name'], 'p'))
    if 'year' in fe:
        parts.append(dummies(df['year'], 'y'))
    if trends:
        t = (df['year'] - df['year'].min()).astype(float)
        P = pd.get_dummies(df['prov_name'], dtype=float)
        parts.append(P.mul(t, axis=0).add_prefix('tr_'))
    X = pd.concat(parts, axis=1)
    if const:
        X.insert(0, 'const', 1.0)
    # drop exactly collinear columns (keeps rank-defining set, regressors first)
    X = drop_collinear(X, keep=regs)
    return X


def drop_collinear(X, keep):
    cols, M = [], None
    order = ['const'] * ('const' in X) + list(keep) + [c for c in X.columns if c not in keep and c != 'const']
    for c in order:
        cand = X[c].values[:, None] if M is None else np.column_stack([M, X[c].values])
        if np.linalg.matrix_rank(cand, tol=1e-9) == cand.shape[1]:
            cols.append(c); M = cand
        elif c in keep:
            raise ValueError(f'focal regressor {c} is collinear')
    return X[cols]


def ols_cr1s(y, X, groups):
    y = np.asarray(y, float); Xv = np.asarray(X, float)
    N, r = Xv.shape
    XtXi = np.linalg.inv(Xv.T @ Xv)
    b = XtXi @ Xv.T @ y
    u = y - Xv @ b
    g = pd.factorize(np.asarray(groups))[0]
    G = g.max() + 1
    S = np.zeros((G, r))
    np.add.at(S, g, Xv * u[:, None])
    meat = S.T @ S
    V = XtXi @ meat @ XtXi * (G / (G - 1)) * ((N - 1) / (N - r))
    se = np.sqrt(np.diag(V))
    t = b / se
    p = 2 * stats.t.sf(np.abs(t), G - 1)
    return dict(b=b, se=se, t=t, p=p, u=u, N=N, G=G, r=r, cols=list(X.columns), XtXi=XtXi)


def wild_restricted(y, X, groups, focal, seed, B=B):
    """Restricted (null-imposed) wild-cluster bootstrap-t, Rademacher weights at the
    province level; provinces in sorted-name order; p = (1+m)/(B+1)."""
    y = np.asarray(y, float); Xv = np.asarray(X, float)
    j = list(X.columns).index(focal)
    full = ols_cr1s(y, X, groups)
    t0 = full['t'][j]
    Xr = np.delete(Xv, j, axis=1)
    br = np.linalg.lstsq(Xr, y, rcond=None)[0]
    yhat_r, ur = Xr @ br, y - Xr @ br
    gnames = np.asarray(groups)
    order = sorted(pd.unique(gnames))
    gidx = np.array([order.index(v) for v in gnames])
    G = len(order); N, r = Xv.shape
    rng = np.random.default_rng(seed)
    W = rng.choice(np.array([-1.0, 1.0]), size=(B, G))
    XtXi = full['XtXi']; H = XtXi @ Xv.T
    c = (G / (G - 1)) * ((N - 1) / (N - r))
    m = 0
    for bdraw in range(B):
        ys = yhat_r + ur * W[bdraw, gidx]
        bs = H @ ys
        us = ys - Xv @ bs
        S = np.zeros((G, r)); np.add.at(S, gidx, Xv * us[:, None])
        a = XtXi[j] @ S.T            # j-th row of XtXi X'u_g for each cluster
        se = np.sqrt(c * (a @ a))
        if abs(bs[j] / se) >= abs(t0):
            m += 1
    return (1 + m) / (B + 1)


def twoway_resid_sd(df, v):
    X = design(df, [], const=True)
    e = df[v].values - X.values @ np.linalg.lstsq(X.values, df[v].values, rcond=None)[0]
    return np.std(e, ddof=1)


def bh(p):
    p = np.asarray(p); n = len(p); o = np.argsort(p)
    q = np.empty(n); prev = 1.0
    for k in range(n - 1, -1, -1):
        i = o[k]; prev = min(prev, p[i] * n / (k + 1)); q[i] = prev
    return q


# ----------------------------------------------------------------------------
# 3. Main
# ----------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--data', required=True)
    ap.add_argument('--out', required=True)
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    R = {}
    d, log = load_and_clean(a.data)
    c = cleaned_panel(d, log)
    log['clean_rows'] = int(len(c))
    keep = ['year', 'prov_name'] + [v for v in RENAME.values() if v in c.columns]
    c[keep].to_csv(os.path.join(a.out, 'cleaned_panel.csv'), index=False)
    R['scale_ratio'] = {v: twoway_resid_sd(c, v) / c[v].std(ddof=1) for v in EXPOSURES}
    R['cleaning_log'] = {k: v for k, v in log.items() if not k.startswith('_')}
    json.dump(R, open(os.path.join(a.out, 'misc_results.json'), 'w'), indent=2, default=float)


if __name__ == '__main__':
    main()
