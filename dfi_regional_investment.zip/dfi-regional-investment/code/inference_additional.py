"""Additional inference for the primary estimates and the outcome-free residual-variation map
(article Sections 5.1, 5.2 and Appendix Table B.2).

Outputs:
  sample_2011_2019.csv       restricted wild-cluster bootstrap-t (B=1,999, Rademacher weights, province clusters)
                                      and CR2 Bell-McCaffrey p-values for the eight primary estimates, 2011-2019
  residual_variation_windows.csv residual-to-raw SD ratio of the published index after province and year effects,
                                      every window of five or more years in 2011-2023 (45 windows)
Usage:  python inference_additional.py --data ../data/dataset.xlsx --pku ../data/pku_reports/provincial_aggregate_2011_2023.csv --out ../output
"""
import argparse, os
import numpy as np
import pandas as pd
from scipy import stats
from analysis import (load_and_clean, cleaned_panel, standardise, design, ols_cr1s, twoway_resid_sd,
                      wild_restricted, bh, OUTCOMES, EXPOSURES, PRIMARY, SPECS)
from robustness import cr2_bm
from pku_names import ZH2EN

SEED = 20261201
TZ = stats.t.ppf(0.975, 30) + stats.norm.ppf(0.80)


def fe_resid(df, v):
    X = design(df, [], const=True).values
    return df[v].values - X @ np.linalg.lstsq(X, df[v].values, rcond=None)[0]


def main():
    ap = argparse.ArgumentParser()
    for k in ('data', 'pku', 'out'):
        ap.add_argument('--' + k, required=True)
    ap.add_argument('--B', type=int, default=1999)
    a = ap.parse_args()
    d, log = load_and_clean(a.data); c = cleaned_panel(d, log)
    ratio = {v: twoway_resid_sd(c, v) / c[v].std(ddof=1) for v in EXPOSURES}

    # 2011-2019 sample: wild-cluster bootstrap and CR2 p-values
    b = c[c.year <= 2019].copy(); zb = standardise(b, c)
    rows, seed = [], SEED
    for y in OUTCOMES:
        for focal, regs in SPECS:
            X = design(zb, regs + PRIMARY); r = ols_cr1s(zb[y], X, zb.prov_name); j = r['cols'].index(focal)
            wp = wild_restricted(zb[y], X, zb.prov_name, focal, seed, a.B)
            p2 = cr2_bm(zb, y, regs, PRIMARY, focal)[3]
            rows.append(dict(outcome=y, exposure=focal, N=r['N'], coef_res=r['b'][j] * ratio[focal],
                             cr1s_p=r['p'][j], wild_p=wp, cr2_p=p2, wild_B=a.B))
            seed += 1
    T15 = pd.DataFrame(rows); T15['bh_q'] = bh(T15.cr1s_p)
    T15.to_csv(os.path.join(a.out, 'sample_2011_2019.csv'), index=False)

    # residual-to-raw SD ratio of the published index, every window of five or more years
    o2 = pd.read_csv(a.pku); o2['prov_name'] = o2.province.map(ZH2EN)
    L = o2.drop(columns='province').melt('prov_name', var_name='year', value_name='dfi'); L['year'] = L.year.astype(int)
    MAP = []
    for s_ in range(2011, 2020):
        for e_ in range(s_ + 4, 2024):
            w = L[(L.year >= s_) & (L.year <= e_)]
            rr = np.std(fe_resid(w.assign(prov_name=w.prov_name), 'dfi'), ddof=1) / w.dfi.std(ddof=1)
            n = len(w)
            MAP.append(dict(start=s_, end=e_, N=n, ratio=rr, exposure_factor=1 / (np.sqrt(n) * rr),
                            mde_per_unit_Dkappa=TZ / (np.sqrt(n) * rr)))
    pd.DataFrame(MAP).to_csv(os.path.join(a.out, 'residual_variation_windows.csv'), index=False)


if __name__ == '__main__':
    main()
