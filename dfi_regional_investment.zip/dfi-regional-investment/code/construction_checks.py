"""Alternative construction of two GDP-based controls (article Appendix A.4, Tables 3, A3 and B1; output alternative_controls.csv).

In 2018-2019 the dataset's regional income size and fiscal support use the
same GDP series as investment intensity. Both are rebuilt on the GDP basis used for 2011-2017: size is divided by r_i, the
ratio of the province's 2018 GDP in the dataset to its CSY2019 value, and multiplied by the ratio of the revised to the preliminary national 2018 GDP
(919,281/900,309, from yearbook_nbs/national_gdp_2018.csv); fiscal support is
multiplied by r_i; the 2018 ratios are also applied in 2019. The primary model is then re-estimated. The file also
records the correlation of the 2018 change in each control with r_i (fiscal support: with 1/r_i).
Usage:  python construction_checks.py --data ../data/dataset.xlsx --nbs ../data/yearbook_nbs --out ../output
"""
import argparse, os
import numpy as np
import pandas as pd
from scipy import stats
from analysis import load_and_clean, cleaned_panel, standardise, twoway_resid_sd, OUTCOMES, EXPOSURES
from construction import Problem, regimes, load_official, load_population, load_national_gdp_2018


def main():
    ap = argparse.ArgumentParser()
    for k in ('data', 'nbs', 'out'):
        ap.add_argument('--' + k, required=True)
    a = ap.parse_args()
    dd, log = load_and_clean(a.data); c = cleaned_panel(dd, log)
    ratio = {v: twoway_resid_sd(c, v) / c[v].std(ddof=1) for v in EXPOSURES}
    F, G, R = load_official(a.nbs); N = load_population(a.nbs)
    nat_pre, nat_rev = load_national_gdp_2018(a.nbs)
    rr = regimes(c, F, G, R, N, nat_rev).set_index('province')
    focal_list = [('dfi', ['dfi']), ('dig', ['cov', 'use', 'dig'])]
    cc = c.copy()
    rmap = rr.revision_ratio_2018
    post = cc.year.isin([2018, 2019])
    rv = cc.prov_name.map(rmap)
    cc_size_fix = cc.copy()
    cc_size_fix.loc[post, 'size'] = cc.loc[post, 'size'] / rv[post] * (nat_rev / nat_pre)
    cc_both = cc_size_fix.copy(); cc_both.loc[post, 'fiscal'] = cc.loc[post, 'fiscal'] * rv[post]
    jumps = dict(size_corr_with_revision=np.corrcoef((cc[cc.year == 2018].set_index('prov_name')['size'] / cc[cc.year == 2017].set_index('prov_name')['size']).reindex(rmap.index), rmap)[0, 1],
                 fiscal_corr_with_inverse_revision=np.corrcoef((cc[cc.year == 2018].set_index('prov_name').fiscal / cc[cc.year == 2017].set_index('prov_name').fiscal).reindex(rmap.index), 1 / rmap)[0, 1])
    CT = []
    for lab, cdat in (('deposit controls', cc), ('size on pre-census vintage', cc_size_fix), ('size and fiscal support on pre-census vintage', cc_both)):
        zz = standardise(cdat, c); w9 = zz[zz.year <= 2019].reset_index(drop=True)
        for y in OUTCOMES:
            for focal, regs in focal_list:
                P = Problem(w9, y, focal, regs, ratio[focal]); k = ratio[focal]
                Ya = w9[y].values.astype(float); s1a, s2a = P.se(Ya)
                CT.append(dict(controls=lab, outcome=y, exposure=focal,
                               theta_deposit=P.theta(Ya) * k, deposit_p=2 * stats.t.sf(abs(P.theta(Ya) / s1a), 30),
                               deposit_tw_p=2 * stats.t.sf(abs(P.theta(Ya) / s2a), P.dfy), **jumps))
    pd.DataFrame(CT).to_csv(os.path.join(a.out, 'alternative_controls.csv'), index=False)


if __name__ == '__main__':
    main()
