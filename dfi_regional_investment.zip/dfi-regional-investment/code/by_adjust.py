"""Benjamini–Yekutieli adjustment of the eight primary p-values under each inference procedure.
The BY step-up procedure controls the false discovery rate under arbitrary dependence among the tests
(Benjamini & Yekutieli, 2001); the adjusted values equal the BH adjusted values times c(m) = sum_{i<=m} 1/i, capped at one.
Usage: python by_adjust.py --out ../output   (after observed.py)."""
import argparse, os
import numpy as np
import pandas as pd


def adjust(p, by=False):
    p = np.asarray(p, float); m = len(p); o = np.argsort(p)
    cm = np.sum(1.0 / np.arange(1, m + 1)) if by else 1.0
    q = np.empty(m); run = 1.0
    for rank in range(m, 0, -1):
        i = o[rank - 1]; run = min(run, cm * m * p[i] / rank); q[i] = min(run, 1.0)
    return q


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--out', required=True); a = ap.parse_args()
    P = pd.read_csv(os.path.join(a.out, 'primary_estimates.csv')); P = P[P['sample'] == '2011-2019'].reset_index(drop=True)
    out = P[['outcome', 'exposure', 'cr1s_p', 'tw_p', 'bh_q_cr1s', 'bh_q_tw']].copy()
    out['bh_check_cr1s'] = adjust(P.cr1s_p); out['bh_check_tw'] = adjust(P.tw_p)
    out['by_q_cr1s'] = adjust(P.cr1s_p, by=True); out['by_q_tw'] = adjust(P.tw_p, by=True)
    gap = max(np.abs(out.bh_check_cr1s - out.bh_q_cr1s).max(), np.abs(out.bh_check_tw - out.bh_q_tw).max())
    assert gap < 1e-12, gap
    out.to_csv(os.path.join(a.out, 'by_qvalues.csv'), index=False)
    print(f'BH reproduced (max gap {gap:.1e}); c(8) = {np.sum(1/np.arange(1,9)):.4f}')
    print(out[['outcome', 'exposure', 'bh_q_cr1s', 'by_q_cr1s', 'by_q_tw']].round(4).to_string())


if __name__ == '__main__':
    main()
