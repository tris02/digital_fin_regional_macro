"""Correlations of the residualised index across adjacent years.

Usage:  python residual_corr.py --data ../data/dataset.xlsx --out ../output
Sample and construction as in the lead-current-lag models of construction.py (2012-2019, observed 2020 index as the lead).
Each of the lead, current value and lag of the exposure is regressed on province and year effects, with and without the
four primary controls; the output reports the correlations of the residuals (lead with current, current with lag).
Output: residual_index_corr.csv.
"""
import argparse, os
import numpy as np
import pandas as pd
from analysis import load_and_clean, cleaned_panel, standardise, design, EXPOSURES, PRIMARY


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--data', required=True); ap.add_argument('--out', required=True)
    a = ap.parse_args()
    dd, log = load_and_clean(a.data); c = cleaned_panel(dd, log); z = standardise(c, c)
    zz = z.sort_values(['prov_name', 'year']).copy()
    for ex in EXPOSURES:
        zz[ex + '_lead'] = zz.groupby('prov_name')[ex].shift(-1)
        zz[ex + '_lag'] = zz.groupby('prov_name')[ex].shift(1)
    w = zz[(zz.year >= 2012) & (zz.year <= 2019)].dropna(subset=[e_ + s_ for e_ in EXPOSURES for s_ in ('_lead', '_lag')]).reset_index(drop=True)
    rows = []
    for ex in EXPOSURES:
        for lab, regs in (('fixed effects only', []), ('fixed effects and primary controls', PRIMARY)):
            X = design(w, regs).values.astype(float)
            res = {}
            for v in (ex + '_lead', ex, ex + '_lag'):
                y = w[v].values.astype(float); b, *_ = np.linalg.lstsq(X, y, rcond=None); res[v] = y - X @ b
            rows.append(dict(exposure=ex, conditioning=lab, N=len(w),
                             corr_lead_current=np.corrcoef(res[ex + '_lead'], res[ex])[0, 1],
                             corr_current_lag=np.corrcoef(res[ex], res[ex + '_lag'])[0, 1]))
    pd.DataFrame(rows).to_csv(os.path.join(a.out, 'residual_index_corr.csv'), index=False)


if __name__ == '__main__':
    main()
