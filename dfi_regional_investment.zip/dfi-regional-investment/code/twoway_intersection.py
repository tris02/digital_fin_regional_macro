"""Two-way-clustered inference for the eight primary estimates (2011-2019) under two finite-sample conventions for the
province-year intersection term of the Cameron-Gelbach-Miller variance V = V_province + V_year - V_intersection.
Reported convention (observed.py): small-sample factors G/(G-1)(N-1)/(N-K) on V_province and V_year, none on
V_intersection. Alternative: the same factor applied to V_intersection, with G = N single-observation clusters.
Reference distribution t(8) in both cases. The script reproduces the stored two-way p-values for the reported convention,
then reports the alternative p-values and their Benjamini-Hochberg values.
Usage: python twoway_intersection.py --data ../data/dataset.xlsx --out ../output   (after observed.py, by_adjust.py)."""
import argparse, os
import numpy as np
import pandas as pd
from scipy import stats
from analysis import load_and_clean, cleaned_panel, standardise, design, twoway_resid_sd, OUTCOMES, EXPOSURES, PRIMARY, SPECS
from robustness import add_fe_columns
from observed import cl_parts
from by_adjust import adjust


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--data', required=True); ap.add_argument('--out', required=True)
    a = ap.parse_args()
    d, log = load_and_clean(a.data); c = add_fe_columns(cleaned_panel(d, log)); z = standardise(c, c)
    ratio = {v: twoway_resid_sd(c, v) / c[v].std(ddof=1) for v in EXPOSURES}
    df = z[z.year <= 2019].reset_index(drop=True)
    P = pd.read_csv(os.path.join(a.out, 'primary_estimates.csv')); P = P[P['sample'] == '2011-2019']
    rows = []
    for y in OUTCOMES:
        for focal, regs in SPECS:
            X = design(df, regs + PRIMARY); Xv = np.asarray(X, float); N, K = Xv.shape; j = list(X.columns).index(focal)
            XtXi = np.linalg.inv(Xv.T @ Xv); b = XtXi @ Xv.T @ df[y].values; u = df[y].values - Xv @ b
            gp = pd.factorize(df.prov_name)[0]; gy = pd.factorize(df.year)[0]; gpy = pd.factorize(df.prov_name + df.year.astype(str))[0]
            vp, G = cl_parts(Xv, u, gp, XtXi, j); vp *= G / (G - 1) * (N - 1) / (N - K)
            vy, Gy = cl_parts(Xv, u, gy, XtXi, j); vy *= Gy / (Gy - 1) * (N - 1) / (N - K)
            vpy, Gpy = cl_parts(Xv, u, gpy, XtXi, j)
            v_rep = vp + vy - vpy; v_alt = vp + vy - vpy * Gpy / (Gpy - 1) * (N - 1) / (N - K)
            k = ratio[focal]; dfy = Gy - 1
            p_rep = 2 * stats.t.sf(abs(b[j] / np.sqrt(v_rep)), dfy); p_alt = 2 * stats.t.sf(abs(b[j] / np.sqrt(v_alt)), dfy)
            s = P[(P.outcome == y) & (P.exposure == focal)].iloc[0]
            assert abs(p_rep - s.tw_p) < 1e-10 and abs(b[j] * k - s.coef_res) < 1e-12
            rows.append(dict(outcome=y, exposure=focal, coef_res=b[j] * k, tw_se_reported=np.sqrt(v_rep) * k, tw_p_reported=p_rep,
                             tw_se_alternative=np.sqrt(v_alt) * k, tw_p_alternative=p_alt))
    R = pd.DataFrame(rows)
    R['bh_q_reported'] = adjust(R.tw_p_reported); R['bh_q_alternative'] = adjust(R.tw_p_alternative)
    R.to_csv(os.path.join(a.out, 'twoway_intersection_results.csv'), index=False)
    print(R.round(4).to_string())


if __name__ == '__main__':
    main()
