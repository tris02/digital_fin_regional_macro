"""Population check of the deposited investment growth series.

Usage:  python population.py --data ../data/dataset.xlsx --nbs ../data/yearbook_nbs --out ../output

Official year-end population: 2010-2013 from CSY2014 table 2-5 (.xls) and 2014-2019 from CSY2020 table 2-6 (image,
integers, transcribed visually). For each province-year the deposited investment growth is compared with
  2011-2017: per-capita growth of yearbook total fixed-asset investment, (F_t/N_t)/(F_t-1/N_t-1) - 1;
  2018-2019: first-release growth converted to per-capita terms, (1 + FR_t)/(N_t/N_t-1) - 1.
Also reported: the population growth implied by the deposit in 2011-2017, (1 + total growth)/(1 + deposit growth) - 1,
against official population growth, and its mean.
Output: population_check.csv (one row per province-year).
"""
import argparse, os
import numpy as np
import pandas as pd
from analysis import load_and_clean, cleaned_panel
from construction import load_official, load_population


def main():
    ap = argparse.ArgumentParser()
    for k in ('data', 'nbs', 'out'):
        ap.add_argument('--' + k, required=True)
    a = ap.parse_args()
    dd, log = load_and_clean(a.data); c = cleaned_panel(dd, log)
    F, G, R = load_official(a.nbs); N = load_population(a.nbs).reindex(F.index)
    AG = c.pivot(index='prov_name', columns='year', values='inv_growth').reindex(F.index)
    pc = (F / N).pct_change(axis=1); tg = F.pct_change(axis=1); ng = N.pct_change(axis=1)
    mean_impl = ((1 + tg.loc[:, 2011:2017]) / (1 + AG.loc[:, 2011:2017]) - 1).mean(axis=1)
    rows = []
    for p in F.index:
        for t in range(2011, 2020):
            if t <= 2017:
                off = pc.loc[p, t]; basis = 'yearbook level per capita'
                impl = (1 + tg.loc[p, t]) / (1 + AG.loc[p, t]) - 1
            else:
                off = (1 + R.loc[p, t]) / (1 + ng.loc[p, t]) - 1; basis = 'first release per capita'
                impl = np.nan
            rows.append(dict(province=p, year=t, basis=basis, deposit_growth=AG.loc[p, t], official_per_capita_growth=off,
                             difference_points=100 * (AG.loc[p, t] - off), pop_growth_official=ng.loc[p, t],
                             pop_growth_implied_by_deposit=impl, pop_growth_extrapolated=mean_impl[p]))
    pd.DataFrame(rows).to_csv(os.path.join(a.out, 'population_check.csv'), index=False)


if __name__ == '__main__':
    main()
