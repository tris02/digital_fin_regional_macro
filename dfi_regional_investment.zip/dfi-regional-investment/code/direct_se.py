"""Direct standard errors for the static sensitivity rows, the lagged-index and lagged-outcome rows and the
2011-deletion rows (article Tables 3 and 4), re-estimated with the same designs as
observed.py and dynamic_checks.py. The script stores the CR1S standard error from the estimation routine,
checks that each re-estimated coefficient and p-value equals the stored one, and compares the direct standard
error with the recovered one in recovered_se.csv.
Usage: python direct_se.py --data ../data/dataset.xlsx --out ../output   (after observed.py, dynamic_checks.py, se_recovery.py)."""
import argparse, os
import numpy as np
import pandas as pd
from analysis import (load_and_clean, cleaned_panel, standardise, design, ols_cr1s, twoway_resid_sd,
                      OUTCOMES, EXPOSURES, PRIMARY, EXPANDED, SPECS)
from robustness import add_fe_columns, design_fe


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--data', required=True); ap.add_argument('--out', required=True)
    a = ap.parse_args()
    d, log = load_and_clean(a.data); c = add_fe_columns(cleaned_panel(d, log))
    z = standardise(c, c)
    for v in ('region', 'ry', 'pp'):
        z[v] = c[v]
    ratio = {v: twoway_resid_sd(c, v) / c[v].std(ddof=1) for v in EXPOSURES}
    b9 = z[z.year <= 2019].reset_index(drop=True); cb = c[c.year <= 2019].reset_index(drop=True)
    R = []
    for y in OUTCOMES:
        for focal, regs in SPECS:
            k = ratio[focal]

            def put(name, df, yy, X, fcol=focal):
                r = ols_cr1s(df[yy], X, df.prov_name); jj = r['cols'].index(fcol)
                R.append(dict(outcome=y, exposure=focal, row=name, N=r['N'], coef_res=r['b'][jj] * k,
                              se_res=r['se'][jj] * k, cr1s_p=r['p'][jj]))
            put('fixed effects only', b9, y, design(b9, regs))
            put('expanded covariates', b9, y, design(b9, regs + EXPANDED))
            W = cb.copy()
            for v in [y] + EXPOSURES + PRIMARY:
                lo, hi = cb[v].quantile([0.01, 0.99]); W[v] = cb[v].clip(lo, hi)
            Wz = standardise(W, c); Wz[y] = W[y]
            put('winsorised 1/99', Wz, y, design(Wz, regs + PRIMARY))
            put('region-by-year effects', b9, y, design_fe(b9, regs + PRIMARY, ['prov_name', 'ry']))
            put('province post-2017 shifts', b9, y, design_fe(b9, regs + PRIMARY, ['prov_name', 'year', 'pp']))
            w = np.sqrt(cb['size'].values); X = design(b9, regs + PRIMARY)
            bw = b9.copy(); bw['_yw'] = b9[y].values * w
            put('GDP-weighted', bw, '_yw', X.mul(w, axis=0))
            L = b9.sort_values(['prov_name', 'year']).copy()
            for v in regs + PRIMARY:
                L[v] = L.groupby('prov_name')[v].shift(1)
            L = L[L.groupby('prov_name')['year'].shift(1) == L['year'] - 1].dropna(subset=regs + PRIMARY)
            put('lagged exposure', L, y, design(L, regs + PRIMARY))
            F = b9.sort_values(['prov_name', 'year']).copy()
            for v in [y] + regs + PRIMARY:
                F[v] = F.groupby('prov_name')[v].diff()
            F = F[F.groupby('prov_name')['year'].diff() == 1].dropna(subset=[y] + regs + PRIMARY)
            put('first differences', F, y, design(F, regs + PRIMARY, fe=('year',)))
            put('province trends', b9, y, design(b9, regs + PRIMARY, trends=True))
            D = b9.sort_values(['prov_name', 'year']).copy()
            D['ylag'] = D.groupby('prov_name')[y].shift(1)
            D = D[D.groupby('prov_name')['year'].shift(1) == D['year'] - 1].dropna(subset=['ylag']).reset_index(drop=True)
            put('lagged outcome, uncorrected', D, y, design(D, regs + PRIMARY + ['ylag']))
            if focal in ('dfi', 'dig'):   # the stored leave-one-year output covers these exposures
                s_ = b9[b9.year != 2011]
                put('drop 2011', s_, y, design(s_, regs + PRIMARY))
    R = pd.DataFrame(R)
    # check against the stored outputs
    SEC = pd.read_csv(os.path.join(a.out, 'estimates_secondary_2011_2019.csv'))
    REM = pd.read_csv(os.path.join(a.out, 'estimates_remaining_2011_2019.csv'))
    LOY = pd.read_csv(os.path.join(a.out, 'leave_one_year.csv'))
    REC = pd.read_csv(os.path.join(a.out, 'recovered_se.csv'))
    gb, gp, gs = [], [], []
    for i, r in R.iterrows():
        if r.row == 'lagged outcome, uncorrected':
            s = REM[(REM.outcome == r.outcome) & (REM.exposure == r.exposure)].iloc[0]; b0, p0 = s.ldv_coef_res, s.ldv_p
            rec = REC[(REC.source == 'estimates_remaining_2011_2019') & (REC.outcome == r.outcome) & (REC.exposure == r.exposure)]
        elif r.row == 'drop 2011':
            s = LOY[(LOY.outcome == r.outcome) & (LOY.exposure == r.exposure) & (LOY.year_dropped == 2011)].iloc[0]; b0, p0 = s.coef_res, s.cr1s_p
            rec = REC[(REC.source == 'leave_one_year') & (REC.outcome == r.outcome) & (REC.exposure == r.exposure) & (REC.row == 'drop 2011')]
        else:
            s = SEC[(SEC.outcome == r.outcome) & (SEC.exposure == r.exposure) & (SEC.check == r.row)].iloc[0]; b0, p0 = s.coef_res, s.p
            rec = REC[(REC.source == 'estimates_secondary_2011_2019') & (REC.outcome == r.outcome) & (REC.exposure == r.exposure) & (REC.row == r.row)]
        gb.append(abs(r.coef_res - b0)); gp.append(abs(r.cr1s_p - p0)); gs.append(abs(r.se_res - rec.iloc[0].se_res))
    R['abs_diff_coef_vs_stored'] = gb; R['abs_diff_p_vs_stored'] = gp; R['abs_diff_se_vs_recovered'] = gs
    R.to_csv(os.path.join(a.out, 'direct_se_rows.csv'), index=False)
    print(f'rows {len(R)}; max |coef diff| {max(gb):.1e}; max |p diff| {max(gp):.1e}; max |SE direct - recovered| {max(gs):.1e}')


if __name__ == '__main__':
    main()
