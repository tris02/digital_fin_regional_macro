"""Observed-years analyses, 2011-2019 (article Tables 2-4, B1 and B3; Sections 5.2-5.5).

Outputs:
  primary_estimates.csv          primary estimates: CR1S and two-way-clustered intervals and p-values, BH q-values,
                                        wild-bootstrap and CR2 p-values (from sample_2011_2019.csv), for 2011-2019
                                        and the deposited 2011-2020 panel
  estimates_secondary_2011_2019.csv    static sensitivity checks re-estimated on 2011-2019
  placebo_size_power_2011_2019.csv   placebo size and power under four exposure dependence processes (residual AR(1)
                                        0.4 or 0.8, with or without regionally correlated shocks), province-clustered and
                                        two-way tests
  estimates_remaining_2011_2019.csv    leave-one-year-out ranges, lagged-outcome models and the split-panel jackknife
                                        (halves 2012-2015 / 2016-2019; province-cluster bootstrap, B=499)
Usage:  python observed.py --data ../data/dataset.xlsx --out ../output   (after inference_additional.py)
"""
import argparse, os
import numpy as np
import pandas as pd
from scipy import stats
from analysis import (load_and_clean, cleaned_panel, standardise, design, ols_cr1s, twoway_resid_sd, bh,
                      OUTCOMES, EXPOSURES, PRIMARY, EXPANDED, SPECS, REGION)
from robustness import add_fe_columns, design_fe, fast_beta

SEED = 20261601
SPJ_B = 499          # province-cluster bootstrap replications for the split-panel jackknife
T30 = stats.t.ppf(0.975, 30); TZ = T30 + stats.norm.ppf(0.80)


def cl_parts(Xv, u, g, XtXi, j):
    G = g.max() + 1; S = np.zeros((G, Xv.shape[1])); np.add.at(S, g, Xv * u[:, None])
    a = XtXi[j] @ S.T; return float(a @ a), G


def twoway(df, yv, X, j):
    Xv = np.asarray(X, float); N, K = Xv.shape; XtXi = np.linalg.inv(Xv.T @ Xv)
    b = XtXi @ Xv.T @ yv; u = yv - Xv @ b
    gp = pd.factorize(df.prov_name)[0]; gy = pd.factorize(df.year)[0]
    gpy = pd.factorize(df.prov_name + df.year.astype(str))[0]
    vp, G = cl_parts(Xv, u, gp, XtXi, j); vp *= G / (G - 1) * (N - 1) / (N - K)
    vy, Gy = cl_parts(Xv, u, gy, XtXi, j); vy *= Gy / (Gy - 1) * (N - 1) / (N - K)
    vpy, _ = cl_parts(Xv, u, gpy, XtXi, j)
    return b[j], np.sqrt(vp), np.sqrt(max(vp + vy - vpy, 1e-300)), Gy - 1


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--data', required=True); ap.add_argument('--out', required=True)
    ap.add_argument('--S', type=int, default=1000)
    a = ap.parse_args()
    d, log = load_and_clean(a.data); c = add_fe_columns(cleaned_panel(d, log))
    z = standardise(c, c)
    for v in ('region', 'ry', 'pp'):
        z[v] = c[v]
    ratio = {v: twoway_resid_sd(c, v) / c[v].std(ddof=1) for v in EXPOSURES}
    S = {'2011-2019': z[z.year <= 2019].reset_index(drop=True), '2011-2020': z.reset_index(drop=True)}
    t15 = pd.read_csv(os.path.join(a.out, 'sample_2011_2019.csv'))

    # 1. primary table
    P = []
    for lab, df in S.items():
        for y in OUTCOMES:
            for focal, regs in SPECS:
                X = design(df, regs + PRIMARY); j = list(X.columns).index(focal)
                b, se1, se2, dfy = twoway(df, df[y].values, X, j); k = ratio[focal]
                row = dict(sample=lab, outcome=y, exposure=focal, coef_res=b * k,
                           cr1s_lo=(b - T30 * se1) * k, cr1s_hi=(b + T30 * se1) * k, cr1s_p=2 * stats.t.sf(abs(b / se1), 30),
                           tw_lo=(b - stats.t.ppf(.975, dfy) * se2) * k, tw_hi=(b + stats.t.ppf(.975, dfy) * se2) * k,
                           tw_p=2 * stats.t.sf(abs(b / se2), dfy), tw_df=dfy, mde_res=TZ * se1 * k,
                           mde_outcome_sd=TZ * se1 / df[y].std(ddof=1))
                if lab == '2011-2019':
                    r15 = t15[(t15.outcome == y) & (t15.exposure == focal)].iloc[0]
                    row.update(wild_p=r15.wild_p, cr2_p=r15.cr2_p)
                P.append(row)
    P = pd.DataFrame(P)
    for lab in S:
        m = P['sample'] == lab
        P.loc[m, 'bh_q_cr1s'] = bh(P.loc[m, 'cr1s_p'].values); P.loc[m, 'bh_q_tw'] = bh(P.loc[m, 'tw_p'].values)
    P.to_csv(os.path.join(a.out, 'primary_estimates.csv'), index=False)

    # 3. secondary analyses on 2011-2019
    b9 = S['2011-2019']; cb = c[c.year <= 2019].reset_index(drop=True)
    SEC = []
    for y in OUTCOMES:
        for focal, regs in SPECS:
            k = ratio[focal]

            def put(name, df, yy, X, fcol=focal):
                r = ols_cr1s(df[yy], X, df.prov_name); jj = r['cols'].index(fcol)
                SEC.append(dict(outcome=y, exposure=focal, check=name, coef_res=r['b'][jj] * k, p=r['p'][jj], N=r['N']))
            put('fixed effects only', b9, y, design(b9, regs))
            put('expanded covariates', b9, y, design(b9, regs + EXPANDED))
            W = cb.copy()
            for v in [y] + EXPOSURES + PRIMARY:
                lo, hi = cb[v].quantile([0.01, 0.99]); W[v] = cb[v].clip(lo, hi)
            Wz = standardise(W, c); Wz[y] = W[y]
            put('winsorised 1/99', Wz, y, design(Wz, regs + PRIMARY))
            put('region-by-year effects', b9, y, design_fe(b9, regs + PRIMARY, ['prov_name', 'ry']))
            put('province post-2017 shifts', b9, y, design_fe(b9, regs + PRIMARY, ['prov_name', 'year', 'pp']))
            w = np.sqrt(cb['size'].values); X = design(b9, regs + PRIMARY)
            bw = b9.copy(); bw['_yw'] = b9[y].values * w
            put('GDP-weighted', bw, '_yw', X.mul(w, axis=0))
            L = b9.sort_values(['prov_name', 'year']).copy()
            nxt = L.groupby('prov_name')['year'].shift(-1) == L['year'] + 1
            for v in regs:
                L[v + '_lead'] = L.groupby('prov_name')[v].shift(-1)
            L = L[nxt]
            put('lead placebo', L, y, design(L, regs + [v + '_lead' for v in regs] + PRIMARY), fcol=focal + '_lead')
            L = b9.sort_values(['prov_name', 'year']).copy()
            for v in regs + PRIMARY:
                L[v] = L.groupby('prov_name')[v].shift(1)
            L = L[L.groupby('prov_name')['year'].shift(1) == L['year'] - 1].dropna(subset=regs + PRIMARY)
            put('lagged exposure', L, y, design(L, regs + PRIMARY))
            F = b9.sort_values(['prov_name', 'year']).copy()
            for v in [y] + regs + PRIMARY:
                F[v] = F.groupby('prov_name')[v].diff()
            F = F[F.groupby('prov_name')['year'].diff() == 1].dropna(subset=[y] + regs + PRIMARY)
            put('first differences', F, y, design(F, regs + PRIMARY, fe=('year',)))
            put('province trends', b9, y, design(b9, regs + PRIMARY, trends=True))
            base = ols_cr1s(b9[y], design(b9, regs + PRIMARY), b9.prov_name); jb = base['cols'].index(focal)
            lo = []
            for pv in sorted(b9.prov_name.unique()):
                s_ = b9[b9.prov_name != pv]; r = ols_cr1s(s_[y], design(s_, regs + PRIMARY), s_.prov_name)
                jj = r['cols'].index(focal); lo.append((r['b'][jj] * k, r['p'][jj]))
            lo = np.array(lo)
            SEC.append(dict(outcome=y, exposure=focal, check='leave-one-province-out', coef_res=np.nan, p=np.nan,
                            N=len(b9) - 9, lopo_min=lo[:, 0].min(), lopo_max=lo[:, 0].max(),
                            lopo_sign_changes=int(np.sum(np.sign(lo[:, 0]) != np.sign(base['b'][jb]))),
                            lopo_p05=int(np.sum(lo[:, 1] < 0.05))))
    pd.DataFrame(SEC).to_csv(os.path.join(a.out, 'estimates_secondary_2011_2019.csv'), index=False)

    # 4. placebo size and power on 2011-2019 under four dependence processes
    x = z['dfi'].values; t = (z.year - 2011).values.astype(float)
    Pd = pd.get_dummies(z.prov_name, dtype=float); Yd = pd.get_dummies(z.year, drop_first=True, dtype=float)
    Xd = np.hstack([Pd.values, Pd.values * t[:, None], Yd.values]); cf = np.linalg.lstsq(Xd, x, rcond=None)[0]
    npv = Pd.shape[1]; al, ga = cf[:npv], cf[npv:2 * npv]; yfx = Xd[:, 2 * npv:] @ cf[2 * npv:]
    sig = float(np.std(x - Xd @ cf, ddof=1))
    provs = list(Pd.columns); pidx = np.array([provs.index(p) for p in z.prov_name])
    regs_ = sorted(set(REGION.values())); ridx = np.array([regs_.index(REGION[p]) for p in z.prov_name])
    yrs = z.year.values; yl = sorted(set(yrs)); yidx = np.array([yl.index(v) for v in yrs])
    keep = yrs <= 2019
    PW = []
    for name, rho, sreg in [('independent, AR(1) 0.4', 0.4, 0.0), ('regional shocks, AR(1) 0.4', 0.4, 0.5),
                            ('independent, AR(1) 0.8', 0.8, 0.0), ('regional shocks, AR(1) 0.8', 0.8, 0.5)]:
        rng = np.random.default_rng(SEED + int(10 * rho) + int(10 * sreg))
        rec = {y: [] for y in OUTCOMES}
        Xb = design(b9, ['dfi'] + PRIMARY); jx = list(Xb.columns).index('dfi')
        for s in range(a.S):
            kk = rng.integers(0, npv, npv); u = np.zeros(len(z))
            for pi in range(npv):
                rr = np.where(pidx == pi)[0]; rr = rr[np.argsort(yrs[rr])]
                v = np.empty(len(rr)); v[0] = rng.normal()
                for jj in range(1, len(rr)):
                    v[jj] = rho * v[jj - 1] + np.sqrt(1 - rho ** 2) * rng.normal()
                u[rr] = v
            if sreg > 0:
                g = rng.normal(0, 1, (len(regs_), len(yl))); u = np.sqrt(1 - sreg) * u + np.sqrt(sreg) * g[ridx, yidx]
            xs = al[kk][pidx] + ga[kk][pidx] * t + yfx + sig * u
            xs = ((xs - xs.mean()) / xs.std(ddof=1))[keep]
            X = Xb.copy(); X['dfi'] = xs
            for y in OUTCOMES:
                b, se1, se2, dfy = twoway(b9, b9[y].values, X, jx); rec[y].append((b, se1, se2, dfy))
        for y in OUTCOMES:
            r = np.array(rec[y]); sdy = c[y].std(ddof=1)
            for th in (0.0, 0.5, 1.0):
                bb = r[:, 0] + th * sdy
                PW.append(dict(process=name, outcome=y, theta=th, S=a.S,
                               reject_cr1s=np.mean(np.abs(bb / r[:, 1]) > T30),
                               reject_twoway=np.mean(np.abs(bb / r[:, 2]) > stats.t.ppf(.975, r[:, 3]))))
    pd.DataFrame(PW).to_csv(os.path.join(a.out, 'placebo_size_power_2011_2019.csv'), index=False)

    # 7. remaining checks on 2011-2019
    RM = []
    rng = np.random.default_rng(SEED + 19)
    for y in OUTCOMES:
        for focal, regs in SPECS:
            k = ratio[focal]
            X = design(b9, regs + PRIMARY); r = ols_cr1s(b9[y], X, b9.prov_name); j = r['cols'].index(focal)
            row = dict(outcome=y, exposure=focal, coef_res=r['b'][j] * k, cr1s_p=r['p'][j])
            ly = []
            for yr in range(2011, 2020):
                s_ = b9[b9.year != yr]; rr = ols_cr1s(s_[y], design(s_, regs + PRIMARY), s_.prov_name)
                jj = rr['cols'].index(focal); ly.append((rr['b'][jj] * k, rr['p'][jj]))
            ly = np.array(ly)
            row.update(loyo_min=ly[:, 0].min(), loyo_max=ly[:, 0].max(), loyo_median_p=np.median(ly[:, 1]),
                       loyo_p05=int(np.sum(ly[:, 1] < 0.05)))
            D = b9.sort_values(['prov_name', 'year']).copy()
            D['ylag'] = D.groupby('prov_name')[y].shift(1)
            D = D[D.groupby('prov_name')['year'].shift(1) == D['year'] - 1].dropna(subset=['ylag']).reset_index(drop=True)
            rr = ols_cr1s(D[y], design(D, regs + PRIMARY + ['ylag']), D.prov_name); jj = rr['cols'].index(focal)
            row.update(ldv_N=rr['N'], ldv_coef_res=rr['b'][jj] * k, ldv_p=rr['p'][jj],
                       ldv_ylag=rr['b'][rr['cols'].index('ylag')])
            D['pid'] = D['prov_name']; R_ = regs + PRIMARY + ['ylag']

            def spj9(Dd):
                full = fast_beta(Dd, y, R_)
                return full, 2 * full - 0.5 * (fast_beta(Dd[Dd.year <= 2015], y, R_) + fast_beta(Dd[Dd.year > 2015], y, R_))
            full, bc = spj9(D); jf, jl = R_.index(focal), R_.index('ylag')
            pv_ = D['prov_name'].unique(); dr = []
            for _ in range(SPJ_B):
                pick = rng.choice(pv_, size=len(pv_), replace=True)
                Db = pd.concat([D[D.prov_name == p_].assign(pid=f'{p_}#{i_}') for i_, p_ in enumerate(pick)])
                dr.append(spj9(Db)[1])
            dr = np.array(dr)
            row.update(spj_coef_res=bc[jf] * k, spj_boot_se_res=dr[:, jf].std(ddof=1) * k,
                       spj_ylag=bc[jl], spj_ylag_boot_se=dr[:, jl].std(ddof=1), spj_boot_B=SPJ_B)
            RM.append(row)
    pd.DataFrame(RM).to_csv(os.path.join(a.out, 'estimates_remaining_2011_2019.csv'), index=False)


if __name__ == '__main__':
    main()
