"""Province composition of the 2011 terms in the year-level decomposition (overall index, investment intensity and
investment growth, 2011-2019). With d residualised on the full 2011-2019 sample exactly as in influence_2011.py, the
script reports for each province its 2011 contribution to the denominator sum d'd (share of all 2011 d'd) and to the
numerator sum d'y (share of all 2011 d'y; shares can be negative or exceed one), and the coefficient obtained when only
that province's 2011 term is removed from both sums with d held fixed.
Usage: python influence_2011_provinces.py --data ../data/dataset.xlsx --out ../output   (after influence_2011.py)."""
import argparse, os
import numpy as np
import pandas as pd
from analysis import load_and_clean, cleaned_panel, standardise, twoway_resid_sd
from influence_2011 import theta


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--data', required=True); ap.add_argument('--out', required=True)
    a = ap.parse_args()
    d0, log = load_and_clean(a.data); c = cleaned_panel(d0, log); z = standardise(c, c)
    k = twoway_resid_sd(c, 'dfi') / c['dfi'].std(ddof=1)
    b9 = z[z.year <= 2019].reset_index(drop=True)
    YI = pd.read_csv(os.path.join(a.out, 'year_influence.csv'))
    rows = []
    for y in ('inv_gdp', 'inv_growth'):
        d, th = theta(b9, y)
        assert abs(th * k - YI[YI.outcome == y].theta_full_res.iloc[0]) < 1e-12
        Y = b9[y].values; m = (b9.year == 2011).values
        N = d * Y; S = d * d
        N11, S11 = N[m].sum(), S[m].sum()
        for i in np.where(m)[0]:
            rows.append(dict(outcome=y, province=b9.prov_name.iloc[i], d_2011=d[i], y_2011=Y[i],
                             share_of_2011_S=S[i] / S11, share_of_2011_N=N[i] / N11,
                             theta_without_this_term_res=(N.sum() - N[i]) / (S.sum() - S[i]) * k))
    out = pd.DataFrame(rows).sort_values(['outcome', 'share_of_2011_N'], ascending=[True, False])
    out.to_csv(os.path.join(a.out, 'influence_2011_provinces_terms.csv'), index=False)
    for y in ('inv_gdp', 'inv_growth'):
        o = out[out.outcome == y]
        print(y, 'top-3 share of 2011 N:', round(o.share_of_2011_N.head(3).sum(), 3), list(o.province.head(3)),
              'top-3 share of 2011 S:', round(o.sort_values('share_of_2011_S', ascending=False).share_of_2011_S.head(3).sum(), 3))


if __name__ == '__main__':
    main()
