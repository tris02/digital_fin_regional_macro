"""Standard errors for Tables 3 and 4 of the article.
The stored outputs keep each CR1S coefficient b and its two-sided p-value from a t(30) reference (31 province clusters).
The CR1S standard error is recovered as |b| / t30^{-1}(1 - p/2), the exact inverse of that t-test.
The script first checks the formula on the eight primary estimates, whose 95 percent intervals are stored.
Usage: python se_recovery.py --out ../output   (after observed.py, construction.py, dynamic_checks.py, control_subsets.py)."""
import argparse, os
import pandas as pd
from scipy import stats


def se30(b, p):
    return abs(b) / stats.t.ppf(1 - p / 2, 30)


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--out', required=True); a = ap.parse_args()
    O = lambda f: pd.read_csv(os.path.join(a.out, f))
    P = O('primary_estimates.csv'); P = P[P['sample'] == '2011-2019']
    se_ci = (P.cr1s_hi - P.cr1s_lo) / (2 * stats.t.ppf(0.975, 30))
    se_p = [se30(b, p) for b, p in zip(P.coef_res, P.cr1s_p)]
    gap = max(abs(x - y) for x, y in zip(se_ci, se_p))
    assert gap < 1e-10, gap
    R = []
    add = lambda src, y, e, lab, b, p: R.append(dict(source=src, outcome=y, exposure=e, row=lab, coef_res=b, cr1s_p=p, se_res=se30(b, p)))
    for _, r in O('estimates_secondary_2011_2019.csv').dropna(subset=['coef_res']).iterrows():
        add('estimates_secondary_2011_2019', r.outcome, r.exposure, r.check, r.coef_res, r.p)
    for _, r in O('leave_one_year.csv').iterrows():
        add('leave_one_year', r.outcome, r.exposure, f'drop {int(r.year_dropped)}', r.coef_res, r.cr1s_p)
    for _, r in O('construction_bounds.csv').drop_duplicates(['outcome', 'exposure']).iterrows():
        add('construction_bounds', r.outcome, r.exposure, 'alternative 2018-2019 outcomes', r.theta_anchor, r.anchor_cr1s_p)
    for _, r in O('alternative_controls.csv').iterrows():
        add('alternative_controls', r.outcome, r.exposure, r.controls, r.theta_deposit, r.deposit_p)
    for _, r in O('control_subsets_estimates.csv').iterrows():
        add('control_subsets_estimates', r.outcome, r.exposure, r.controls, r.coef_res, r.cr1s_p)
    for _, r in O('yearbook_outcomes.csv').iterrows():
        add('yearbook_outcomes', r.variable, r.exposure, 'outcome variant', r.coef_res, r.cr1s_p)
    for _, r in O('estimates_remaining_2011_2019.csv').iterrows():
        add('estimates_remaining_2011_2019', r.outcome, r.exposure, 'lagged outcome, uncorrected', r.ldv_coef_res, r.ldv_p)
    for _, r in O('dynamics.csv').iterrows():
        for col, pc in (('lead', 'lead_p'), ('current', 'current_p'), ('lag', 'lag_p'), ('change', 'change_p')):
            if pd.notna(r[col]) and pd.notna(r[pc]):
                add('dynamics', r.outcome, r.exposure, f'{r.model}: {col}', r[col], r[pc])
    pd.DataFrame(R).to_csv(os.path.join(a.out, 'recovered_se.csv'), index=False)
    print(f'formula check on primary estimates: max gap {gap:.1e}; rows written: {len(R)}')


if __name__ == '__main__':
    main()
