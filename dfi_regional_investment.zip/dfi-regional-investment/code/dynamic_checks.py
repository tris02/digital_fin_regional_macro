"""Assumption checks for the dynamic and year-sensitivity results (2011-2019).
  1. Lagged-outcome model: full-sample estimate and the two half-panel estimates (2012-2015, 2016-2019) that enter the
     split-panel jackknife, for the index coefficient and the lagged-outcome coefficient.
  2. Leave-one-year-out refits of the primary model, year by year (province clustering).
Usage: python dynamic_checks.py --data ../data/dataset.xlsx --out ../output   (any time after analysis.py)"""
import argparse, os
import pandas as pd
from analysis import load_and_clean, cleaned_panel, standardise, design, ols_cr1s, twoway_resid_sd, OUTCOMES, EXPOSURES, PRIMARY, SPECS
from robustness import add_fe_columns, fast_beta


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--data', required=True); ap.add_argument('--out', required=True)
    a = ap.parse_args()
    d, log = load_and_clean(a.data); c = add_fe_columns(cleaned_panel(d, log))
    z = standardise(c, c)
    ratio = {v: twoway_resid_sd(c, v) / c[v].std(ddof=1) for v in EXPOSURES}
    b9 = z[z.year <= 2019].reset_index(drop=True)
    H, Y = [], []
    for y in OUTCOMES:
        for focal, regs in SPECS:
            if focal not in ('dfi', 'dig'):
                continue
            k = ratio[focal]
            D = b9.sort_values(['prov_name', 'year']).copy()
            D['ylag'] = D.groupby('prov_name')[y].shift(1)
            D = D[D.groupby('prov_name')['year'].shift(1) == D['year'] - 1].dropna(subset=['ylag']).reset_index(drop=True)
            D['pid'] = D['prov_name']; R_ = regs + PRIMARY + ['ylag']
            jf, jl = R_.index(focal), R_.index('ylag')
            full = fast_beta(D, y, R_); h1 = fast_beta(D[D.year <= 2015], y, R_); h2 = fast_beta(D[D.year > 2015], y, R_)
            spj = 2 * full - 0.5 * (h1 + h2)
            H.append(dict(outcome=y, exposure=focal, N=len(D), N_half1=int((D.year <= 2015).sum()), N_half2=int((D.year > 2015).sum()),
                          index_full=full[jf] * k, index_half1=h1[jf] * k, index_half2=h2[jf] * k, index_spj=spj[jf] * k,
                          ylag_full=full[jl], ylag_half1=h1[jl], ylag_half2=h2[jl], ylag_spj=spj[jl]))
            for yr in range(2011, 2020):
                s_ = b9[b9.year != yr]; rr = ols_cr1s(s_[y], design(s_, regs + PRIMARY), s_.prov_name)
                jj = rr['cols'].index(focal)
                Y.append(dict(outcome=y, exposure=focal, year_dropped=yr, N=rr['N'], coef_res=rr['b'][jj] * k, cr1s_p=rr['p'][jj]))
    pd.DataFrame(H).to_csv(os.path.join(a.out, 'spj_halves.csv'), index=False)
    pd.DataFrame(Y).to_csv(os.path.join(a.out, 'leave_one_year.csv'), index=False)


if __name__ == '__main__':
    main()
