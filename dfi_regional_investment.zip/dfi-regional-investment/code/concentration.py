"""Concentration of the residualised exposure variation (article Section 5.1; output exposure_concentration.csv).

It computes exposure_concentration.csv. For each sample, exposure
and residualisation, it reports the province shares of the residualised exposure sum of squares, their inverse
Herfindahl index, the top-three and largest shares, and the residual-to-raw SD ratio; the score rows report the same
concentration for the province-level score contributions.
Usage:  python concentration.py --data ../data/dataset.xlsx --out ../output   (after analysis.py)
"""
import argparse, os
import numpy as np
import pandas as pd
from analysis import load_and_clean, cleaned_panel, standardise, design, ols_cr1s, OUTCOMES, PRIMARY, SPECS


def partial_out(df, v, regs):
    X = design(df, regs, const=True).values
    return df[v].values - X @ np.linalg.lstsq(X, df[v].values, rcond=None)[0]


def inv_herf(share):
    share = np.asarray(share, float); share = share / share.sum()
    return 1.0 / np.sum(share ** 2)


def main():
    ap = argparse.ArgumentParser()
    for k in ('data', 'out'):
        ap.add_argument('--' + k, required=True)
    a = ap.parse_args()
    d, log = load_and_clean(a.data); c = cleaned_panel(d, log); z = standardise(c, c)
    samples = {'2011-2020': z.reset_index(drop=True), '2011-2019': z[z.year <= 2019].reset_index(drop=True)}
    CON = []
    for lab, df in samples.items():
        P = df.prov_name.values; provs = sorted(set(P))
        for focal, regs in SPECS:
            others = [r for r in regs if r != focal]
            for kind, rr in (('two-way only', []), ('after controls', others + PRIMARY)):
                dt = partial_out(df, focal, rr)
                ss = pd.Series(dt ** 2).groupby(P).sum().reindex(provs)
                sh = (ss / ss.sum()).sort_values(ascending=False)
                CON.append(dict(sample=lab, exposure=focal, residualisation=kind, inv_herfindahl=inv_herf(sh),
                                top3_share=sh.iloc[:3].sum(), top_province=sh.index[0], top_share=sh.iloc[0],
                                sd_ratio=np.std(dt, ddof=1) / df[focal].std(ddof=1)))
            for y in OUTCOMES:
                X = design(df, regs + PRIMARY); r = ols_cr1s(df[y], X, df.prov_name)
                dt = partial_out(df, focal, others + PRIMARY)
                psi = pd.Series(dt * r['u']).groupby(P).sum().reindex(provs)
                p2 = psi ** 2 / np.sum(psi ** 2)
                CON.append(dict(sample=lab, exposure=focal, residualisation='score, ' + y,
                                inv_herfindahl=1 / np.sum(p2 ** 2),
                                top3_share=np.sort(p2.values)[::-1][:3].sum(), top_province=p2.idxmax(), top_share=p2.max(),
                                sd_ratio=np.nan))
    pd.DataFrame(CON).to_csv(os.path.join(a.out, 'exposure_concentration.csv'), index=False)


if __name__ == '__main__':
    main()
