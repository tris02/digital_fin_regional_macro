#!/usr/bin/env python3
"""replicate.py: reproduce the tables, Figure 1 and the numbers quoted in the text of the article
"Digital Financial Inclusion and Regional Investment: Limits of Provincial Evidence".

The script runs the analysis modules in this folder in order, each in its own Python process, and writes their outputs
to --out. It then rebuilds the eleven article tables (Tables 1-5, A.1-A.3 and B.1-B.3) and Figure 1, and recomputes the
numbers quoted in the text. With --manuscript it checks that every table cell and quoted number appears in the
article file.

All inputs are read from the data/ folder (see README.md). Table entries, sample sizes and quoted numbers are computed
from the outputs of the analysis modules. Captions are the printed table titles. Notes reproduce the printed notes; their sample sizes, degrees of freedom and
estimates are computed from the outputs.

Usage (from the package root)
  python code/replicate.py --out output                                full run (about 10 minutes, one thread)
  python code/replicate.py --out output --skip-pipeline                tables, Figure 1 and quoted numbers only
  python code/replicate.py --out output --skip-pipeline --manuscript article.docx   also check the article file
  python code/replicate.py --out output --start-at sensitivity         resume a run at one module
"""
import argparse, os, re, subprocess, sys, time
import numpy as np
import pandas as pd

CODE_DIR = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(CODE_DIR)


# >>> PIPELINE
def pipeline(root):
    D = os.path.join(root, 'data', 'dataset.xlsx'); NBS = os.path.join(root, 'data', 'yearbook_nbs')
    PKU = os.path.join(root, 'data', 'pku_reports'); PKU23 = os.path.join(PKU, 'provincial_aggregate_2011_2023.csv')
    return [  # (module, arguments); the order matters because later modules read earlier outputs
        ('analysis', ['--data', D]), ('inference_additional', ['--data', D, '--pku', PKU23]), ('observed', ['--data', D]),
        ('yearbook', ['--data', D, '--nbs', NBS]), ('sensitivity', ['--data', D]), ('control_subsets', ['--data', D]),
        ('dynamic_checks', ['--data', D]), ('jackknife_simulation', ['--data', D]), ('construction', ['--data', D, '--nbs', NBS]),
        ('construction_checks', ['--data', D, '--nbs', NBS]), ('population', ['--data', D, '--nbs', NBS]),
        ('residual_corr', ['--data', D]), ('concentration', ['--data', D]), ('validate_index', ['--data', D, '--pku', PKU]),
        ('influence_2011', ['--data', D]), ('se_recovery', []), ('direct_se', ['--data', D]), ('by_adjust', []),
        ('direct_se_dynamic', ['--data', D, '--nbs', NBS]), ('influence_2011_provinces', ['--data', D]),
        ('reconcile_conference', ['--data', D]), ('twoway_intersection', ['--data', D]), ('scaling_check', ['--data', D]),
        ('figure1', [])]


NO_OUT = set()
ENV = dict(os.environ, OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1', SOURCE_DATE_EPOCH='1760745600')


def run_pipeline(root, out, start_at=None):
    steps = pipeline(root)
    if start_at:
        k = [n for n, _ in steps].index(start_at.removesuffix('.py')); steps = steps[k:]
    for name, args in steps:
        t0 = time.time()
        r = run_module(name, args, out)
        print(f'{name + ".py":30s} rc={r.returncode} {time.time() - t0:6.0f}s', flush=True)
        if r.returncode != 0:
            print(r.stdout[-2000:], r.stderr[-2000:]); sys.exit(f'{name}.py failed')
# <<< PIPELINE


def run_module(name, args, out):
    cmd = [sys.executable, os.path.join(CODE_DIR, name + '.py')] + args + ([] if name in NO_OUT else ['--out', out])
    return subprocess.run(cmd, cwd=out, env=ENV, capture_output=True, text=True)


# >>> MANUSCRIPT LAYER


def build_tables(O, raw=False):
    """Rebuild every manuscript table from the outputs in folder O. Returns {label: (caption, header_rows, rows, note)} and
    Figure 1's caption; with raw=True also the full table definitions (column widths and alignment), for typesetting."""
    O = os.path.join(O, '')
    f3 = lambda v: ('−' if v < -0.0005 else '') + f'{abs(v):.3f}'
    f2 = lambda v: ('−' if v < -0.005 else '') + f'{abs(v):.2f}'
    fp = lambda p: '<0.001' if p < 0.001 else f'{p:.3f}'
    pb = lambda p: f'[p{fp(p)}]' if p < 0.001 else f'[p={fp(p)}]'
    OL = {'inv_gdp': 'Investment intensity', 'inv_growth': 'Investment growth'}
    EL = {'dfi': 'Overall DFI', 'cov': 'Coverage breadth', 'use': 'Usage depth', 'dig': 'Digitization'}
    from scipy import stats as _st
    T30_, T8_ = _st.t.ppf(0.975, 30), _st.t.ppf(0.975, 8)
    def se30(b, p):
        """CR1S standard error implied by a coefficient and its two-sided t(30) p-value (exact inverse)."""
        return abs(b) / _st.t.ppf(1 - p / 2, 30)
    pbr = lambda p: f'[{fp(p)}]'
    DSE = pd.read_csv(O + 'direct_se_rows.csv')
    def dse(y, e, row):
        r = DSE[(DSE.outcome == y) & (DSE.exposure == e) & (DSE.row == row)].iloc[0]
        return f'{f3(r.coef_res)}\n({f3(r.se_res)})\n{pbr(r.cr1s_p)}'
    cse = lambda b, p: f'{f3(b)}\n({f3(se30(b, p))})\n{pbr(p)}'
    DSE2 = pd.read_csv(O + 'direct_se_dynamic_rows.csv')
    def dse2(y, e, row):
        r = DSE2[(DSE2.outcome == y) & (DSE2.exposure == e) & (DSE2.row == row)].iloc[0]
        return f'{f3(r.coef_res)}\n({f3(r.se_res)})\n{pbr(r.cr1s_p)}'

    # ---------------- Table 1: summary statistics, 2011-2019
    CPA = pd.read_csv(O + 'cleaned_panel.csv')                     # all cleaned records, 2011-2020
    CP = CPA[CPA.year <= 2019]                                       # primary sample, 2011-2019
    NOBS, NPROV, NYR = len(CP), CP.prov_name.nunique(), CP.year.nunique()
    assert NOBS == NPROV * NYR                                       # balanced primary panel
    n_above = int((CP.inv_gdp > 1).sum())
    f3s = lambda v: ('−' if v < -0.0005 else '') + f'{abs(v):.3f}'
    f4s = lambda v: ('−' if v < -0.00005 else '') + f'{abs(v):.4f}'
    def srow(c, lab_, f=None):
        f = f or f3s
        return [lab_, str(int(CP[c].notna().sum())), f(CP[c].mean()), f(CP[c].std()), f(CP[c].min()), f(CP[c].max())]
    T1 = [('PANEL', 'Panel A. Outcomes'), srow('inv_gdp', 'Investment intensity (FAI/GDP)'), srow('inv_growth', 'Investment growth (nominal, per capita)'),
          ('PANEL', 'Panel B. Digital financial inclusion (index/100)'), srow('dfi', 'Overall index'), srow('cov', 'Coverage breadth'),
          srow('use', 'Usage depth'), srow('dig', 'Digitization'),
          ('PANEL', 'Panel C. Primary controls'), srow('labor', 'Labour cost (log average wage)'), srow('size', 'Regional income size (share of national GDP)'),
          srow('vol', 'Regional income volatility', f4s), srow('fiscal', 'Fiscal support (expenditure/GDP)')]
    TABLE1 = ('Table 1. ', 'Summary Statistics, 2011–2019',
              ['Variable', 'N', 'Mean', 'SD', 'Min', 'Max'], T1, [3561, 800, 1250, 1250, 1250, 1250],
              '')

    # ---------------- Table 2: primary estimates, journal layout
    P4 = pd.read_csv(O + 'primary_estimates.csv'); P4 = P4[P4['sample'] == '2011-2019']
    def p4(y, e):
        return P4[(P4.outcome == y) & (P4.exposure == e)].iloc[0]
    cols2 = [('inv_gdp', 'dfi'), ('inv_gdp', 'comp'), ('inv_growth', 'dfi'), ('inv_growth', 'comp')]
    def _r(y, e): return p4(y, e)
    def cell2(y, spec, e, proc):
        if (spec == 'dfi') != (e == 'dfi'):
            return ''
        r = _r(y, e)
        sp_ = (r.cr1s_hi - r.cr1s_lo) / (2 * T30_); st_ = (r.tw_hi - r.tw_lo) / (2 * T8_)
        if proc == 'prov':
            return f'{f3(r.coef_res)}\n({f3(sp_)})\n[{fp(r.cr1s_p)}]'
        return f'({f3(st_)})\n[{fp(r.tw_p)}]'
    T2 = []
    for e in ('dfi', 'cov', 'use', 'dig'):
        if e == 'cov':
            T2.append(('PANEL', 'Components entered jointly'))
        lab = 'Overall index' if e == 'dfi' else EL[e]
        T2.append([lab + ': province-clustered'] + [cell2(y, sp, e, 'prov') for y, sp in cols2])
        T2.append(['   two-way-clustered'] + [cell2(y, sp, e, 'tw') for y, sp in cols2])
    T2.append(['Observations'] + [str(NOBS)] * 4)
    T2.append(['Provinces; years'] + [f'{NPROV}; {NYR}'] * 4)
    T2.append(['Primary controls'] + ['Yes'] * 4)
    T2.append(['Province and year fixed effects'] + ['Yes'] * 4)
    TABLE2 = ('Table 2. ', 'Primary Estimates, 2011–2019',
              [['', ('Investment intensity', 2), ('Investment growth', 2)],
               ['', '(1)', '(2)', '(3)', '(4)']],
              T2, [2961, 1600, 1600, 1600, 1600],
              '')

    # ---------------- Table 3: static robustness map, journal layout
    SEC = pd.read_csv(O + 'estimates_secondary_2011_2019.csv'); REM = pd.read_csv(O + 'estimates_remaining_2011_2019.csv')
    IDS = pd.read_csv(O + 'construction_bounds.csv').drop_duplicates(['outcome', 'exposure']).set_index(['outcome', 'exposure'])
    CO = pd.read_csv(O + 'alternative_controls.csv')
    CS = pd.read_csv(O + 'control_subsets_estimates.csv')
    cols = [('inv_growth', 'dfi'), ('inv_growth', 'dig'), ('inv_gdp', 'dfi')]
    cp2 = lambda b, p: f'{f3(b)}\n{pb(p)}'
    def sec(chk):
        return [cp2(SEC[(SEC.outcome == y) & (SEC.exposure == e) & (SEC.check == chk)].iloc[0].coef_res,
                    SEC[(SEC.outcome == y) & (SEC.exposure == e) & (SEC.check == chk)].iloc[0].p) for y, e in cols]
    LOY = pd.read_csv(O + 'leave_one_year.csv')
    one = lambda s_: int(s_.unique().item())                         # a sample size that must be common to all rows
    secN = lambda chk: one(SEC[SEC.check == chk].N)
    N11 = one(LOY[LOY.year_dropped == 2011].N); NLOPO = secN('leave-one-province-out')
    NLOYO = one(LOY.N)
    def sec_se(chk):
        out = []
        for y, e in cols:
            out.append(dse(y, e, chk))
        return out
    rows3 = [('PANEL', 'Panel A. Primary estimate')]
    rows3.append(['Coefficient, province-clustered SE'] + [f'{f3(p4(y, e).coef_res)}\n({f3((p4(y, e).cr1s_hi - p4(y, e).cr1s_lo) / (2 * T30_))})\n{pbr(p4(y, e).cr1s_p)}' for y, e in cols])
    rows3.append(['Two-way-clustered SE'] + [f"({f3((p4(y, e).tw_hi - p4(y, e).tw_lo) / (2 * T8_))})\n{pbr(p4(y, e).tw_p)}" for y, e in cols])
    rows3.append(('PANEL', 'Panel B. Sample and variable construction (same nominal specification)'))
    rows3.append(['Alternative 2018–2019 outcomes'] + [f'{f3(IDS.loc[(y, e)].theta_anchor)}\n({f3((IDS.loc[(y, e)].anchor_cr1s_hi - IDS.loc[(y, e)].anchor_cr1s_lo) / (2 * T30_))})\n{pbr(IDS.loc[(y, e)].anchor_cr1s_p)}' for y, e in cols])
    cc = lambda y, e: CO[(CO.controls == 'size and fiscal support on pre-census vintage') & (CO.outcome == y) & (CO.exposure == e)].iloc[0]
    rows3.append(['Alternative GDP-based controls'] + [dse2(y, e, 'size and fiscal support on pre-census vintage') for y, e in cols])
    ly11 = lambda y, e: LOY[(LOY.outcome == y) & (LOY.exposure == e) & (LOY.year_dropped == 2011)].iloc[0]
    rows3.append([f'2011 excluded (N={N11})'] + [dse(y, e, 'drop 2011') for y, e in cols])
    lp = []
    for y, e in cols:
        r = SEC[(SEC.outcome == y) & (SEC.exposure == e) & (SEC.check == 'leave-one-province-out')].iloc[0]
        lp.append(f'{f3(r.lopo_min)} to {f3(r.lopo_max)}')
    rows3.append(['Leave-one-province-out range'] + lp)
    rows3.append(('PANEL', 'Panel C. Specification changes (different estimand)'))
    rows3.append(['Expanded controls'] + sec_se('expanded covariates'))
    rows3.append(['Region × year effects'] + sec_se('region-by-year effects'))
    rows3.append(['GDP-weighted'] + sec_se('GDP-weighted'))
    rows3.append(['Province linear trends'] + sec_se('province trends'))
    rows3.append([f'First differences (N={secN("first differences")})'] + sec_se('first differences'))
    rows3 = [r if isinstance(r, tuple) else ['   ' + r[0]] + r[1:] for r in rows3]
    TABLE3 = ('Table 3. ', 'Selected Sensitivity Checks for the Static Estimates, 2011–2019',
              [['', ('Investment growth', 2), 'Investment intensity'],
               ['', 'Overall index\n(1)', 'Digitization\n(2)', 'Overall index\n(3)']],
              rows3, [4111, 1750, 1750, 1750],
              '')

    # ---------------- Table 4: dynamic specifications, journal layout
    DYN = pd.read_csv(O + 'dynamics.csv')
    def dyn(y, e, model):
        return DYN[(DYN.outcome == y) & (DYN.exposure == e) & (DYN.model == model)].iloc[0]
    JL = 'lead, current and lag jointly'; CH = 'change in the index (per residual SD of the change)'; LC = 'level and change together'
    RM = lambda y, e: REM[(REM.outcome == y) & (REM.exposure == e)].iloc[0]
    NDYN = one(DYN.N); NLDV = one(REM.ldv_N)
    LP = {y_: SEC[(SEC.outcome == y_) & (SEC.exposure == 'dfi') & (SEC.check == 'lead placebo')].iloc[0] for y_ in ('inv_growth', 'inv_gdp')}
    rows4 = [('PANEL', 'Panel A. Single-regressor models, 2012–2019')]
    _cs = dyn('inv_growth', 'dfi', 'current only, same sample')
    rows4.append([f'Current value of the index (N={NDYN})'] + [dse2(y, e, 'current only, same sample: current') for y, e in cols])
    rows4.append([f'Change in the index (N={NDYN})'] + [dse2(y, e, CH + ': current') for y, e in cols])
    rows4.append([f'Lagged index and lagged controls (N={secN("lagged exposure")})'] + sec_se('lagged exposure'))
    rows4.append(('PANEL', f'Panel B. Joint lead–current–lag model, 2012–2019 (N={NDYN})'))
    for _lab, _col, _pc in (('Lead (t+1)', 'lead', 'lead_p'), ('Current value (t)', 'current', 'current_p'), ('Lag (t−1)', 'lag', 'lag_p')):
        rows4.append([_lab] + [dse2(y, e, JL + ': ' + _col) for y, e in cols])
    rows4.append(('PANEL', 'Tests on the joint model, p-values'))
    rows4.append(['Joint test, H₀: all three zero (nominal)'] + [pbr(dyn(y, e, JL).joint_p) for y, e in cols])
    rows4.append(['Test, H₀: lead equals current value (nominal)'] + [pbr(dyn(y, e, JL).lead_equals_current_p) for y, e in cols])
    rows4.append(('PANEL', f'Panel C. Level and change entered together, 2012–2019 (N={NDYN})'))
    rows4.append(['Level'] + [dse2(y, e, LC + ': current') for y, e in cols])
    rows4.append(['Change'] + [dse2(y, e, LC + ': change') for y, e in cols])
    rows4.append(('PANEL', f'Panel D. Lagged-outcome model, exploratory, 2012–2019 (N={NLDV})'))
    rows4.append(['Index coefficient, no bias correction'] + [dse(y, e, 'lagged outcome, uncorrected') for y, e in cols])
    rows4 = [r if isinstance(r, tuple) else ['   ' + r[0]] + r[1:] for r in rows4]
    TABLE4 = ('Table 4. ', 'Dynamic Specifications, 2012–2019',
              [['', ('Investment growth', 2), 'Investment intensity'],
               ['', 'Overall index\n(1)', 'Digitization\n(2)', 'Overall index\n(3)']],
              rows4, [4111, 1750, 1750, 1750],
              '')

    REC = pd.read_csv(O + 'conference_reconciliation.csv')
    NST = {st: one(REC[REC.step.str.startswith(st)].N) for st in '0126'}
    DF0 = one(REC[REC.step.str.startswith('0')].conference_convention_df)
    STEPLAB = {'0': f'Step 0. Conference estimation code (N={NST["0"]})',
               '1': f'Step 1. Record restored (N={NST["1"]})',
               '2': f'Step 2. Record removed (N={NST["2"]})',
               '3': 'Step 3. Moderators centred at their means', '4': 'Step 4. Interactions removed',
               '5': 'Step 5. Four primary controls', '6': f'Step 6. Sample 2011–2019 (N={NST["6"]})',
               '7': 'Step 7. Rescaled to one baseline residual SD (Table 2)'}
    rows5 = []
    for y, pan in (('inv_growth', 'Panel A. Investment growth'), ('inv_gdp', 'Panel B. Investment intensity')):
        rows5.append(('PANEL', pan))
        for st in '01234567':
            Rs = REC[(REC.outcome == y) & REC.step.str.startswith(st)]
            cells = []
            for e in ('cov', 'use', 'dig'):
                r = Rs[Rs.exposure == e].iloc[0]
                b = r.coef_res if st == '7' else r.coef_index_scale
                se_ = r.cr1s_se_res if st == '7' else r.cr1s_se_index_scale
                cells.append(f'{f3(b)}\n({f3(se_)})\n[{fp(r.cr1s_p)}]')
            rows5.append(['   ' + STEPLAB[st]] + cells)
            if st == '0':
                rows5.append([f'      p-value, conference convention (t({DF0}))'] +
                             [pbr(Rs[Rs.exposure == e].iloc[0].conference_convention_p) for e in ('cov', 'use', 'dig')])
    TABLE5 = ('Table 5. ', 'Reconciliation with the Conference Specification of Guan et al. (2025), Joint Components',
              ['', 'Coverage breadth', 'Usage depth', 'Digitization'], rows5, [4561, 1600, 1600, 1600],
              '')

    # ---------------- appendix tables
    mnus = lambda t: t.replace('-', '−')
    f2z = lambda v: ('−' if v < -0.005 else '') + f'{abs(v):.2f}'
    f4 = lambda p: f'{p:.4f}'
    import json as _json
    MISC = _json.load(open(O + 'misc_results.json')); LOG = MISC['cleaning_log']
    (mp_, my_, mraw_), = LOG['malformed_fiscal']                      # the one malformed fiscal value
    fis = CPA[CPA.prov_name == mp_].set_index('year').fiscal; my_ = int(my_)
    assert len(CPA) == LOG['clean_rows']
    _m17 = CPA[CPA.year <= 2017]
    N_MECH_T = len(_m17)
    N_MECH = int(((_m17.pub_inv + _m17.priv_inv + _m17.for_inv - _m17.inv_gdp).abs() <= 1e-4).sum())
    TABLEA1 = ('Table A.1. ', 'Data-Cleaning Decisions',
               ['Issue', 'Evidence', 'Treatment'],
               [['Beijing 2011 fiscal value' if (mp_, my_) == ('Beijing', 2011) else f'{mp_} {my_} fiscal value',
                 f'The recorded value is “{mraw_}”.', f'Retain the numeric prefix, {float(fis[my_])!r}.'],
                ['Composite 2020 province record', 'Two rows are labelled Hubei and none is labelled Hebei. One row combines the published Hebei index with duplicated Hubei outcome and control values.',
                 'Exclude the composite row and retain the internally consistent Hubei row. No 2020 Hebei record remains.'],
                ['Mechanical relation to the outcome', f'The public, domestic-private and foreign investment components sum to investment intensity to within 0.0001 in {N_MECH} of {N_MECH_T} province-years in 2011–2017.',
                 'Exclude all three investment components from the regressions.'],
                ['Variables common to all provinces', 'Financial depth, width and structure have the same value for every province within each year.',
                 'Exclude as regional regressors because year effects absorb their levels.'],
                ['Sectoral structure', f'The series ranges from {f3(CPA.sectoral.min())} to {f3(CPA.sectoral.max())}. Its definition and transformation are undocumented.', 'Exclude from the analysis.'],
                ['Regional capital flows', 'The variable is present in the deposit, but its operational definition is undocumented.', 'Exclude from the analysis.']],
               [2000, 4361, 3000],
               '', 'left')

    RG = pd.read_csv(O + 'construction_regimes.csv')
    rA2 = []
    for _, r in RG.sort_values('province').iterrows():
        rA2.append([r.province, f'{r.deposit_inv_gdp_2018:.3f}', f'{r.anchor_inv_gdp_2018:.3f}', f'{r.deposit_inv_gdp_2019:.3f}',
                    f'{r.anchor_inv_gdp_2019:.3f}', f2z(100 * (r.deposit_growth_2018 - r.anchor_growth_2018)),
                    f2z(100 * (r.deposit_growth_2019 - r.anchor_growth_2019))])
    assert len(rA2) == NPROV
    TABLEA2 = ('Table A.2. ', 'Dataset Values and Alternative Constructions, 2018–2019',
               [['', ('Investment intensity, 2018', 2), ('Investment intensity, 2019', 2), ('Growth: dataset − alternative', 2)],
                ['Province', 'Dataset', 'Alternative', 'Dataset', 'Alternative', '2018', '2019']],
               rA2, [1961, 1200, 1200, 1200, 1200, 1300, 1300],
               '')

    IDS_ = pd.read_csv(O + 'construction_bounds.csv').drop_duplicates(['outcome', 'exposure']).set_index(['outcome', 'exposure'])
    colsA3 = [('inv_growth', 'dfi'), ('inv_growth', 'dig'), ('inv_gdp', 'dfi'), ('inv_gdp', 'dig')]
    pp_ = lambda a, b: f'[{fp(a)}; {fp(b)}]'
    rA3 = [['Dataset variables (Table 2)'] + [f'{f3(p4(y, e).coef_res)}\n{pp_(p4(y, e).cr1s_p, p4(y, e).tw_p)}' for y, e in colsA3],
           ['Alternative 2018–2019 outcomes'] + [f'{f3(IDS_.loc[(y, e)].theta_anchor)}\n{pp_(IDS_.loc[(y, e)].anchor_cr1s_p, IDS_.loc[(y, e)].anchor_tw_p)}' for y, e in colsA3]]
    for lab_, key_ in (('Alternative income size', 'size on pre-census vintage'),
                       ('Alternative income size and fiscal support', 'size and fiscal support on pre-census vintage')):
        rA3.append([lab_] + [f'{f3(r.theta_deposit)}\n{pp_(r.deposit_p, r.deposit_tw_p)}' for r in
                             [CO[(CO.controls == key_) & (CO.outcome == y) & (CO.exposure == e)].iloc[0] for y, e in colsA3]])
    for y, e in colsA3:   # the dataset row of the controls file must equal Table 2
        r = CO[(CO.controls == 'deposit controls') & (CO.outcome == y) & (CO.exposure == e)].iloc[0]
        assert abs(r.theta_deposit - p4(y, e).coef_res) < 1e-10
        assert abs(IDS_.loc[(y, e)].theta_deposit - p4(y, e).coef_res) < 1e-10
    rA3 = [['   ' + r[0]] + r[1:] for r in rA3]
    TABLEA3 = ('Table A.3. ', 'Primary Estimates under Alternative Constructions, 2011–2019',
               [['', ('Investment growth', 2), ('Investment intensity', 2)],
                ['', 'Overall index\n(1)', 'Digitization\n(2)', 'Overall index\n(3)', 'Digitization\n(4)']],
               rA3, [3361, 1500, 1500, 1500, 1500],
               '')

    # Table B.1: all static checks (coefficient, CR1S SE, p)
    _c = lambda b, p: f'{f3(b)} ({f3(se30(b, p))}) [{fp(p)}]'
    OF13 = pd.read_csv(O + 'yearbook_outcomes.csv')
    _of = lambda v, e: OF13[(OF13.variable == v) & (OF13.exposure == e)].iloc[0]
    def _secB(chk):
        return [_c(*SEC[(SEC.outcome == y) & (SEC.exposure == e) & (SEC.check == chk)].iloc[0][['coef_res', 'p']]) for y, e in cols]
    def _csB(lab_):
        return [_c(*CS[(CS.controls == lab_) & (CS.outcome == y) & (CS.exposure == e)].iloc[0][['coef_res', 'cr1s_p']]) for y, e in cols]
    _coB = lambda y, e: CO[(CO.controls == 'size and fiscal support on pre-census vintage') & (CO.outcome == y) & (CO.exposure == e)].iloc[0]
    rB1 = [('PANEL', 'Panel A. Inference')]
    rB1.append(['Primary, province-clustered'] + [_c(p4(y, e).coef_res, p4(y, e).cr1s_p) for y, e in cols])
    rB1.append(['Primary, two-way-clustered'] + [f'{f3(p4(y, e).coef_res)} ({f3((p4(y, e).tw_hi - p4(y, e).tw_lo) / (2 * T8_))}) [{fp(p4(y, e).tw_p)}]' for y, e in cols])
    rB1.append(('PANEL', 'Panel B. Sample and variable construction'))
    rB1.append([f'Investment intensity, 2011–2017 (N={one(OF13[OF13.variable == "off_ratio"].N)})', 'n.a.', 'n.a.', _c(_of('off_ratio', 'dfi').coef_res, _of('off_ratio', 'dfi').cr1s_p)])
    rB1.append(['Alternative 2018–2019 outcomes'] + [_c(IDS_.loc[(y, e)].theta_anchor, IDS_.loc[(y, e)].anchor_cr1s_p) for y, e in cols])
    rB1.append(['Alternative GDP-based controls'] + [_c(_coB(y, e).theta_deposit, _coB(y, e).deposit_p) for y, e in cols])
    rB1.append(['Winsorised at 1/99 percent'] + _secB('winsorised 1/99'))
    rB1.append([f'2011 excluded (N={N11})'] + [_c(*LOY[(LOY.outcome == y) & (LOY.exposure == e) & (LOY.year_dropped == 2011)].iloc[0][['coef_res', 'cr1s_p']]) for y, e in cols])
    _lpB, _lyB = [], []
    for y, e in cols:
        r = SEC[(SEC.outcome == y) & (SEC.exposure == e) & (SEC.check == 'leave-one-province-out')].iloc[0]
        _lpB.append(f'{f3(r.lopo_min)} to {f3(r.lopo_max)}; {int(r.lopo_p05)} of {NPROV}')
        r = REM[(REM.outcome == y) & (REM.exposure == e)].iloc[0]
        _lyB.append(f'{f3(r.loyo_min)} to {f3(r.loyo_max)}; {int(r.loyo_p05)} of {NYR}')
    rB1.append(['Leave one province out: range; n(p<0.05)'] + _lpB)
    rB1.append(['Leave one year out: range; n(p<0.05)'] + _lyB)
    rB1.append(('PANEL', 'Panel C. Specification'))
    rB1.append(['Yearbook-based total investment growth'] + [_c(_of('growth_official', e).coef_res, _of('growth_official', e).cr1s_p) for e in ('dfi', 'dig')] + ['n.a.'])
    rB1.append(['Fixed effects only (no controls)'] + _secB('fixed effects only'))
    rB1.append(['Without regional income volatility'] + _csB('without vol'))
    rB1.append(['Without fiscal support'] + _csB('without fiscal'))
    rB1.append(['Without regional income size'] + _csB('without size'))
    rB1.append(['Expanded controls'] + _secB('expanded covariates'))
    rB1.append(['Region-by-year effects'] + _secB('region-by-year effects'))
    rB1.append(['Province post-2017 shifts'] + _secB('province post-2017 shifts'))
    rB1.append(['GDP-weighted'] + _secB('GDP-weighted'))
    rB1.append(['Province-specific linear trends'] + _secB('province trends'))
    rB1.append([f'First differences (N={secN("first differences")})'] + _secB('first differences'))
    rB1 = [r if isinstance(r, tuple) else ['   ' + r[0]] + r[1:] for r in rB1]
    TABLEB1 = ('Table B.1. ', 'All Static Sensitivity Checks, 2011–2019',
               [['', ('Investment growth', 2), 'Investment intensity'],
                ['', 'Overall index', 'Digitization', 'Overall index']],
               rB1, [3361, 2000, 2000, 2000],
               '')

    WB = one(pd.read_csv(O + 'sample_2011_2019.csv').wild_B)
    BYQ = pd.read_csv(O + 'by_qvalues.csv'); TWI = pd.read_csv(O + 'twoway_intersection_results.csv')
    rB2 = []
    for y, pan in (('inv_gdp', 'Panel A. Investment intensity'), ('inv_growth', 'Panel B. Investment growth')):
        rB2.append(('PANEL', pan))
        for e in ('dfi', 'cov', 'use', 'dig'):
            r = p4(y, e); b_ = BYQ[(BYQ.outcome == y) & (BYQ.exposure == e)].iloc[0]; t_ = TWI[(TWI.outcome == y) & (TWI.exposure == e)].iloc[0]
            assert abs(b_.bh_q_cr1s - r.bh_q_cr1s) < 1e-12 and abs(t_.tw_p_reported - r.tw_p) < 1e-12
            rB2.append(['   ' + ('Overall index' if e == 'dfi' else EL[e]), fp(r.cr1s_p), f4(r.wild_p), fp(r.cr2_p), fp(r.bh_q_cr1s), fp(b_.by_q_cr1s),
                        fp(r.tw_p), fp(r.bh_q_tw), fp(t_.tw_p_alternative), fp(t_.bh_q_alternative)])
    TABLEB2 = ('Table B.2. ', 'Additional Inference for the Primary Estimates, 2011–2019',
               [['', ('Province-clustered', 5), ('Two-way-clustered', 4)],
                ['', 'p, CR1S', 'p, wild', 'p, CR2', 'BH q', 'BY q', 'p', 'BH q', 'p, alt.', 'BH q, alt.']],
               rB2, [1801] + [840] * 9,
               '')

    SPJ = pd.read_csv(O + 'spj_halves.csv')
    NS, NH1, NH2, SB = one(SPJ.N), one(SPJ.N_half1), one(SPJ.N_half2), one(REM.spj_boot_B)
    assert NH1 == NH2
    rB3 = []
    for y, pan in (('inv_gdp', 'Panel A. Investment intensity'), ('inv_growth', 'Panel B. Investment growth')):
        rB3.append(('PANEL', pan))
        for e in ('dfi', 'dig'):
            r = SPJ[(SPJ.outcome == y) & (SPJ.exposure == e)].iloc[0]
            q = REM[(REM.outcome == y) & (REM.exposure == e)].iloc[0]
            assert abs(q.spj_coef_res - r.index_spj) < 1e-10 and abs(q.spj_ylag - r.ylag_spj) < 1e-10
            rB3.append(['   ' + ('Overall index' if e == 'dfi' else EL[e])] + [f3(r[c]) for c in ('index_full', 'index_half1', 'index_half2', 'index_spj')]
                       + [f'({f3(q.spj_boot_se_res)})'] + [f2(r[c]) for c in ('ylag_full', 'ylag_half1', 'ylag_half2', 'ylag_spj')] + [f'({f2(q.spj_ylag_boot_se)})'])
    TABLEB3 = ('Table B.3. ', 'Lagged-Outcome Models: Full Sample, Half-Panels and Split-Panel Jackknife, 2012–2019',
               [['', ('Index coefficient', 5), ('Lagged-outcome coefficient', 5)],
                ['', 'Full', '2012–15', '2016–19', 'SPJ', 'SE', 'Full', '2012–15', '2016–19', 'SPJ', 'SE']],
               rB3, [1761] + [760] * 10,
               '')

    FIG1 = ('Figure 1. ', 'Approximate Minimum Detectable Effects, Overall Index',
            os.path.join(O, 'figure1_mde.png'),
            'Notes: MDE = (t₀.₉₇₅,ν + z₀.₈)·SE, a t-critical-value approximation for nominal 80 percent power in a two-sided 5 '
            f'percent test, per baseline residual SD of the index. ν = {NPROV - 1} for province-clustered inference ({NPROV - 4} without three '
            'provinces) and the number of years minus one for two-way-clustered inference. Rows: sample years and controls. '
            '2011–20: deposited 2011–2020 panel. −3 prov.: Shanghai, Beijing and Zhejiang removed. Vertical lines: reference '
            'effects of 0.005, 0.01 and 0.02 (Section 4.2).')

    # ---------------- references
    T = {}; RAW = {}
    # Captions are the printed titles. Notes are the printed notes, with every sample size, degree of freedom and
    # estimate computed from the outputs above.
    DFP, DFT = NPROV - 1, NYR - 1
    CAPTIONS = {
        '1': 'Table 1. Summary Statistics, 2011–2019',
        '2': 'Table 2. Primary Estimates, 2011–2019',
        '3': 'Table 3. Selected Sensitivity Checks for the Static Estimates, 2011–2019',
        '4': 'Table 4. Dynamic Specifications, 2012–2019',
        '5': 'Table 5. Reconciliation with the Conference Specification of Guan et al. (2025), Joint Components',
        'A1': 'Table A.1. Data-Cleaning Decisions',
        'A2': 'Table A.2. Dataset Values and Alternative Constructions, 2018–2019',
        'A3': 'Table A.3. Primary Estimates under Alternative Constructions, 2011–2019',
        'B1': 'Table B.1. All Static Sensitivity Checks, 2011–2019',
        'B2': 'Table B.2. Additional Inference for the Primary Estimates, 2011–2019',
        'B3': 'Table B.3. Lagged-Outcome Models: Full Sample, Half-Panels and Split-Panel Jackknife, 2012–2019',
    }
    NOTES = {
        '1': f'Notes: Data from Zhan et al. (2023b), {NPROV} provinces, 2011–2019. SD: standard deviation. FAI: fixed-asset investment. Investment growth is the nominal growth rate of fixed-asset investment per head of year-end population. Outcomes are ratios (0.10 corresponds to 10 percent). The digital-finance variables are provincial values of the Peking University index and its components, divided by 100. Labour cost is the logarithm of the average wage of urban employees. Regional income size is provincial GDP divided by national GDP. Fiscal support is local general public budget expenditure divided by provincial GDP. Regional income volatility is reported to four decimal places because its mean is zero to rounding. Raw values are shown; the regressions standardise the controls and measure the exposures in baseline residual-SD units (Section 4.1).',
        '2': f'Notes: Coefficients per baseline residual SD of the exposure (Section 4.1). As in Tables 3 and 4, standard errors are in parentheses and p-values in brackets. The first row of each exposure gives the coefficient with its province-clustered standard error and p-value; the second gives the two-way-clustered standard error and p-value for the same coefficient. Province-clustered inference uses CR1S with t({DFP}). Two-way-clustered inference clusters by province and year with t({DFT}); it is a sensitivity analysis with limited time-cluster support (Section 4.2). Investment intensity is investment/GDP; investment growth is per-capita growth. Columns (1) and (3) enter the overall index; columns (2) and (4) enter the three components jointly. Coefficients, standard errors and p-values are rounded to three decimals. Appendix B.1 gives the covariance formulas. Appendix Table B.2 reports wild-cluster bootstrap and CR2 p-values, Benjamini–Hochberg and Benjamini–Yekutieli values and the alternative two-way convention.',
        '3': f'Notes: Coefficients per baseline residual SD of the exposure. Below each coefficient: the province-clustered CR1S standard error in parentheses and the p-value (t({DFP})) in brackets. The second row gives the two-way-clustered standard error and p-value (t({DFT})) of the primary estimate. Common baseline: 2011–2019, four primary controls, province and year effects. N={NOBS} unless stated; leave-one-province-out refits use N={NLOPO}. Digitization is entered jointly with the other two components. Panel B keeps the nominal specification and changes the sample or the construction of a variable (Appendix A.4); a sample change can alter the period and composition that the estimate describes. Panel C changes the controls, fixed effects, weighting or estimator, so each row estimates a different parameter. Standard errors come from the estimation routines. Appendix Table B.1 reports all static checks.',
        '4': f'Notes: Primary controls and province and year effects throughout. Below each coefficient: the province-clustered CR1S standard error in parentheses and the p-value (t({DFP})) in brackets. Level terms are per baseline residual SD of the index. Change terms are per residual SD of the change in the index, so their magnitudes are not comparable with level terms. Samples and timing differ across panels and from Table 2. Models with the lead use {NDYN} observations, and the observed 2020 index is the lead of 2019 (Appendix Table A.1). Panels A–C use the same {NDYN} observations, except the lagged-index row. The lagged-index model lags the index and the controls one year. A lead placebo on 2011–2018 adds the next-year overall index to the current-index model; its coefficient is {f3(LP["inv_growth"].coef_res)} (p = {fp(LP["inv_growth"].p)}) for investment growth and {f3(LP["inv_gdp"].coef_res)} (p = {fp(LP["inv_gdp"].p)}) for investment intensity. Joint tests: Wald tests with F(3, {DFP}) and F(1, {DFP}). For digitization, the other two components enter with the same terms. Panel D adds the one-year lag of the outcome to the current-index model and uses the within estimator; its standard errors ignore the bias of order 1/T (Section 4.2). Appendix B.2 describes the split-panel-jackknife diagnostic.',
        '5': f'Notes: Province-clustered standard errors (CR1S) in parentheses and p-values (t({DFP})) in brackets. Each step changes one feature of the previous step. Step 3 changes only the reference point, and Step 7 only the scale. Step 0 applies the estimation code of the conference paper to the deposited records, with province and year effects. It enters the three components jointly with eleven controls (investment return, saving, credit-market quality, labour cost, income volatility, fiscal support, sectoral structure, public, private and foreign investment, regional income size). It also includes the twelve interactions of the components with financial depth, financial width, financial structure and regional income size. Steps 1 and 2 align the records with the cleaned dataset (Appendix Table A.1). The row below Step 0 gives p-values under the convention of that code, which scales the clustered covariance by N/(N − K) and uses t({DF0}). Steps 0–6: coefficients on the deposited index scale (index/100). Step 3 centres the moderators and leaves the fitted values unchanged. Step 7 rescales Step 6 and equals the joint estimates of Table 2.',
        'A1': f'Notes: The cleaned panel has {LOG["clean_rows"]} province-years. The removed 2020 row carries the published Hebei index values and outcome and control values that equal the linear extrapolation of Hubei’s 2018 and 2019 values, so no corrected Hebei record can be built. The parsed {mp_} {my_} fiscal value ({fis[my_]:.4f}) is in line with the province’s {my_ + 1} and {my_ + 2} values ({fis[my_ + 1]:.3f} and {fis[my_ + 2]:.3f}).',
        'A2': f'Notes: Alternative investment intensity: the same chained investment level divided by GDP from the series used for 2011–2017. For 2018 this is the GDP printed in CSY2019. For 2019 it is 2019 GDP from CSY2020 scaled by the province’s 2018 ratio of the two series, an approximation, because CSY2019 does not report 2019. Alternative growth: published growth per head of year-end population. Growth differences in percentage points.',
        'A3': f'Notes: Coefficients are scaled by the baseline residual standard deviation of the relevant digital-finance variable. Each coefficient is followed by two p-values: province-clustered (CR1S, t({DFP})) and two-way-clustered (t({DFT})), respectively. Digitization enters jointly with the other two index components. All specifications use {NOBS} province-year observations. Alternative outcomes replace only the 2018–2019 outcome values. Alternative controls retain the deposited outcome values. The results are sensitivity checks under the stated construction assumptions.',
        'B1': f'Notes: Coefficients are expressed per baseline residual standard deviation of the exposure. Standard errors are reported in parentheses and p-values in brackets. All specifications use province-clustered CR1S inference unless otherwise stated. Province-clustered p-values use t({DFP}); the two-way-clustered row uses t({DFT}). All reported sensitivity-test p-values are nominal and unadjusted for multiple testing. The primary sample contains {NOBS} province-year observations. Each leave-one-province-out regression contains {NLOPO} observations and uses t({DFP - 1}). Each leave-one-year-out regression contains {NLOYO} observations and uses t({DFP}). The leave-one-out rows report coefficient ranges and the number of refits with nominal p < 0.05. These counts are descriptive. The winsorised specifications apply pooled 1st and 99th percentile cutoffs to the outcome, digital-finance variables and primary controls, using the cleaned 2011–2020 panel. The baseline standardisation is retained. Yearbook-based total investment growth uses reported investment levels for 2011–2017 and published growth rates for 2018–2019, without the per-capita adjustment. Province post-2017 shifts add province-specific indicators for 2018 onward. GDP weights equal regional income size. Region-by-year effects replace year effects with region-by-year indicators. Expanded controls add investment return, saving and credit-market quality. The digitization specifications include the other two digital-finance components. n.a. denotes not applicable.',
        'B2': f'Notes: N={NOBS}. Coefficients as in Table 2. Wild: restricted wild-cluster bootstrap-t with {WB:,} draws and province-level Rademacher weights, shown to four decimals because the bootstrap grid has steps of {1 / (WB + 1):.4f}. CR2: Bell–McCaffrey standard errors with Satterthwaite degrees of freedom. BH and BY: Benjamini–Hochberg and Benjamini–Yekutieli adjustments within the family of eight estimates under each procedure. Two-way p uses t({DFT}). Alt.: the same small-sample factor is also applied to the intersection term of the two-way estimator.',
        'B3': f'Notes: N = {NS} ({NH1} in each half). Index coefficients per baseline residual SD; lagged-outcome coefficients to two decimals. Primary controls and province and year effects throughout; digitization is entered jointly with the other two components. SPJ: split-panel jackknife, equal to 2 × Full − the mean of the two halves. The correction is SPJ − Full. SE: province-cluster bootstrap standard error of the SPJ estimate, {SB} replications.',
    }
    for lab in ('1', '2', '3', '4', '5', 'A1', 'A2', 'A3', 'B1', 'B2', 'B3'):
        t = locals()['TABLE' + lab]
        T[lab] = (CAPTIONS[lab], t[2], t[3], NOTES[lab]); RAW[lab] = t
    return (T, FIG1, RAW) if raw else (T, FIG1)


NUMRE = re.compile(r'^[\(\[]?[−-]?<?\d+\.\d+[\)\]]?( / [−-]?<?\d+\.\d+)?$')
def isnum(text):
    parts = [x for x in str(text).split('\n')]
    return bool(str(text)) and all(NUMRE.match(x) for x in parts)


def flatten_row(r):
    """The printed lines of one table row, in reading order, as the manuscript splits multi-line cells into sub-rows."""
    if isinstance(r, tuple):
        return [r[1]]
    ncell = max(len(str(c).split('\n')) for c in r[1:])
    out = []
    for k in range(ncell):
        row_ = [r[0] if k == 0 else '']
        for c in r[1:]:
            ls_ = str(c).split('\n')
            row_.append(ls_[k] if (k < len(ls_) and (len(ls_) > 1 or isnum(c) or k == 0)) else '')
        out += row_
    return [x for x in out if x.strip()]


def write_tables(T, folder):
    os.makedirs(folder, exist_ok=True)
    for lab, (cap, hdr, rows, note) in T.items():
        hdrs = hdr if isinstance(hdr[0], list) else [hdr]
        width = sum(c[1] if isinstance(c, tuple) else 1 for c in hdrs[-1])
        recs = []
        for h in hdrs:
            line = []
            for c in h:
                txt, sp = (c if isinstance(c, tuple) else (c, 1))
                line += [txt.replace('\n', ' ')] + [''] * (sp - 1)
            recs.append(line)
        for r in rows:
            recs.append([r[1].strip()] + [''] * (width - 1) if isinstance(r, tuple) else [str(c).strip().replace('\n', ' ') for c in r])
        df = pd.DataFrame(recs)
        name = os.path.join(folder, f'Table_{lab}.csv')
        with open(name, 'w', encoding='utf-8') as fh:
            fh.write(cap + '\n'); df.to_csv(fh, index=False, header=False); fh.write(note + '\n')


def numbers(O, root):
    """Numbers quoted in the text or tables, recomputed from the outputs, with the string printed in the manuscript."""
    rd = lambda f: pd.read_csv(os.path.join(O, f))
    f3 = lambda v: ('−' if v < -0.0005 else '') + f'{abs(v):.3f}'
    P = rd('primary_estimates.csv'); P = P[P['sample'] == '2011-2019'].set_index(['outcome', 'exposure'])
    C = rd('exposure_concentration.csv'); C = C[(C['sample'] == '2011-2019') & (C.exposure == 'dfi')].set_index('residualisation')
    CP = rd('cleaned_panel.csv'); CP = CP[CP.year <= 2019]
    SEC = rd('estimates_secondary_2011_2019.csv').set_index(['outcome', 'exposure', 'check'])
    LOY = rd('leave_one_year.csv').set_index(['outcome', 'exposure', 'year_dropped'])
    DY = rd('dynamics.csv').set_index(['outcome', 'exposure', 'model'])
    YI = rd('year_influence.csv').set_index(['outcome', 'year'])
    PV = rd('influence_2011_provinces_terms.csv').set_index(['outcome', 'province'])
    SC = rd('scaling_check_results.csv').set_index(['exposure', 'outcome'])
    BY = rd('by_qvalues.csv').set_index(['outcome', 'exposure'])
    CO = rd('alternative_controls.csv').set_index(['controls', 'outcome', 'exposure'])
    CS = rd('control_subsets_estimates.csv').set_index(['controls', 'outcome', 'exposure'])
    RC = rd('residual_index_corr.csv').set_index(['exposure', 'conditioning'])
    g, i_ = ('inv_growth', 'dfi'), ('inv_gdp', 'dfi')
    N = []
    add = lambda claim, value, printed: N.append((claim, value, printed))
    add('Province-year observations, 2011-2019', len(CP), str(len(CP)))
    add('Mean investment intensity', CP.inv_gdp.mean(), f'{CP.inv_gdp.mean():.2f}')
    add('Investment intensity above one (province-years)', int((CP.inv_gdp > 1).sum()), f'in {int((CP.inv_gdp > 1).sum())} province-years')
    add('Mean investment growth (percent)', 100 * CP.inv_growth.mean(), f'{100 * CP.inv_growth.mean():.1f} percent')
    add('Residual-to-raw SD ratio, FE only (percent)', 100 * C.loc['two-way only'].sd_ratio, f'{100 * C.loc["two-way only"].sd_ratio:.1f} percent')
    add('Residual-to-raw SD ratio, after controls (percent)', 100 * C.loc['after controls'].sd_ratio, f'{100 * C.loc["after controls"].sd_ratio:.1f} percent')
    add('Inverse Herfindahl, FE only', C.loc['two-way only'].inv_herfindahl, f'{C.loc["two-way only"].inv_herfindahl:.1f}')
    add('Top-3 share, FE only (percent)', 100 * C.loc['two-way only'].top3_share, f'{100 * C.loc["two-way only"].top3_share:.1f} percent')
    add('Shanghai share, FE only (percent)', 100 * C.loc['two-way only'].top_share, f'{100 * C.loc["two-way only"].top_share:.1f} percent')
    add('Inverse Herfindahl, after controls', C.loc['after controls'].inv_herfindahl, f'{C.loc["after controls"].inv_herfindahl:.1f}')
    add('Shanghai share, after controls (percent)', 100 * C.loc['after controls'].top_share, f'{100 * C.loc["after controls"].top_share:.1f} percent')
    for (y, e), lab in ((g, 'investment growth, overall index'), (('inv_growth', 'dig'), 'investment growth, digitization'), (i_, 'investment intensity, overall index')):
        r = P.loc[(y, e)]
        add(f'Coefficient, {lab}', r.coef_res, f3(r.coef_res))
        add(f'Province-clustered p, {lab}', r.cr1s_p, f'{r.cr1s_p:.3f}')
        add(f'Two-way-clustered p, {lab}', r.tw_p, f'{r.tw_p:.3f}')
    for (y, e), lab in ((g, 'investment growth'), (i_, 'investment intensity')):
        r = P.loc[(y, e)]
        add(f'Province-clustered 95% interval, {lab}', (r.cr1s_lo, r.cr1s_hi), f'[{f3(r.cr1s_lo)}, {f3(r.cr1s_hi)}]')
        add(f'Two-way-clustered 95% interval, {lab}', (r.tw_lo, r.tw_hi), f'[{f3(r.tw_lo)}, {f3(r.tw_hi)}]')
    add('Wild-bootstrap p, investment growth', P.loc[g].wild_p, f'{P.loc[g].wild_p:.4f}')
    add('BH q, digitization (growth)', P.loc[('inv_growth', 'dig')].bh_q_cr1s, f'{P.loc[("inv_growth", "dig")].bh_q_cr1s:.3f}')
    add('BH q, overall index (growth)', P.loc[g].bh_q_cr1s, f'{P.loc[g].bh_q_cr1s:.3f}')
    add('BY q, digitization (growth)', BY.loc[('inv_growth', 'dig')].by_q_cr1s, f'{BY.loc[("inv_growth", "dig")].by_q_cr1s:.3f}')
    add('BY q, overall index (growth)', BY.loc[g].by_q_cr1s, f'{BY.loc[g].by_q_cr1s:.3f}')
    add('Province trends, investment growth', SEC.loc[g + ('province trends',)].coef_res, f3(SEC.loc[g + ('province trends',)].coef_res))
    add('Province trends, investment intensity', SEC.loc[i_ + ('province trends',)].coef_res, f3(SEC.loc[i_ + ('province trends',)].coef_res))
    add('Province trends p, investment intensity', SEC.loc[i_ + ('province trends',)].p, f'p={SEC.loc[i_ + ("province trends",)].p:.3f}')
    add('GDP-weighted, investment growth', SEC.loc[g + ('GDP-weighted',)].coef_res, f3(SEC.loc[g + ('GDP-weighted',)].coef_res))
    add('GDP-weighted p, investment growth (Table 3)', SEC.loc[g + ('GDP-weighted',)].p, f'[{SEC.loc[g + ("GDP-weighted",)].p:.3f}]')
    add('Lagged index, investment growth', SEC.loc[g + ('lagged exposure',)].coef_res, f3(SEC.loc[g + ('lagged exposure',)].coef_res))
    add('2011 excluded, investment intensity', LOY.loc[i_ + (2011,)].coef_res, f3(LOY.loc[i_ + (2011,)].coef_res))
    add('2011 excluded p, investment intensity', LOY.loc[i_ + (2011,)].cr1s_p, f'p={LOY.loc[i_ + (2011,)].cr1s_p:.3f}')
    o = LOY.loc[i_].drop(index=2011)
    add('Other year deletions, investment intensity (range)', (o.coef_res.min(), o.coef_res.max()), f'{f3(o.coef_res.min())}–{f3(o.coef_res.max())}')
    ch = DY.loc[g + ('change in the index (per residual SD of the change)',)]
    add('Change in the index, investment growth', ch.current, f'{f3(ch.current)} (p={ch.current_p:.3f})')
    jl = DY.loc[('inv_growth', 'dig', 'lead, current and lag jointly')]
    add('Joint lead-current-lag test, digitization (growth)', jl.joint_p, f'p={jl.joint_p:.3f}')
    jl = DY.loc[g + ('lead, current and lag jointly',)]
    add('Joint test, overall index (growth)', jl.joint_p, f'p={jl.joint_p:.3f}')
    add('Lead equals current test (growth)', jl.lead_equals_current_p, f'p={jl.lead_equals_current_p:.3f}')
    rc = RC.loc[('dfi', 'fixed effects and primary controls')]
    add('Adjacent-index correlations after FE and controls', (rc.corr_current_lag, rc.corr_lead_current), f'{rc.corr_current_lag:.2f} and {rc.corr_lead_current:.2f}')
    s, k = YI.loc[('inv_gdp', 2011)], YI.loc[('inv_gdp', 2019)]
    add('2011 share of residualised variation (percent)', 100 * s.share_S, f'{100 * s.share_S:.0f} percent')
    add('2019 share of residualised variation (percent)', 100 * k.share_S, f'{100 * k.share_S:.0f} percent')
    add('Fixed-residual calculation without 2011', s.theta_without_year_d_fixed_res, f3(s.theta_without_year_d_fixed_res))
    add('Removing Qinghai 2011 term', PV.loc[('inv_gdp', 'Qinghai')].theta_without_this_term_res, f3(PV.loc[('inv_gdp', 'Qinghai')].theta_without_this_term_res))
    sc = SC.loc[('dfi', 'inv_growth')]
    add('Scale factor k, overall index', sc.k, f'{sc.k:.3f}')
    add('Norm of d in baseline residual-SD units', sc.norm_d, f'{sc.norm_d:.2f}')
    add('Exposure-only MDE, primary design', sc.mde_exposure_only, f'{sc.mde_exposure_only:.3f}')
    a = CO.loc[('size and fiscal support on pre-census vintage',) + g]
    add('Alternative GDP-based controls, investment growth', (a.theta_deposit, a.deposit_p), f'declines to {f3(a.theta_deposit)}, with a province-clustered p-value of {a.deposit_p:.3f}')
    w = CS.loc[('without size',) + g]
    add('Without regional income size, investment growth', w.coef_res, f3(w.coef_res))
    # Section 5.6: the conference specification (Table 5)
    RC5 = rd('conference_reconciliation.csv'); RC5['s'] = RC5.step.str[0]
    cf = lambda y, s_, e: RC5[(RC5.outcome == y) & (RC5.s == s_) & (RC5.exposure == e)].iloc[0]
    n0 = int(cf('inv_growth', '0', 'cov').N)
    add('Conference code sample', n0, f'Conference estimation code (N={n0})')
    v = [cf('inv_growth', '0', e).coef_index_scale for e in ('cov', 'use', 'dig')]
    add('Step 0 coefficients, investment growth', v, f'{f3(v[0])} for coverage breadth, {f3(v[1])} for usage depth and {f3(v[2])} for digitization')
    v = [cf('inv_gdp', '0', e).coef_index_scale for e in ('cov', 'use', 'dig')]
    add('Step 0 coefficients, investment intensity', v, f'{f3(v[0])}, {f3(v[1])} and {f3(v[2])}')
    z = cf('inv_growth', '0', 'cov')
    add('Step 0 reference df (conference convention)', int(z.conference_convention_df), f't({int(z.conference_convention_df)})')
    for y, lab in (('inv_growth', 'investment growth'), ('inv_gdp', 'investment intensity')):
        s0, s2 = cf(y, '0', 'cov'), cf(y, '2', 'cov')
        add(f'Cleaning steps, coverage breadth, {lab}', (s0.coef_index_scale, s2.coef_index_scale),
            f'from {f3(s0.coef_index_scale)} (p={s0.cr1s_p:.3f}) to {f3(s2.coef_index_scale)} (p={s2.cr1s_p:.3f})')
    # checks on the input data quoted in Appendix A.1
    CPA = rd('cleaned_panel.csv'); m17 = CPA[CPA.year <= 2017]
    nm = int(((m17.pub_inv + m17.priv_inv + m17.for_inv - m17.inv_gdp).abs() <= 1e-4).sum())
    add('Investment components reproduce investment intensity, 2011-2017', nm, f'{nm} of {len(m17)} province-years')
    # ---- Section 1 and Section 5.1: residual variation, concentration and precision
    import json, math
    from scipy import stats
    MISC = json.load(open(os.path.join(O, 'misc_results.json')))
    CPA = rd('cleaned_panel.csv')
    k = MISC['scale_ratio']['dfi']
    add('Residual variance share, FE only (percent)', 100 * C.loc['two-way only'].sd_ratio ** 2, f'approximately {100 * C.loc["two-way only"].sd_ratio ** 2:.1f} percent of the raw variance')
    add('Top-3 share, FE only, rounded (percent)', 100 * C.loc['two-way only'].top3_share, f'about {100 * C.loc["two-way only"].top3_share:.0f} percent')
    add('Top-3 share, after controls (percent)', 100 * C.loc['after controls'].top3_share, f'{100 * C.loc["after controls"].top3_share:.1f} percent, and Shanghai')
    CC = rd('exposure_concentration.csv')
    CC = CC[(CC['sample'] == '2011-2019') & (CC.residualisation == 'two-way only')].set_index('exposure').sd_ratio
    add('Component residual SD ratios (percent)', tuple(100 * CC[['cov', 'dig', 'use']]),
        f'from {100 * CC["cov"]:.1f} percent for coverage breadth to {100 * CC["dig"]:.1f} percent for digitization, with {100 * CC["use"]:.1f} percent for usage depth')
    W = rd('residual_variation_windows.csv'); W = W[W.end - W.start >= 4]
    add('Windows of five or more years, 2011-2023', len(W), f'all {len(W)} windows of five or more years')
    add('Residual SD ratio across windows (percent)', (100 * W.ratio.min(), 100 * W.ratio.max()), f'{100 * W.ratio.min():.1f} to {100 * W.ratio.max():.1f} percent')
    add('Residual SD ratio across windows, alternative wording', (100 * W.ratio.min(), 100 * W.ratio.max()), f'between {100 * W.ratio.min():.1f} and {100 * W.ratio.max():.1f} percent')
    rsd_pts = 100 * k * CPA.dfi.std(ddof=1)
    add('One baseline residual SD of the overall index (index points)', rsd_pts, f'about {rsd_pts:.1f} index points, or {100 * rsd_pts / (100 * CPA.dfi.mean()):.0f} percent')
    add('Growth coefficient in percentage points', 100 * P.loc[g].coef_res, f'approximately {100 * P.loc[g].coef_res:.1f} percentage points')
    add('SD of investment growth (percentage points)', 100 * CP.inv_growth.std(), f'standard deviation of {100 * CP.inv_growth.std():.1f} percentage points')
    add('Coefficient per raw SD', P.loc[g].coef_res / k, f'approximately {P.loc[g].coef_res / k:.2f} ({f3(P.loc[g].coef_res)}/{k:.3f})')
    MF = rd('mde_frontier.csv'); prim = MF[(MF.window == '2011-2019 (primary)') & (MF.conditioning == 'primary covariates')].set_index(['outcome', 'inference'])
    mde0 = SC.loc[('dfi', 'inv_growth')].mde_exposure_only
    add('Exposure-only MDE in outcome residual SDs', mde0, f'MDE is {mde0:.2f} outcome residual')
    oi, og = prim.loc[('inv_gdp', 'CR1S')].outcome_noise, prim.loc[('inv_growth', 'CR1S')].outcome_noise
    add('Reference effect 0.01 in outcome residual SDs', (0.01 / oi, 0.01 / og), f'{0.01 / oi:.2f} outcome residual standard deviations for investment intensity and {0.01 / og:.2f} for investment growth')
    fi = (prim.loc[('inv_gdp', 'CR1S')].dependence_factor, prim.loc[('inv_gdp', 'two-way')].dependence_factor)
    fg = (prim.loc[('inv_growth', 'CR1S')].dependence_factor, prim.loc[('inv_growth', 'two-way')].dependence_factor)
    add('Dependence factors, investment intensity', fi, f'factors of {fi[0]:.1f} under province clustering and {fi[1]:.1f} under two-way')
    add('Dependence factors, investment growth', fg, f'growth are {fg[0]:.1f} and {fg[1]:.1f}')
    for o_, lab in (('inv_gdp', 'investment intensity'), ('inv_growth', 'investment growth')):
        r = prim.loc[(o_, 'CR1S')]
        add(f'Realised MDE decomposition, {lab}', r.mde_res, f'{mde0:.3f} × {r.outcome_noise:.3f} × {r.dependence_factor:.2f} = {r.mde_res:.3f} for {lab}')
    for o_, inf_, lab in (('inv_growth', 'two-way', 'investment-growth MDEs range from'), ('inv_gdp', 'CR1S', 'MDEs range from'), ('inv_gdp', 'two-way', 'and from')):
        v = MF[(MF.outcome == o_) & (MF.inference == inf_)].mde_res
        add(f'MDE range, {o_}, {inf_}', (v.min(), v.max()), f'{lab} {v.min():.3f} to {v.max():.3f}')
    below = MF[MF.mde_res < 0.02]
    add('Designs with MDE below 0.02', len(below), f'Only one design yields a value below 0.02' if len(below) == 1 else f'{len(below)} designs')
    add('MDE of that design', below.mde_res.iloc[0], f'province-clustered inference ({below.mde_res.iloc[0]:.3f})')
    add('Minimum realised MDE above 0.01', MF.mde_res.min(), 'All values exceed the reference effect of 0.01' if MF.mde_res.min() > 0.01 else 'not all above 0.01')
    ex3 = MF[MF.window.str.contains('without') & (MF.outcome == 'inv_growth') & (MF.inference == 'CR1S')].iloc[0]
    add('Inverse Herfindahl without three provinces', ex3.inv_herfindahl, f'increases from {C.loc["after controls"].inv_herfindahl:.1f} to {ex3.inv_herfindahl:.1f}')
    add('Growth MDE without three provinces', ex3.mde_res, f'MDE increases from {prim.loc[("inv_growth", "CR1S")].mde_res:.3f} to {ex3.mde_res:.3f}')
    # ---- Section 5.2: intervals, multiple testing, placebo simulations
    for lo, hi, lab in (('cr1s_lo', 'cr1s_hi', 'province clustering'), ('tw_lo', 'tw_hi', 'two-way clustering')):
        r = P.loc[g]
        add(f'Growth 95% interval in percentage points, {lab}', (100 * r[lo], 100 * r[hi]),
            f'from {"−" if r[lo] < 0 else ""}{abs(100 * r[lo]):.1f} to {100 * r[hi]:.1f} percentage points under {lab}')
    add('Minimum two-way BH q', P.bh_q_tw.min(), f'all eight Benjamini–Hochberg q-values are {math.floor(100 * P.bh_q_tw.min()) / 100:.2f} or higher')
    TW = rd('twoway_intersection_results.csv').set_index(['outcome', 'exposure'])
    add('Alternative two-way p, overall index and digitization (growth)', (TW.loc[g].tw_p_alternative, TW.loc[('inv_growth', 'dig')].tw_p_alternative),
        f'two-way p-values are {TW.loc[g].tw_p_alternative:.3f} for the overall index and {TW.loc[("inv_growth", "dig")].tw_p_alternative:.3f} for digitization')
    cv = TW.loc[('inv_growth', 'cov')]
    add('Coverage breadth two-way p, reported and alternative', (cv.tw_p_reported, cv.tw_p_alternative), f'declines from {cv.tw_p_reported:.3f} to {cv.tw_p_alternative:.3f}')
    add('Minimum alternative BH q', TW.bh_q_alternative.min(), f'remain above {math.floor(100 * TW.bh_q_alternative.min()) / 100:.2f}')
    PI = P.loc['inv_gdp']; bounds = {}
    for lab, lo, hi, df in (('province', 'cr1s_lo', 'cr1s_hi', NPROV_ := CP.prov_name.nunique() - 1), ('two-way', 'tw_lo', 'tw_hi', CP.year.nunique() - 1)):
        se = (PI[hi] - PI.coef_res) / stats.t.ppf(0.975, df); t9 = stats.t.ppf(0.95, df)
        b = np.maximum((PI.coef_res + t9 * se).abs(), (PI.coef_res - t9 * se).abs())
        bounds[lab] = (b.min(), b.max())
    add('90% interval bounds, investment intensity', bounds, f'up to {bounds["province"][0]:.3f}–{bounds["province"][1]:.3f} in absolute value under province clustering and up to {bounds["two-way"][0]:.3f}–{bounds["two-way"][1]:.3f}')
    PL = rd('placebo_size_power_2011_2019.csv'); PL0 = PL[PL.theta == 0]
    add('Placebo draws per process', int(PL0.S.iloc[0]), f'Across {int(PL0.S.iloc[0]):,} draws per process')
    add('Placebo rejection rates under the null (percent)', (100 * PL0.reject_cr1s.min(), 100 * PL0.reject_cr1s.max(), 100 * PL0.reject_twoway.min(), 100 * PL0.reject_twoway.max()),
        f'{100 * PL0.reject_cr1s.min():.1f}–{100 * PL0.reject_cr1s.max():.1f} percent of draws. Two-way-clustered tests reject it in {100 * PL0.reject_twoway.min():.1f}–{100 * PL0.reject_twoway.max():.1f} percent')
    # ---- Sections 5.3, 5.5 and 5.6
    cs = CS.loc[('without size',) + g]
    add('Without regional income size, p-values', (cs.cr1s_p, cs.tw_p), f'province-clustered p-value of {cs.cr1s_p:.3f} and a nominal two-way-clustered p-value of {cs.tw_p:.4f}')
    LP_ = SEC.loc[g + ('lead placebo',)]
    add('Lead placebo, investment growth', (LP_.coef_res, LP_.p), f'{f3(LP_.coef_res)} (p={LP_.p:.3f}) for investment growth')
    fd = CPA.fin_depth
    add('Range of financial depth', (fd.min(), fd.max()), f'financial depth ranges from {fd.min():.2f} to {fd.max():.2f}')
    # ---- Appendix A: checks of the dataset against published statistics
    YR = rd('yearbook_reconstruction.csv'); y17 = YR[YR.item == 'Investment/GDP = yearbook total FAI / GDP']
    y17 = y17[y17.year <= 2017]
    add('Investment intensity equals yearbook investment over GDP, 2011-2017', (int(y17.n_within_tol.sum()), y17.value.max()),
        f'For all {int(y17.N.sum())} province-years in 2011–2017, deposited investment intensity agrees with transcribed investment divided by GDP to within 0.0001' if (y17.n_within_tol.sum() == y17.N.sum() and y17.value.max() <= 1e-4) else 'mismatch')
    PC = rd('population_check.csv')
    p17 = PC[PC.year <= 2017].difference_points.abs()
    add('Investment growth versus yearbook per-capita growth, 2011-2017 (pp)', p17.max(), f'within {p17.max():.2f} percentage points')
    RG = rd('construction_regimes.csv').set_index('province')
    gm = pd.concat([RG.check_deposit_minus_anchor_growth_2018, RG.check_deposit_minus_anchor_growth_2019]).abs() * 100
    ok = gm[gm <= gm.sort_values().iloc[-2]]
    add('Published growth and population reproduce deposited growth, 2018-2019', (len(ok), len(gm), ok.max()),
        f'within {math.ceil(100 * ok.max()) / 100:.2f} percentage points in {len(ok)} of {len(gm)} province-years')
    add('Largest growth difference (Hainan 2018, pp)', RG.loc['Hainan'].check_deposit_minus_anchor_growth_2018 * 100,
        f'Hainan in 2018 differs by {100 * RG.loc["Hainan"].check_deposit_minus_anchor_growth_2018:.2f} percentage points')
    c19 = RG.check_2019_deposit_minus_chained.abs()
    add('2019 investment intensity reproduced (provinces)', int((c19 <= 2e-5).sum()), f'In {int((c19 <= 2e-5).sum())} of {len(c19)} provinces, the 2019 investment-intensity value can be reproduced to within 0.00002')
    hs = RG.loc['Hainan']
    add('Hainan 2018 growth: published rate and sign that reproduces the deposit', (hs.first_release_2018, hs.check_2019_deposit_minus_chained_2018_sign_reversed),
        f'entered as +{100 * abs(hs.first_release_2018):.1f}%, whereas the published rate is −{100 * abs(hs.first_release_2018):.1f}%'
        if hs.first_release_2018 < 0 and abs(hs.check_2019_deposit_minus_chained_2018_sign_reversed) <= 2e-5 else 'sign check fails')
    sz = RG.check_revised_gdp_ratio_vs_size.abs()
    add('GDP from regional income size versus GDP implied by investment intensity', int((sz <= 2e-5).sum()), f'For {int((sz <= 2e-5).sum())} provinces, GDP recovered from regional income size agrees with GDP implied by investment intensity to within 0.002%')
    NG = pd.read_csv(os.path.join(root, 'data', 'yearbook_nbs', 'national_gdp_2018.csv')).set_index('series').gdp_100m_yuan
    add('National GDP 2018, revised and preliminary', (NG['revised'], NG['preliminary']), f'divided by {NG["revised"]:,.0f} (100 million yuan)')
    add('National GDP 2018, preliminary', NG['preliminary'], f'The preliminary national total was {NG["preliminary"]:,.0f}')
    cr = CPA[CPA.year.isin([2018, 2019])]
    med = (cr.pub_inv + cr.priv_inv + cr.for_inv).div(cr.inv_gdp).groupby(cr.year).median()
    add('Median ratio of the component sum to investment intensity', tuple(med), f'median ratio to investment intensity of {med[2018]:.2f} in 2018 and {med[2019]:.2f} in 2019')
    fc = CO.loc[('deposit controls',) + i_].fiscal_corr_with_inverse_revision
    add('Correlation of the fiscal-support ratio with the GDP revision ratio', fc, f'correlation of {fc:.2f} with the ratio')
    # ---- Appendix B.2: split-panel-jackknife simulation
    SJ = rd('spj_simulation.csv'); st = SJ[SJ.process.str.startswith('stationary')]; hh = SJ[SJ.process == 'half_heterogeneity']
    add('Stationary processes: mean bias and mean correction', (st.fe_bias_res.abs().max(), st.mean_correction_res.abs().max()),
        f'mean bias of the uncorrected estimator is at most {math.ceil(1000 * st.fe_bias_res.abs().max()) / 1000:.3f} per residual SD, and the mean correction is at most {math.ceil(1000 * st.mean_correction_res.abs().max()) / 1000:.3f}')
    add('Coverage of normal 95% intervals (percent)', (100 * st.coverage95.min(), 100 * st.coverage95.max()), f'in {100 * st.coverage95.min():.0f}–{100 * st.coverage95.max():.0f} percent of draws')
    add('Stationary draws with a correction as large as observed (percent)', 100 * st.share_correction_ge_observed.max(), f'At most {100 * st.share_correction_ge_observed.max():.0f} percent of stationary draws')
    add('Different half-panel parameters: corrections exceeding the observed (percent)', (100 * hh.share_correction_ge_observed.min(), 100 * hh.share_correction_ge_observed.max()),
        f'exceed the observed ones in {100 * hh.share_correction_ge_observed.min():.0f}–{100 * hh.share_correction_ge_observed.max():.0f} percent of draws')
    # ---- Section 3.1 and Appendix A.1, A.2: index validation and the 2020 records
    WORDS = dict(enumerate('zero one two three four five six seven eight nine ten eleven twelve'.split()))
    IV = rd('index_validation.csv').set_index('comparison')
    add('Overall index agrees with the published index (retained records)', (IV.loc['overall index'].agree, IV.loc['overall index'].compared),
        f'in all {IV.loc["overall index"].agree} retained province-year records' if IV.loc['overall index'].agree == IV.loc['overall index'].compared else 'mismatch')
    add('Components agree with the published values', (IV.loc['components'].agree, IV.loc['components'].compared),
        f'match all {IV.loc["components"].agree} published values' if IV.loc['components'].agree == IV.loc['components'].compared else 'mismatch')
    py = dict(x.split(':') for x in IV.loc['components'].provinces_by_year.split('; '))
    add('Provinces covered by the component tables', py, f'all {py["2011"]} provinces in 2011–2014 and {py["2015"]} provinces in 2015')
    c20 = CPA.set_index(['prov_name', 'year']).sort_index()
    ex_vars = ['inv_gdp', 'inv_growth', 'inv_return', 'saving', 'credit', 'labor', 'size', 'vol', 'fiscal', 'sectoral',
               'pub_inv', 'priv_inv', 'for_inv', 'fin_depth', 'fin_width', 'fin_struct']   # outcomes and every control used
    dev = {v: (c20[v].xs(2020, level='year') - (2 * c20[v].xs(2019, level='year') - c20[v].xs(2018, level='year'))).dropna() for v in ex_vars}
    big = [(v, p_, x) for v, ser in dev.items() for p_, x in ser.items() if abs(x) > 5e-6]
    (bv, bp, bx), = big
    add('2020 values that differ from the linear extrapolation', (bv, bp, bx), f'{"Investment growth" if bv == "inv_growth" else bv} in {bp} differs by {100 * abs(bx):.2f} percentage points')
    P20 = rd('primary_estimates.csv'); P20 = P20[P20['sample'] == '2011-2020']
    inc = bool(((P20.cr1s_lo < 0) & (P20.cr1s_hi > 0) & (P20.tw_lo < 0) & (P20.tw_hi > 0)).all())
    add('2011-2020 panel: all eight 95% intervals include zero', inc, f'the 95% confidence intervals for all {WORDS[len(P20)]} primary estimates include zero' if inc else 'not all include zero')
    # ---- Sections 4.4, 5.3, 5.4 and Appendix B.2: counts quoted in the text
    ND = int(rd('dynamics.csv').N.iloc[0]) if 'N' in rd('dynamics.csv').columns else None
    add('Observations in models with the lead', ND, f'models with the lead use {ND} observations')
    lp = SEC.loc[g + ('leave-one-province-out',)]
    add('Leave-one-province-out refits with p < 0.05, investment growth', lp.lopo_p05, f'{int(lp.lopo_p05)} of these refits have p-values below 0.05')
    sh = PV.loc['inv_gdp'].sort_values('share_of_2011_S', ascending=False)
    add('Shares of 2011 residualised variation, Shanghai and Beijing (percent)', tuple(100 * sh.share_of_2011_S.iloc[:2]),
        f'{sh.index[0]} and {sh.index[1]} account for {100 * sh.share_of_2011_S.iloc[0]:.0f} and {100 * sh.share_of_2011_S.iloc[1]:.0f} percent')
    sn = PV.loc['inv_gdp'].sort_values('share_of_2011_N', ascending=False)
    add('Shares of the 2011 numerator, Qinghai and Guizhou (percent)', tuple(100 * sn.share_of_2011_N.iloc[:2]),
        f'{sn.index[0]} and {sn.index[1]} account for {100 * sn.share_of_2011_N.iloc[0]:.0f} and {100 * sn.share_of_2011_N.iloc[1]:.0f} percent')
    add('Ratio of raw SD to residual SD', 1 / k, f'about {1 / k:.0f} times larger')
    add('Simulation draws per process', int(SJ.R.iloc[0]), f'Each process has {int(SJ.R.iloc[0])} draws')
    # ---- Table A.1: national series and the removed 2020 record
    nat_sd = CPA.groupby('year')[['fin_depth', 'fin_width', 'fin_struct']].std(ddof=0).max().max()
    add('National series: largest within-year SD across provinces', nat_sd,
        'Financial depth, width and structure have the same value for every province within each year.' if nat_sd < 1e-12 else 'not constant')
    sys.path.insert(0, CODE_DIR)
    from analysis import load_and_clean
    raw, lg = load_and_clean(os.path.join(root, 'data', 'dataset.xlsx'))
    rem = raw.loc[lg['_mixed_index']]
    ext = 2 * c20.xs(2019, level='year').loc['Hubei'] - c20.xs(2018, level='year').loc['Hubei']
    same = all(abs(float(rem[v]) - ext[v]) < 1e-6 for v in ex_vars)
    add('Removed 2020 row: outcomes and controls equal the Hubei extrapolation', same,
        'outcome and control values that equal the linear extrapolation of Hubei’s 2018 and 2019 values' if same else 'mismatch')
    return pd.DataFrame(N, columns=['claim', 'value', 'printed'])


def manuscript_check(path, T, NUM, O=None):
    from docx import Document
    d = Document(path)
    def norm(t):   # typographic variants: thin spaces, en dashes and spacing around relational signs
        t = t.replace('\u200b', '').replace('\u00ad', '').replace('\u2009', ' ').replace('\u2004', ' ').replace('\u202f', ' ').replace('\u00a0', ' ').replace('–', '-')
        t = re.sub(r'\s*([=<>])\s*', r'\1', t)
        return re.sub(r'\s+', ' ', t).strip()
    M_NS = '{http://schemas.openxmlformats.org/officeDocument/2006/math}t'
    paras = '\n'.join(norm(p.text) for p in d.paragraphs)
    text = norm(' '.join(p.text for p in d.paragraphs) + ' ' + ' '.join(e.text or '' for e in d.element.body.iter(M_NS)))
    body = d.element.body
    from docx.table import Table
    tables = [Table(el, d) for el in body.iterchildren() if el.tag.endswith('}tbl')]
    def cells(t):
        out = []
        for r in t.rows:
            seen = None
            for c in r.cells:
                if c._tc is seen: continue
                seen = c._tc
                if norm(c.text): out.append(norm(c.text))
        return out
    doc_cells = [cells(t) for t in tables]
    text = text + ' ' + ' '.join(x for dc in doc_cells for x in dc)   # numbers may be printed in the text or in a table
    bad = 0
    for lab, (cap, hdr, rows, note) in T.items():
        want = [norm(x) for r in rows for x in flatten_row(r)]
        match = [k for k, dc in enumerate(doc_cells) if all(x in dc for x in want[:6])]
        if not match:
            print(f'Table {lab}: not found in the manuscript'); bad += 1; continue
        dc = doc_cells[match[0]]
        miss = [x for x in want if x not in dc]
        print(f'Table {lab}: {len(want) - len(miss)} of {len(want)} printed cells found' + (f'; missing {miss[:5]}' if miss else ''))
        bad += bool(miss)
        for part, txt in (('caption', cap), ('notes', note)):            # computed notes must equal the printed notes
            if norm(txt) not in paras:
                print(f'Table {lab}: {part} differ from the manuscript'); bad += 1
    for r in NUM.itertuples():
        if norm(r.printed) not in text:
            print(f'Number not found in text: {r.claim}: "{r.printed}"'); bad += 1
    print(f'Text numbers: {len(NUM) - sum(norm(p) not in text for p in NUM.printed)} of {len(NUM)} found')
    if O:
        bad += trace_numbers(d, O)
    return bad


def trace_numbers(d, O):
    """Locate every decimal number in the body text (before the references) in the computed outputs.

    A number counts as located when an output value rounds to it at the printed precision, directly or as a percentage
    (x100) or a ratio (/100). Writes manuscript_number_trace.csv with the output files that contain each number. The
    trace is a search aid: a located number can coincide with an unrelated output value, so the claims listed in
    manuscript_numbers.csv remain the primary check."""
    import glob, json
    body = []
    for p in d.paragraphs:
        if p.text.strip() == 'References':
            break
        body.append(p.text)
    toks = []
    for t in body:
        for m in re.finditer(r'(?<![\w.])[−-]?\d+\.\d+', t):
            if 'doi.org' in t[max(0, m.start() - 20):m.end() + 5]:
                continue
            toks.append((m.group(0), t[max(0, m.start() - 60):m.end() + 30]))
    pools = {}
    for f in sorted(glob.glob(os.path.join(O, '*.csv')) + glob.glob(os.path.join(O, 'manuscript_tables', '*.csv'))):
        if f.endswith('manuscript_number_trace.csv'):
            continue
        txt = open(f, encoding='utf-8').read().replace('−', '-')
        pools[os.path.relpath(f, O)] = np.array([float(x) for x in re.findall(r'-?\d+\.\d+(?:e-?\d+)?', txt)])
    def walk(o, acc):
        if isinstance(o, dict): [walk(v, acc) for v in o.values()]
        elif isinstance(o, list): [walk(v, acc) for v in o]
        elif isinstance(o, (int, float)) and not isinstance(o, bool): acc.append(float(o))
    acc = []; walk(json.load(open(os.path.join(O, 'misc_results.json'))), acc); pools['misc_results.json'] = np.array(acc)
    rows = []
    for tok, ctx in toks:
        x = float(tok.replace('−', '-')); nd = len(tok.split('.')[1]); tol = 0.5 * 10 ** -nd + 1e-12
        src = [k for k, v in pools.items() if len(v) and np.any(np.abs(np.round(np.concatenate([v, 100 * v, v / 100]), nd) - x) <= tol)]
        rows.append({'number': tok, 'context': ' '.join(ctx.split()), 'located': bool(src), 'outputs': '; '.join(src[:6])})
    tr = pd.DataFrame(rows); tr.to_csv(os.path.join(O, 'manuscript_number_trace.csv'), index=False)
    nf = int((~tr.located).sum())
    print(f'Decimal numbers in the text: {len(tr) - nf} of {len(tr)} located in the outputs (manuscript_number_trace.csv)')
    for r in tr[~tr.located].itertuples():
        print(f'  not located: {r.number}  ({r.context[:90]})')
    return nf


# <<< MANUSCRIPT LAYER


def main():
    ap = argparse.ArgumentParser(description='Reproduce the results of the article.')
    ap.add_argument('--out', default='output', help='output folder')
    ap.add_argument('--root', default=REPO, help='folder that contains data/ (default: the repository root)')
    ap.add_argument('--skip-pipeline', action='store_true', help='rebuild tables and numbers from existing outputs')
    ap.add_argument('--manuscript', default=None, help='manuscript .docx to check (needs python-docx)')
    ap.add_argument('--start-at', default=None, help='resume the pipeline at this module, keeping earlier outputs')
    a = ap.parse_args()
    out = os.path.abspath(a.out); os.makedirs(out, exist_ok=True); root = os.path.abspath(a.root)
    if not os.path.exists(os.path.join(root, 'data', 'dataset.xlsx')):
        sys.exit(f'data/dataset.xlsx not found under {root}')
    if not a.skip_pipeline:
        run_pipeline(root, out, a.start_at)
    T, FIG1 = build_tables(out)
    write_tables(T, os.path.join(out, 'manuscript_tables'))
    print(f'Tables written: {", ".join(T)} -> {os.path.join(out, "manuscript_tables")}')
    if a.skip_pipeline:   # Figure 1 is part of the pipeline; regenerate it here when the pipeline is skipped
        r = run_module('figure1', [], out)
        if r.returncode != 0: sys.exit(r.stderr[-2000:])
    print('Figure 1:', ', '.join(f for f in sorted(os.listdir(out)) if f.startswith('figure1_mde')))
    NUM = numbers(out, root); NUM.to_csv(os.path.join(out, 'manuscript_numbers.csv'), index=False)
    print(f'Text numbers recomputed: {len(NUM)} -> manuscript_numbers.csv')
    if a.manuscript:
        bad = manuscript_check(a.manuscript, T, NUM, out)
        print('Manuscript check:', 'all items found' if bad == 0 else f'{bad} item(s) need attention')
        if bad: sys.exit(1)


if __name__ == '__main__':
    main()
