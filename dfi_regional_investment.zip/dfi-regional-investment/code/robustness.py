"""Shared estimation helpers (imported by other modules, not run on its own).

  add_fe_columns   region, region-by-year and province post-2017 identifiers
  design_fe        design matrix with arbitrary categorical fixed effects
  cr2_bm           CR2 standard error with Bell-McCaffrey (Satterthwaite) degrees of freedom on the full dummy-variable
                   design (Bell & McCaffrey, 2002; Pustejovsky & Tipton, 2018); used for Table B.2
  fast_beta        fixed-effects coefficients by least squares, used in the split-panel-jackknife bootstrap
"""
import numpy as np
import pandas as pd
from scipy import stats
from analysis import design, REGION


def add_fe_columns(df):
    df = df.copy()
    df['region'] = df['prov_name'].map(REGION)
    df['ry'] = df['region'] + '_' + df['year'].astype(str)
    df['pp'] = np.where(df['year'] >= 2018, df['prov_name'] + '_post', '000_pre')
    return df


def design_fe(df, regs, fe_cols, const=True):
    """Design with arbitrary categorical fixed effects (columns of df)."""
    parts = [df[regs].astype(float)]
    for col in fe_cols:
        parts.append(pd.get_dummies(df[col].astype(str), prefix=col, drop_first=True, dtype=float))
    X = pd.concat(parts, axis=1)
    if const:
        X.insert(0, 'const', 1.0)
    from analysis import drop_collinear
    return drop_collinear(X, keep=regs)


# ---------------------------------------------------------------- CR2 / BM
def cr2_bm(df, y, regs, controls, focal):
    """CR2 on the full dummy-variable design; adjustment matrices are symmetric
    pseudo-inverse square roots of the cluster blocks of the residual maker
    (singular because province dummies are nested in clusters)."""
    X = design(df, regs + controls); Xv = X.values; yv = df[y].values.astype(float)
    XtXi = np.linalg.inv(Xv.T @ Xv); b = XtXi @ Xv.T @ yv; u = yv - Xv @ b
    M = np.eye(len(yv)) - Xv @ XtXi @ Xv.T
    g = pd.factorize(df['prov_name'].values)[0]; j = list(X.columns).index(focal)
    meat = np.zeros_like(XtXi); Gm = []
    for k in range(g.max() + 1):
        idx = np.where(g == k)[0]
        w, Q = np.linalg.eigh(M[np.ix_(idx, idx)])
        Ag = Q @ np.diag([1 / np.sqrt(x) if x > 1e-10 else 0.0 for x in w]) @ Q.T
        s = Xv[idx].T @ (Ag @ u[idx]); meat += np.outer(s, s)
        Gm.append(M[:, idx] @ (Ag @ Xv[idx] @ XtXi[:, j]))
    se = np.sqrt((XtXi @ meat @ XtXi)[j, j])
    Gm = np.column_stack(Gm); Om = Gm.T @ Gm
    df_bm = np.trace(Om) ** 2 / np.trace(Om @ Om)
    return b[j], se, df_bm, 2 * stats.t.sf(abs(b[j] / se), df_bm)


# ---------------------------------------------------------------- fast FE beta (bootstrap)
def fast_beta(df, y, regs, prov_col='pid'):
    D = [df[regs].values.astype(float), np.ones((len(df), 1)),
         pd.get_dummies(df[prov_col], drop_first=True, dtype=float).values,
         pd.get_dummies(df['year'], drop_first=True, dtype=float).values]
    X = np.hstack(D)
    b = np.linalg.lstsq(X, df[y].values.astype(float), rcond=None)[0]
    return b[:len(regs)]
