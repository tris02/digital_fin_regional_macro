"""Closure check of the scale normalisation in Sections 4.1 and 4.3 of the article.
Each exposure enters the article's formulas as D = Dz / k, where Dz is the exposure divided by its raw SD in the cleaned
2011-2020 panel and k is the baseline residual SD (province and year means removed, no controls, 2011-2020) divided by
the raw SD. With d = M_Z D (Z: primary controls, constant, province and year indicators, and for a jointly entered
component the other two components), the script checks for the 2011-2019 sample that
  (i)   d'Y/d'd equals the reported coefficient (primary_estimates.csv);
  (ii)  the CR1S standard error computed with D equals k times the CR1S standard error computed with Dz;
  (iii) (t_0.975,30 + z_0.8)/||d|| equals k (t_0.975,30 + z_0.8)/||d_z|| and the stored exposure-only MDE of the primary
        design (frontier_layers.csv, overall index only).
Usage: python scaling_check.py --data ../data/dataset.xlsx --out ../output   (after observed.py and construction.py)"""
import argparse, os
import numpy as np
import pandas as pd
from scipy import stats
from analysis import load_and_clean, cleaned_panel, standardise, design, ols_cr1s, twoway_resid_sd, PRIMARY

TZ = stats.t.ppf(0.975, 30) + stats.norm.ppf(0.8)


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--data', required=True); ap.add_argument('--out', required=True)
    a = ap.parse_args()
    d, log = load_and_clean(a.data); c = cleaned_panel(d, log); z = standardise(c, c)
    b9 = z[z.year <= 2019].reset_index(drop=True)
    P = pd.read_csv(os.path.join(a.out, 'primary_estimates.csv'))
    P = P[P['sample'] == '2011-2019'].set_index(['outcome', 'exposure'])
    L = pd.read_csv(os.path.join(a.out, 'frontier_layers.csv'))
    rows = []
    for e, others in (('dfi', []), ('cov', ['use', 'dig']), ('use', ['cov', 'dig']), ('dig', ['cov', 'use'])):
        k = twoway_resid_sd(c, e) / c[e].std(ddof=1)
        Z = design(b9, others + PRIMARY).values
        dz = b9[e].values - Z @ np.linalg.lstsq(Z, b9[e].values, rcond=None)[0]
        dk = dz / k
        for y in ('inv_gdp', 'inv_growth'):
            th = dk @ b9[y].values / (dk @ dk)
            Xz = design(b9, [e] + others + PRIMARY); Xk = Xz.copy(); Xk[e] = Xk[e] / k
            rz = ols_cr1s(b9[y], Xz, b9.prov_name); rk = ols_cr1s(b9[y], Xk, b9.prov_name)
            se_z = rz['se'][rz['cols'].index(e)]; se_k = rk['se'][rk['cols'].index(e)]
            row = dict(exposure=e, outcome=y, k=k, norm_d_raw_standardised=np.linalg.norm(dz), norm_d=np.linalg.norm(dk),
                       t_plus_z=TZ, mde_exposure_only_raw_standardised=TZ / np.linalg.norm(dz),
                       mde_exposure_only=TZ / np.linalg.norm(dk), coef_fwl=th, coef_reported=P.loc[(y, e)].coef_res,
                       se_cr1s_D=se_k, k_times_se_cr1s_Dz=k * se_z)
            if e == 'dfi':
                m = L[(L.outcome == y) & (L.window == '2011-2019 (primary)') & (L.inference == 'CR1S') & (L.conditioning == 'primary covariates')]
                row['mde_exposure_only_stored'] = m.exposure_only_mde.iloc[0] if len(m) == 1 else np.nan
            rows.append(row)
    out = pd.DataFrame(rows)
    assert (abs(out.coef_fwl - out.coef_reported) < 1e-10).all()
    assert (abs(out.se_cr1s_D - out.k_times_se_cr1s_Dz) < 1e-12).all()
    s = out.dropna(subset=['mde_exposure_only_stored'])
    assert len(s) == 2 and (abs(s.mde_exposure_only - s.mde_exposure_only_stored) < 1e-10).all()
    out.to_csv(os.path.join(a.out, 'scaling_check_results.csv'), index=False)
    pd.set_option('display.width', 250)
    print(out.round(6).to_string(index=False))


if __name__ == '__main__':
    main()
