"""Chinese-to-English province names used to read the PKU report tables."""
ZH2EN = {'北京市':'Beijing','天津市':'Tianjin','河北省':'Hebei','山西省':'Shanxi','内蒙古自治区':'Inner Mongolia',
 '辽宁省':'Liaoning','吉林省':'Jilin','黑龙江省':'Heilongjiang','上海市':'Shanghai','江苏省':'Jiangsu','浙江省':'Zhejiang',
 '安徽省':'Anhui','福建省':'Fujian','江西省':'Jiangxi','山东省':'Shandong','河南省':'Henan','湖北省':'Hubei','湖南省':'Hunan',
 '广东省':'Guangdong','广西壮族自治区':'Guangxi','海南省':'Hainan','重庆市':'Chongqing','四川省':'Sichuan','贵州省':'Guizhou',
 '云南省':'Yunnan','西藏自治区':'Tibet','陕西省':'Shaanxi','甘肃省':'Gansu','青海省':'Qinghai','宁夏回族自治区':'Ningxia',
 '新疆维吾尔自治区':'Xinjiang'}
ZH2EN.update({'内蒙古':'Inner Mongolia','广西':'Guangxi','西藏':'Tibet','宁夏':'Ningxia','新疆':'Xinjiang'})
