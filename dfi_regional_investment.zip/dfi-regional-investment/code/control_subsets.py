"""Primary 2011-2019 model with each primary control dropped in turn, and with none.
Checks how much the estimates depend on regional income volatility, whose construction is not documented.
Usage: python control_subsets.py --data ../data/dataset.xlsx --out ../output   (any time after analysis.py)"""
import argparse, os
import pandas as pd
from scipy import stats
from analysis import load_and_clean, cleaned_panel, standardise, design, twoway_resid_sd, OUTCOMES, EXPOSURES, PRIMARY, SPECS
from robustness import add_fe_columns
from observed import twoway

T30 = stats.t.ppf(0.975, 30)


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--data', required=True); ap.add_argument('--out', required=True)
    a = ap.parse_args()
    d, log = load_and_clean(a.data); c = add_fe_columns(cleaned_panel(d, log))
    z = standardise(c, c)
    ratio = {v: twoway_resid_sd(c, v) / c[v].std(ddof=1) for v in EXPOSURES}
    df = z[z.year <= 2019].reset_index(drop=True)
    sets = [('all four primary controls', PRIMARY)] + [(f'without {v}', [w for w in PRIMARY if w != v]) for v in PRIMARY] + [('no controls', [])]
    rows = []
    for y in OUTCOMES:
        for focal, regs in SPECS:
            for lab, ctl in sets:
                X = design(df, regs + ctl); j = list(X.columns).index(focal)
                b, se1, se2, dfy = twoway(df, df[y].values, X, j); k = ratio[focal]
                rows.append(dict(outcome=y, exposure=focal, controls=lab, N=len(df), coef_res=b * k,
                                 cr1s_p=2 * stats.t.sf(abs(b / se1), 30), tw_p=2 * stats.t.sf(abs(b / se2), dfy)))
    pd.DataFrame(rows).to_csv(os.path.join(a.out, 'control_subsets_estimates.csv'), index=False)


if __name__ == '__main__':
    main()
