"""Figure 1 of the article (approximate MDEs, one panel per outcome, three reference effects), saved as a 600-dpi
PNG and as vector PDF and EPS files.
Usage: python figure1.py --out ../output   (after sensitivity.py). Reads mde_frontier.csv only."""
import argparse, os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

INK, GREY, LIGHT = '#000000', '#555555', '#b0b0b0'
plt.rcParams.update({'svg.hashsalt': 'dfi-regional-investment', 'pdf.fonttype': 42, 'ps.fonttype': 42, 'font.family': 'DejaVu Sans', 'font.size': 12, 'axes.edgecolor': INK, 'axes.labelcolor': INK,
                     'xtick.color': INK, 'ytick.color': INK, 'axes.spines.top': False, 'axes.spines.right': False})


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--out', required=True); a = ap.parse_args()
    F = pd.read_csv(os.path.join(a.out, 'mde_frontier.csv'))
    order = []
    for w in ['2011-2015', '2011-2017', '2011-2019 (primary)', '2011-2020 (deposited)']:
        for cnd in ['fixed effects only', 'primary covariates', 'expanded covariates']:
            order.append((w, cnd))
    drop = [w for w in F.window.unique() if 'without' in w][0]
    order.insert(order.index(('2011-2019 (primary)', 'expanded covariates')) + 1, (drop, 'primary covariates'))
    wl = {'2011-2015': '2011–15', '2011-2017': '2011–17', '2011-2019 (primary)': '2011–19',
          '2011-2020 (deposited)': '2011–20', drop: '2011–19, −3 prov.'}
    cl = {'fixed effects only': 'none', 'primary covariates': 'primary', 'expanded covariates': 'expanded'}
    lab = lambda w, c: f'{wl[w]}: {cl[c]}'
    fig, axes = plt.subplots(2, 1, figsize=(6.6, 9.6), sharex=True)
    for ax, (y, title) in zip(axes, [('inv_growth', 'A. Investment growth'), ('inv_gdp', 'B. Investment intensity')]):
        ys = np.arange(len(order))[::-1]
        for yy, (w, cnd) in zip(ys, order):
            r = F[(F.outcome == y) & (F.window == w) & (F.conditioning == cnd)].set_index('inference')
            p, t = r.loc['CR1S', 'mde_res'], r.loc['two-way', 'mde_res']
            ax.plot([p, t], [yy, yy], color=LIGHT, lw=1.2, zorder=1)
            ax.scatter(p, yy, s=34, color=INK, zorder=3, label='Province-clustered' if yy == ys[0] else None)
            ax.scatter(t, yy, s=34, marker='s', facecolor='white', edgecolor=GREY, lw=1.4, zorder=3,
                       label='Two-way-clustered' if yy == ys[0] else None)
        for v, ls in ((0.005, ':'), (0.01, '--'), (0.02, '-.')):
            ax.axvline(v, color=INK, lw=1.2, ls=ls, zorder=2)
        ax.set_yticks(ys); ax.set_yticklabels([lab(w, c) for w, c in order], fontsize=12)
        ax.set_ylim(-0.7, len(order) - 0.3)
        ax.set_title(title, fontsize=13, color=INK, loc='left', pad=6)
        ax.set_xlim(0, 0.115); ax.tick_params(direction='out')
    from matplotlib.lines import Line2D
    h, l = axes[0].get_legend_handles_labels()
    for v, ls in ((0.005, ':'), (0.01, '--'), (0.02, '-.')):
        h.append(Line2D([0], [0], color=INK, lw=1.2, ls=ls)); l.append(f'Reference {v:g}')
    leg = fig.legend(h, l, loc='upper center', ncol=2, fontsize=10.5, frameon=True, fancybox=False, edgecolor=INK, framealpha=1,
                     bbox_to_anchor=(0.5, 0.995))
    leg.get_frame().set_linewidth(0.8)
    fig.supxlabel('Approximate MDE per baseline residual SD of the index', fontsize=11.5, x=0.5)
    fig.tight_layout(rect=(0, 0, 1, 0.925))
    for ext, kw in (('png', dict(dpi=600)), ('pdf', dict(metadata={'CreationDate': None})), ('eps', dict(metadata={'CreationDate': None}))):
        fig.savefig(os.path.join(a.out, f'figure1_mde.{ext}'), **kw)
    plt.close(fig)


if __name__ == '__main__':
    main()
