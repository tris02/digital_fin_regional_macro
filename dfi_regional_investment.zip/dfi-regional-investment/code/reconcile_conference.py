"""Reconciliation of the article's component estimates with the specification of the earlier conference
paper (article Section 5.6 and Table 5).

Step 0 recomputes the conference estimates from the deposited dataset with the data handling and model of the
conference estimation code (a Jupyter notebook, cells 1-3 with the variable lists of cell 7):
  - every column converted to numbers with invalid entries set to missing, then every row with a missing value dropped.
    This drops Beijing 2011, whose fiscal-support cell holds a malformed string, and keeps both 2020 records labelled
    Hubei, one of which carries Hebei's index values (article Table A.1). N = 309.
  - the three components, financial depth, financial width, financial structure and regional income size, ten further
    controls, and the twelve component-by-moderator interactions with uncentred moderators.
  - province and year fixed effects (the national moderators are absorbed by the year effects).
The conference code estimated this model with linearmodels PanelOLS and entity-clustered standard errors. That
convention scales the cluster-robust covariance by N/(N-K) and uses t(N-K) reference values. The script stores those
p-values (conference_convention_p) next to the CR1S values with t(30) used everywhere else in the article, and reports
the gap between the two. No estimate of the conference paper is read from a file: all values are computed here.

Each later step changes one feature, ending at the article's primary specification (Table 2, joint columns):
  1 Beijing 2011 restored (fiscal value parsed as in Table A.1), 2 mixed 2020 record removed (the documented cleaning),
  3 moderators centred at their 2011-2020 means, 4 interactions removed, 5 the four primary controls, 6 sample
  2011-2019, 7 rescaled to one baseline residual SD. Coefficients are on the deposited index scale (index/100) until
  step 7. The script also records that the three financial moderators are national annual series.
Usage: python reconcile_conference.py --data ../data/dataset.xlsx --out ../output   (after observed.py)."""
import argparse, os
import numpy as np
import pandas as pd
from scipy import stats
from analysis import load_and_clean, cleaned_panel, design, ols_cr1s, twoway_resid_sd, PRIMARY, RENAME

COMP = ['cov', 'use', 'dig']
CTRL11 = ['inv_return', 'saving', 'credit', 'labor', 'vol', 'fiscal', 'sectoral', 'pub_inv', 'priv_inv', 'for_inv', 'size']
MODS = ['fin_depth', 'fin_width', 'fin_struct', 'size']


def conference_frame(path):
    """The estimation sample of the conference code: numeric coercion of every column, then rows with any missing value
    dropped (pandas to_numeric(errors='coerce') followed by DataFrame.dropna())."""
    d = pd.read_excel(path).rename(columns=RENAME)
    for col in d.columns:
        if col != 'prov_name':
            d[col] = pd.to_numeric(d[col], errors='coerce')
    return d.dropna().sort_values(['prov_name', 'year'], kind='stable').reset_index(drop=True)


def fit(df, y, controls, inter, centre=None):
    df = df.copy(); regs = list(COMP)
    if inter:
        for a in COMP:
            for m in MODS:
                mv = df[m] - (centre[m] if centre is not None else 0.0)
                df[f'{a}_x_{m}'] = df[a] * mv; regs.append(f'{a}_x_{m}')
    X = design(df, regs + [v for v in controls if v not in regs])
    r = ols_cr1s(df[y], X, df.prov_name)
    N, G, K = r['N'], r['G'], r['r']
    # linearmodels clustered convention: covariance x N/(N-K) instead of the CR1S factor G/(G-1) x (N-1)/(N-K); t(N-K)
    conv = np.sqrt(N * (G - 1) / (G * (N - 1)))
    out = {}
    for a in COMP:
        j = r['cols'].index(a); se_c = r['se'][j] * conv
        out[a] = (r['b'][j], r['p'][j], r['se'][j], 2 * stats.t.sf(abs(r['b'][j] / se_c), N - K), N - K)
    return out, len(df)


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--data', required=True); ap.add_argument('--out', required=True)
    a = ap.parse_args()
    d, log = load_and_clean(a.data); c = cleaned_panel(d, log)
    conf = conference_frame(a.data)
    raw = d.sort_values(['prov_name', 'year']).reset_index(drop=True)          # all deposited records, fiscal value parsed
    lost = sorted(set(map(tuple, raw[['prov_name', 'year']].values)) - set(map(tuple, conf[['prov_name', 'year']].values)))
    assert len(raw) - len(conf) == len(lost) == len(log['malformed_fiscal'])   # only the malformed record is lost
    nat = {m: float(c.groupby('year')[m].std().max()) for m in ('fin_depth', 'fin_width', 'fin_struct')}
    c9 = c[c.year <= 2019].reset_index(drop=True)
    mean20 = {m: c[m].mean() for m in MODS}
    steps = [
        (f'0 Conference code specification: {len(conf)} records (malformed record dropped, mixed 2020 record kept), '
         f'{len(CTRL11)} controls, {len(COMP) * len(MODS)} interactions, two-way FE', conf, CTRL11, True, None),
        (f'1 Malformed fiscal value parsed and its record restored ({len(raw)} records)', raw, CTRL11, True, None),
        (f'2 Mixed 2020 record removed: documented cleaning ({len(c)} records)', c, CTRL11, True, None),
        ('3 Moderators centred at their 2011-2020 means (same model, components evaluated at mean moderators)', c, CTRL11, True, mean20),
        ('4 Interactions removed', c, CTRL11, False, None),
        ('5 Four primary controls only', c, PRIMARY, False, None),
        (f'6 Primary sample 2011-2019 (N={len(c9)})', c9, PRIMARY, False, None),
    ]
    rows = []
    for y in ('inv_growth', 'inv_gdp'):
        for lab, df, ctrl, inter, cen in steps:
            est, n = fit(df, y, ctrl, inter, cen)
            for comp in COMP:
                rows.append(dict(outcome=y, step=lab, N=n, exposure=comp, coef_index_scale=est[comp][0], cr1s_p=est[comp][1],
                                 cr1s_se_index_scale=est[comp][2], conference_convention_p=est[comp][3],
                                 conference_convention_df=est[comp][4]))
        # step 7: rescale step 6 to baseline residual SD units and compare with the article's Table 2
        P = pd.read_csv(os.path.join(a.out, 'primary_estimates.csv')); P = P[P['sample'] == '2011-2019']
        for comp in COMP:
            b6 = [r for r in rows if r['outcome'] == y and r['step'].startswith('6') and r['exposure'] == comp][0]
            k = twoway_resid_sd(c, comp)
            t2 = P[(P.outcome == y) & (P.exposure == comp)].iloc[0]
            assert abs(b6['coef_index_scale'] * k - t2.coef_res) < 1e-10, (y, comp)
            rows.append(dict(outcome=y, step='7 Rescaled to one baseline residual SD (article Table 2)', N=len(c9), exposure=comp,
                             coef_res=t2.coef_res, cr1s_p=t2.cr1s_p, tw_p=t2.tw_p, cr1s_se_res=b6['cr1s_se_index_scale'] * k))
    out = pd.DataFrame(rows)
    out.to_csv(os.path.join(a.out, 'conference_reconciliation.csv'), index=False)
    pd.set_option('display.width', 200)
    print('records dropped by the conference code:', lost)
    print(out.round(4).to_string())
    print(nat)


if __name__ == '__main__':
    main()
