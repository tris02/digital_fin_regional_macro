"""Direct standard errors for the remaining rows of article Tables 3 and 4: the dynamic models of dynamics.csv
(current value only, lead-current-lag jointly, change in the index, level and change together) and the alternative
construction of two GDP-based controls in alternative_controls.csv. The designs repeat construction.py (section 7) and
construction_checks.py (section 6). The script stores the CR1S standard error from the estimation routine and checks
each coefficient and p-value against the stored output and each standard error against recovered_se.csv.
Usage: python direct_se_dynamic.py --data ../data/dataset.xlsx --nbs ../data/yearbook_nbs --out ../output
(after construction.py, construction_checks.py and se_recovery.py)."""
import argparse, os
import pandas as pd
from analysis import load_and_clean, cleaned_panel, standardise, design, ols_cr1s, twoway_resid_sd, OUTCOMES, EXPOSURES, PRIMARY
from construction import regimes, load_official, load_population, load_national_gdp_2018


def main():
    ap = argparse.ArgumentParser()
    for k in ('data', 'nbs', 'out'):
        ap.add_argument('--' + k, required=True)
    a = ap.parse_args()
    dd, log = load_and_clean(a.data); c = cleaned_panel(dd, log)
    z = standardise(c, c)
    ratio = {v: twoway_resid_sd(c, v) / c[v].std(ddof=1) for v in EXPOSURES}
    R = []
    add = lambda src, y, ex, row, N, b, se, p: R.append(dict(source=src, outcome=y, exposure=ex, row=row, N=N,
                                                             coef_res=b, se_res=se, cr1s_p=p))
    # dynamics (construction.py, section 7)
    zz = z.sort_values(['prov_name', 'year']).reset_index(drop=True)
    for ex in EXPOSURES:
        zz[ex + '_lead'] = zz.groupby('prov_name')[ex].shift(-1)
        zz[ex + '_lag'] = zz.groupby('prov_name')[ex].shift(1)
        zz[ex + '_d'] = zz[ex] - zz[ex + '_lag']
    w = zz[(zz.year >= 2012) & (zz.year <= 2019)].dropna(subset=[e_ + s_ for e_ in EXPOSURES for s_ in ('_lead', '_lag')]).reset_index(drop=True)
    for y in OUTCOMES:
        for ex in ('dfi', 'dig'):
            others = [] if ex == 'dfi' else ['cov', 'use']
            k = ratio[ex]
            X = design(w, [ex] + others + PRIMARY); r = ols_cr1s(w[y], X, w.prov_name); j = list(X.columns).index(ex)
            add('dynamics', y, ex, 'current only, same sample: current', len(w), r['b'][j] * k, r['se'][j] * k, r['p'][j])
            regs = [ex + '_lead', ex, ex + '_lag'] + [o + s_ for o in others for s_ in ('_lead', '', '_lag')]
            X = design(w, regs + PRIMARY); r = ols_cr1s(w[y], X, w.prov_name)
            for nm, v in (('lead', ex + '_lead'), ('current', ex), ('lag', ex + '_lag')):
                j = list(X.columns).index(v)
                add('dynamics', y, ex, f'lead, current and lag jointly: {nm}', len(w), r['b'][j] * k, r['se'][j] * k, r['p'][j])
            kdd = twoway_resid_sd(w, ex + '_d')
            X = design(w, [ex + '_d'] + [o + '_d' for o in others] + PRIMARY); r = ols_cr1s(w[y], X, w.prov_name)
            j = list(X.columns).index(ex + '_d')
            add('dynamics', y, ex, 'change in the index (per residual SD of the change): current', len(w),
                r['b'][j] * kdd, r['se'][j] * kdd, r['p'][j])
            X = design(w, [ex] + others + [ex + '_d'] + [o + '_d' for o in others] + PRIMARY); r = ols_cr1s(w[y], X, w.prov_name)
            jl = list(X.columns).index(ex); jd = list(X.columns).index(ex + '_d')
            add('dynamics', y, ex, 'level and change together: current', len(w), r['b'][jl] * k, r['se'][jl] * k, r['p'][jl])
            add('dynamics', y, ex, 'level and change together: change', len(w), r['b'][jd] * kdd, r['se'][jd] * kdd, r['p'][jd])
    # alternative construction of two GDP-based controls (construction_checks.py, section 6)
    F, G, Rr, = load_official(a.nbs)
    N = load_population(a.nbs)
    nat_pre, nat_rev = load_national_gdp_2018(a.nbs)
    rr = regimes(c, F, G, Rr, N, nat_rev).set_index('province')
    rv = c.prov_name.map(rr.revision_ratio_2018); post = c.year.isin([2018, 2019])
    cb = c.copy()
    cb.loc[post, 'size'] = c.loc[post, 'size'] / rv[post] * (nat_rev / nat_pre)
    cb.loc[post, 'fiscal'] = c.loc[post, 'fiscal'] * rv[post]
    w9 = standardise(cb, c); w9 = w9[w9.year <= 2019].reset_index(drop=True)
    for y in OUTCOMES:
        for focal, regs in (('dfi', ['dfi']), ('dig', ['cov', 'use', 'dig'])):
            X = design(w9, regs + PRIMARY); r = ols_cr1s(w9[y], X, w9.prov_name); j = list(X.columns).index(focal); k = ratio[focal]
            add('alternative_controls', y, focal, 'size and fiscal support on pre-census vintage', len(w9), r['b'][j] * k, r['se'][j] * k, r['p'][j])
    R = pd.DataFrame(R)
    DY = pd.read_csv(os.path.join(a.out, 'dynamics.csv')); CO = pd.read_csv(os.path.join(a.out, 'alternative_controls.csv'))
    REC = pd.read_csv(os.path.join(a.out, 'recovered_se.csv'))
    gb, gp, gs = [], [], []
    for _, r in R.iterrows():
        if r.source == 'dynamics':
            model, col = r.row.rsplit(': ', 1)
            s = DY[(DY.outcome == r.outcome) & (DY.exposure == r.exposure) & (DY.model == model)].iloc[0]
            b0, p0 = s[col], s[col + '_p']
        else:
            s = CO[(CO.outcome == r.outcome) & (CO.exposure == r.exposure) & (CO.controls == r.row)].iloc[0]
            b0, p0 = s.theta_deposit, s.deposit_p
        rec = REC[(REC.source == r.source) & (REC.outcome == r.outcome) & (REC.exposure == r.exposure) & (REC.row == r.row)]
        gb.append(abs(r.coef_res - b0)); gp.append(abs(r.cr1s_p - p0)); gs.append(abs(r.se_res - rec.iloc[0].se_res))
    R['abs_diff_coef_vs_stored'] = gb; R['abs_diff_p_vs_stored'] = gp; R['abs_diff_se_vs_recovered'] = gs
    R.to_csv(os.path.join(a.out, 'direct_se_dynamic_rows.csv'), index=False)
    print(f'rows {len(R)}; max |coef diff| {max(gb):.1e}; max |p diff| {max(gp):.1e}; max |SE direct - recovered| {max(gs):.1e}')


if __name__ == '__main__':
    main()
