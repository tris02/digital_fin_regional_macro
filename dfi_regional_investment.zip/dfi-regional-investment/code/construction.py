"""Construction checks of the 2018-2019 research variables, the dynamic specifications and the information layers of
Figure 1 (article Appendices A.3-A.4, Sections 4.3, 5.1 and 5.5, Tables 3, 4, A2, A3 and B1).

Outputs:
  construction_regimes.csv          province-level comparison of the dataset's 2018-2019 investment intensity, regional income
                                 size and growth with values built from the yearbook tables (Appendix A.3, Table A.2): the
                                 2017 investment level chained with published growth, GDP of the series used for 2011-2017
                                 (2018 printed in CSY2019; 2019 scaled by the 2018 ratio of the two series), and growth per
                                 head of official year-end population
  construction_bounds.csv  primary estimates with the 2018-2019 outcomes replaced by these alternatives (one row per
                                 outcome and exposure; Tables 3, A3 and B1)
  dynamics.csv         lead, current and lag of the index jointly with Wald tests, the change in the index, and
                                 level and change together, 2012-2019 (Table 4)
  frontier_layers.csv  exposure-only MDE, outcome residual SD and dependence factor for the designs of Figure 1
The module also provides load_official, load_population, regimes and Problem (the fixed-design coefficient h'Y with its
CR1S and two-way standard errors as quadratic forms in Y) to other modules.
Usage:  python construction.py --data ../data/dataset.xlsx --nbs ../data/yearbook_nbs --out ../output   (after sensitivity.py)
"""
import argparse, os
import numpy as np
import pandas as pd
from scipy import stats
from analysis import (load_and_clean, cleaned_panel, standardise, design, ols_cr1s, twoway_resid_sd,
                      OUTCOMES, EXPOSURES, PRIMARY)
from observed import twoway
from sensitivity import fwl

T30 = stats.t.ppf(0.975, 30)


def load_official(nbs):
    F = pd.read_csv(os.path.join(nbs, 'fai_total_2010_2017.csv')).pivot(index='province', columns='year', values='fai_total_100m_yuan')
    G = pd.read_csv(os.path.join(nbs, 'gdp_2011_2019.csv')).pivot(index='province', columns='year', values='gdp_100m_yuan')
    R = pd.read_csv(os.path.join(nbs, 'fai_growth_first_release_2018_2020.csv')).pivot(index='province', columns='year', values='fai_growth_pct') / 100
    return F, G, R


def load_national_gdp_2018(nbs):
    """National GDP for 2018 (100 million yuan): the preliminary and the revised value published by the NBS
    (yearbook_nbs/national_gdp_2018.csv; see provenance.md). Returns (preliminary, revised)."""
    n = pd.read_csv(os.path.join(nbs, 'national_gdp_2018.csv')).set_index('series').gdp_100m_yuan.astype(float)
    return n['preliminary'], n['revised']


def load_population(nbs):
    """Official year-end population (10,000 persons): 2010-2013 from CSY2014 table 2-5 (.xls, decimals) and 2014-2019
    from CSY2020 table 2-6 (image, integers). 2013 agrees between the two sources after rounding."""
    a = pd.read_csv(os.path.join(nbs, 'population_2010_2013.csv'))
    b = pd.read_csv(os.path.join(nbs, 'population_2013_2019.csv'))
    b = b[b.year >= 2014]
    return pd.concat([a, b]).pivot(index='province', columns='year', values='pop_10k')


def regimes(c, F, G, R, N, nat_rev):
    A = c.pivot(index='prov_name', columns='year', values='inv_gdp')
    AG = c.pivot(index='prov_name', columns='year', values='inv_growth')
    CS = (c.pub_inv + c.priv_inv + c.for_inv).groupby([c.prov_name, c.year]).sum().unstack()
    N18 = F[2017] * (1 + R[2018]); N19 = N18 * (1 + R[2019])
    # The dataset's 2018 regional income size is provincial GDP over the revised national total nat_rev (NBS), so
    # size x nat_rev recovers the provincial 2018 GDP that the dataset uses. The check below confirms this.
    # Check: the 2017 level chained with first-release growth, divided by the deposited ratio, gives the same value except
    # where the deposit used its own 2018 growth rate (Hainan).
    SZ = c.pivot(index='prov_name', columns='year', values='size')
    gdp18_rev = SZ[2018] * nat_rev
    own = (AG[2018] - R[2018]).abs() > 0.05
    impl = N18 / A[2018]
    out = pd.DataFrame({'deposit_inv_gdp_2018': A[2018], 'deposit_inv_gdp_2019': A[2019],
                        'chained_fai_2018': N18, 'chained_fai_2019': N19,
                        'gdp_2018_precensus': G[2018], 'gdp_2018_revised_implied': gdp18_rev, 'gdp_2019_revised': G[2019]})
    out['revision_ratio_2018'] = out.gdp_2018_revised_implied / out.gdp_2018_precensus
    out['deposit_numerator_own_growth_2018'] = own.astype(int)
    out['gdp_2018_revised_from_ratio'] = impl
    out['check_revised_gdp_ratio_vs_size'] = impl / gdp18_rev - 1
    chk = out.check_revised_gdp_ratio_vs_size[~own].abs()
    assert chk.max() < 1e-4, f'regional income size does not match the revised national GDP: {chk.max():.2e}'
    out['check_2019_deposit_minus_chained'] = A[2019] - N19 / G[2019]
    # the same 2019 calculation with the sign of the first-release 2018 growth rate reversed (Appendix A.3, Hainan)
    out['check_2019_deposit_minus_chained_2018_sign_reversed'] = A[2019] - F[2017] * (1 - R[2018]) * (1 + R[2019]) / G[2019]
    out['anchor_inv_gdp_2018'] = N18 / G[2018]
    out['anchor_inv_gdp_2019'] = N19 / (G[2019] / out.revision_ratio_2018)       # 2019 GDP on the series used for 2011-2017
    for y in (2018, 2019):
        out[f'vintage_error_{y}'] = out[f'deposit_inv_gdp_{y}'] - out[f'anchor_inv_gdp_{y}']
        out[f'component_sum_over_anchor_{y}'] = CS[y] / out[f'anchor_inv_gdp_{y}']
    tg = F.pct_change(axis=1)
    gap = ((1 + tg.loc[:, 2011:2017]) / (1 + AG.loc[:, 2011:2017]) - 1)          # implied population growth, 2011-2017
    out['pop_growth_implied_2011_2017'] = gap.mean(axis=1)
    out['pop_growth_within_sd'] = gap.std(axis=1, ddof=1)
    for y in (2018, 2019):
        out[f'deposit_growth_{y}'] = AG[y]
        out[f'first_release_{y}'] = R[y]
        out[f'anchor_growth_popimplied_{y}'] = (1 + R[y]) / (1 + out.pop_growth_implied_2011_2017) - 1
        if N is not None:
            n_ = N[y] / N[y - 1] - 1
            out[f'pop_growth_official_{y}'] = n_
            out[f'anchor_growth_{y}'] = (1 + R[y]) / (1 + n_) - 1
            out[f'check_deposit_minus_anchor_growth_{y}'] = AG[y] - out[f'anchor_growth_{y}']
        else:
            out[f'anchor_growth_{y}'] = out[f'anchor_growth_popimplied_{y}']
    out.index.name = 'province'
    return out.reset_index()


class Problem:
    """Fixed design: theta = h'Y; CR1S and two-way standard errors as quadratic forms in Y."""
    def __init__(self, df, y, focal, regs, k):
        self.df = df; self.k = k
        self.X, self.j, self.d = fwl(df, y, focal, regs, PRIMARY)
        Xv = self.X.values.astype(float); N, K = Xv.shape
        XtXi = np.linalg.inv(Xv.T @ Xv)
        self.h = XtXi[self.j] @ Xv.T
        M = np.eye(N) - Xv @ XtXi @ Xv.T
        gp = pd.factorize(df.prov_name)[0]; gy = pd.factorize(df.year)[0]
        G, Gy = gp.max() + 1, gy.max() + 1
        Dp = np.zeros((G, N)); Dp[gp, np.arange(N)] = 1; Dy = np.zeros((Gy, N)); Dy[gy, np.arange(N)] = 1
        self.Ap = (Dp * self.h) @ M; self.Ay = (Dy * self.h) @ M; self.Apy = self.h[:, None] * M
        self.fp = G / (G - 1) * (N - 1) / (N - K); self.fy = Gy / (Gy - 1) * (N - 1) / (N - K)
        self.dfy = Gy - 1
        self.provs = sorted(df.prov_name.unique())
        self.idx = {(p, t): n for n, (p, t) in enumerate(zip(df.prov_name, df.year))}

    def theta(self, Y):
        return self.h @ Y

    def se(self, Y):
        vp = self.fp * np.sum((self.Ap @ Y) ** 2); vy = self.fy * np.sum((self.Ay @ Y) ** 2); vpy = np.sum((self.Apy @ Y) ** 2)
        return np.sqrt(vp), np.sqrt(max(vp + vy - vpy, 1e-300))


def anchor_Y(P, Y0, reg, outcome):
    """Centre of the admissible set on the consistent definition (x = 1, s = 1; m = 1/(1+n), r = 0)."""
    r = reg.set_index('province').reindex(P.provs); Y = Y0.copy()
    for i, p in enumerate(P.provs):
        for t in (2018, 2019):
            Y[P.idx[(p, t)]] = r[f'anchor_inv_gdp_{t}'].iloc[i] if outcome == 'inv_gdp' else r[f'anchor_growth_{t}'].iloc[i]
    return Y


def main():
    ap = argparse.ArgumentParser()
    for k in ('data', 'nbs', 'out'):
        ap.add_argument('--' + k, required=True)
    a = ap.parse_args()
    dd, log = load_and_clean(a.data); c = cleaned_panel(dd, log)
    z = standardise(c, c)
    ratio = {v: twoway_resid_sd(c, v) / c[v].std(ddof=1) for v in EXPOSURES}
    b9 = z[z.year <= 2019].reset_index(drop=True)
    F, G, R = load_official(a.nbs); N = load_population(a.nbs)

    # 1. measurement regimes
    reg = regimes(c, F, G, R, N, load_national_gdp_2018(a.nbs)[1])
    reg.to_csv(os.path.join(a.out, 'construction_regimes.csv'), index=False)

    # 2. primary estimates with the alternative 2018-2019 outcomes
    IDS = []
    for y in OUTCOMES:
        for focal, regs in [('dfi', ['dfi']), ('dig', ['cov', 'use', 'dig'])]:
            P = Problem(b9, y, focal, regs, ratio[focal]); k = ratio[focal]
            Ya = b9[y].values.astype(float)
            b_chk, s1_chk, s2_chk, _ = twoway(b9, Ya, P.X, P.j)
            s1a, s2a = P.se(Ya)
            assert abs(b_chk - P.theta(Ya)) < 1e-10 and abs(s1_chk - s1a) < 1e-10 and abs(s2_chk - s2a) < 1e-10
            Yc = anchor_Y(P, Ya, reg, y); s1c, s2c = P.se(Yc); thc = P.theta(Yc)
            IDS.append(dict(outcome=y, exposure=focal, theta_deposit=P.theta(Ya) * k,
                            deposit_cr1s_p=2 * stats.t.sf(abs(P.theta(Ya) / s1a), 30),
                            theta_anchor=thc * k, anchor_cr1s_lo=(thc - T30 * s1c) * k, anchor_cr1s_hi=(thc + T30 * s1c) * k,
                            anchor_cr1s_p=2 * stats.t.sf(abs(thc / s1c), 30), anchor_tw_p=2 * stats.t.sf(abs(thc / s2c), P.dfy),
                            realised_shift_deposit_minus_anchor=(P.theta(Ya) - thc) * k,
                            realised_rms_deposit_minus_anchor=np.sqrt(np.mean((Ya - Yc) ** 2))))
    pd.DataFrame(IDS).to_csv(os.path.join(a.out, 'construction_bounds.csv'), index=False)

    # 3. dynamics: lead, current and lag jointly; the change in the index
    zz = z.sort_values(['prov_name', 'year']).reset_index(drop=True)
    for ex in EXPOSURES:
        zz[ex + '_lead'] = zz.groupby('prov_name')[ex].shift(-1)      # the 2020 index values are observed
        zz[ex + '_lag'] = zz.groupby('prov_name')[ex].shift(1)
        zz[ex + '_d'] = zz[ex] - zz[ex + '_lag']
    w = zz[(zz.year >= 2012) & (zz.year <= 2019)].dropna(subset=[e_ + s_ for e_ in EXPOSURES for s_ in ('_lead', '_lag')]).reset_index(drop=True)
    DY = []
    for y in OUTCOMES:
        for ex in ('dfi', 'dig'):
            others = [] if ex == 'dfi' else ['cov', 'use']
            k = ratio[ex]
            X = design(w, [ex] + others + PRIMARY); r = ols_cr1s(w[y], X, w.prov_name); jc = list(X.columns).index(ex)
            DY.append(dict(outcome=y, exposure=ex, model='current only, same sample', N=len(w), current=r['b'][jc] * k, current_p=r['p'][jc]))
            regs = [ex + '_lead', ex, ex + '_lag'] + [o + s_ for o in others for s_ in ('_lead', '', '_lag')]
            X = design(w, regs + PRIMARY); r = ols_cr1s(w[y], X, w.prov_name)
            jj = [list(X.columns).index(v) for v in (ex + '_lead', ex, ex + '_lag')]
            Xv = X.values.astype(float); g = pd.factorize(w.prov_name)[0]; Gn = g.max() + 1
            Sm = np.zeros((Gn, Xv.shape[1])); np.add.at(Sm, g, Xv * r['u'][:, None])
            V = r['XtXi'] @ (Sm.T @ Sm) @ r['XtXi'] * (Gn / (Gn - 1)) * ((len(w) - 1) / (len(w) - Xv.shape[1]))
            bb = r['b'][jj]; VV = V[np.ix_(jj, jj)]

            def wald(Rm):
                Rm = np.atleast_2d(np.asarray(Rm, float)); q = Rm.shape[0]; v_ = Rm @ bb
                Fst = float(v_ @ np.linalg.solve(Rm @ VV @ Rm.T, v_)) / q
                return Fst, stats.f.sf(Fst, q, Gn - 1)
            Fall, pall = wald(np.eye(3)); _, ple = wald([[1, -1, 0]]); _, psum = wald([[1, 1, 1]])
            corr = np.corrcoef(np.column_stack([w[ex + '_lead'], w[ex], w[ex + '_lag']]).T)
            DY.append(dict(outcome=y, exposure=ex, model='lead, current and lag jointly', N=len(w),
                           lead=bb[0] * k, lead_p=r['p'][jj[0]], current=bb[1] * k, current_p=r['p'][jj[1]],
                           lag=bb[2] * k, lag_p=r['p'][jj[2]], sum_coef=bb.sum() * k, sum_p=psum,
                           joint_F=Fall, joint_p=pall, lead_equals_current_p=ple,
                           raw_corr_lead_current=corr[0, 1], raw_corr_current_lag=corr[1, 2]))
            kdd = twoway_resid_sd(w, ex + '_d')
            X = design(w, [ex + '_d'] + [o + '_d' for o in others] + PRIMARY); r = ols_cr1s(w[y], X, w.prov_name)
            jd = list(X.columns).index(ex + '_d')
            DY.append(dict(outcome=y, exposure=ex, model='change in the index (per residual SD of the change)', N=len(w),
                           current=r['b'][jd] * kdd, current_p=r['p'][jd]))
            X = design(w, [ex] + others + [ex + '_d'] + [o + '_d' for o in others] + PRIMARY)
            r = ols_cr1s(w[y], X, w.prov_name); jl = list(X.columns).index(ex); jd = list(X.columns).index(ex + '_d')
            DY.append(dict(outcome=y, exposure=ex, model='level and change together', N=len(w),
                           current=r['b'][jl] * k, current_p=r['p'][jl], change=r['b'][jd] * kdd, change_p=r['p'][jd]))
    pd.DataFrame(DY).to_csv(os.path.join(a.out, 'dynamics.csv'), index=False)

    # 4. information layers of the frontier
    FR = pd.read_csv(os.path.join(a.out, 'mde_frontier.csv'))
    FR['exposure_only_mde'] = FR.mde_res / (FR.dependence_factor * FR.outcome_noise)   # per outcome residual SD, independent errors
    FR[['outcome', 'window', 'conditioning', 'inference', 'N', 'inv_herfindahl', 'exposure_only_mde',
        'outcome_noise', 'dependence_factor', 'mde_res']].to_csv(os.path.join(a.out, 'frontier_layers.csv'), index=False)


if __name__ == '__main__':
    main()
