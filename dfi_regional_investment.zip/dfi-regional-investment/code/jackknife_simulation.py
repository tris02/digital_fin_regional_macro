"""Calibrated simulation of the split-panel jackknife in the lagged-outcome model (2012-2019, overall index).
The exercise is assumption-dependent. It keeps the observed exposure, controls, initial outcomes (2011), fitted fixed
effects and residual blocks of the observed panel, and it generates outcomes under three processes:
  stationary_null   : common persistence (jackknife estimate), index coefficient 0;
  stationary        : common persistence and index coefficient (both set to the jackknife estimates);
  half_heterogeneity: persistence and index coefficient set to the half-panel estimates (2012-2015, 2016-2019).
For each draw it records the uncorrected fixed-effects estimate, the split-panel-jackknife estimate (halves 2012-2015 and
2016-2019), the correction (jackknife minus uncorrected), the gap between the half-panel index coefficients (second minus
first), the gap between the half-panel persistence coefficients (first minus second), and the province-cluster bootstrap SE of the jackknife estimate (B draws), and it checks whether the normal
95 percent interval built from that SE covers the reference value. In the heterogeneity process, the reference value is
the mean of the two half-specific coefficients.
Shares: the share of draws whose correction or gap is at least as large as the observed value.
Limitations: parameters are time-invariant within the stationary processes, but the paths start from the observed 2011
outcomes and use the fixed effects and control coefficients of the uncorrected fit, so they do not start in a steady state.
Errors: each province receives the 8-year residual block of a randomly drawn province, multiplied by a Rademacher sign.
Residual blocks are assigned independently across provinces, so cross-province dependence is not reproduced.
The panel is balanced, so two-way fixed effects are removed by two-way demeaning.
Usage: python jackknife_simulation.py --data ../data/dataset.xlsx --out ../output [--R 500 --B 199]"""
import argparse, os
import numpy as np
import pandas as pd
from analysis import load_and_clean, cleaned_panel, standardise, twoway_resid_sd, PRIMARY

YEARS = list(range(2012, 2020))


def dm(a):
    """Two-way demeaning of a (provinces x years [x k]) array."""
    return a - a.mean(axis=0, keepdims=True) - a.mean(axis=1, keepdims=True) + a.mean(axis=(0, 1), keepdims=True)


def beta(Y, Z):
    """Y: (n, T); Z: (n, T, k). Two-way FE OLS on a balanced panel."""
    y = dm(Y).ravel(); X = dm(Z).reshape(-1, Z.shape[2])
    return np.linalg.lstsq(X, y, rcond=None)[0]


def spj(Y, Z):
    full = beta(Y, Z)
    h1 = beta(Y[:, :4], Z[:, :4]); h2 = beta(Y[:, 4:], Z[:, 4:])
    return full, 2 * full - 0.5 * (h1 + h2), h1, h2


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--data', required=True); ap.add_argument('--out', required=True)
    ap.add_argument('--R', type=int, default=500); ap.add_argument('--B', type=int, default=199)
    ap.add_argument('--seed', type=int, default=20261015)
    a = ap.parse_args(); rng = np.random.default_rng(a.seed)
    d, log = load_and_clean(a.data); c = cleaned_panel(d, log)
    z = standardise(c, c); k = twoway_resid_sd(c, 'dfi') / c['dfi'].std(ddof=1)
    b9 = z[z.year <= 2019].sort_values(['prov_name', 'year'])
    provs = sorted(b9.prov_name.unique()); n = len(provs)
    piv = lambda v, yrs: b9.pivot(index='prov_name', columns='year', values=v).loc[provs, yrs].values
    out = []
    for yv in ('inv_gdp', 'inv_growth'):
        Yall = piv(yv, [2011] + YEARS); Y = Yall[:, 1:]; Ylag = Yall[:, :-1]
        Xd = np.stack([piv('dfi', YEARS)] + [piv(v, YEARS) for v in PRIMARY], axis=2)
        assert not np.isnan(Yall).any() and not np.isnan(Xd).any()
        Z = np.concatenate([Xd, Ylag[:, :, None]], axis=2)            # columns: dfi, 4 controls, ylag
        bf = beta(Y, Z)
        # fitted fixed-effect component and residual blocks of the observed lagged-outcome model
        lin = Z @ bf; res_fe = Y - lin
        U = dm(res_fe)                                                 # residuals after two-way FE
        mu = res_fe - U                                                # alpha_i + lambda_t
        gam = bf[1:5]
        _, bc, _, _ = spj(Y, Z)
        h1 = beta(Y[:, :4], Z[:, :4]); h2 = beta(Y[:, 4:], Z[:, 4:])
        th_full, rho_full = bc[0], bc[5]
        procs = {
            'stationary_null': (np.full(8, rho_full), np.zeros(8)),
            'stationary': (np.full(8, rho_full), np.full(8, th_full)),
            'half_heterogeneity': (np.r_[np.full(4, h1[5]), np.full(4, h2[5])], np.r_[np.full(4, h1[0]), np.full(4, h2[0])]),
        }
        for name, (rho_t, th_t) in procs.items():
            ref = th_t.mean()
            obs_corr = (bc[0] - bf[0]); obs_gap = h2[0] - h1[0]; obs_rgap = h1[5] - h2[5]
            fe_e, sp_e, se_e, cov, gap_e, rgap_e = [], [], [], [], [], []
            for _ in range(a.R):
                pick = rng.integers(0, n, n); sgn = rng.choice([-1.0, 1.0], n)[:, None]
                e = U[pick] * sgn
                ys = np.empty((n, 9)); ys[:, 0] = Yall[:, 0]
                for t in range(8):
                    ys[:, t + 1] = rho_t[t] * ys[:, t] + th_t[t] * Xd[:, t, 0] + Xd[:, t, 1:] @ gam + mu[:, t] + e[:, t]
                Ys = ys[:, 1:]; Zs = np.concatenate([Xd, ys[:, :-1, None]], axis=2)
                f_, s_, a1, a2 = spj(Ys, Zs)
                gap_e.append(a2[0] - a1[0]); rgap_e.append(a1[5] - a2[5])
                bd = np.empty(a.B)
                for b in range(a.B):
                    pb = rng.integers(0, n, n)
                    bd[b] = spj(Ys[pb], Zs[pb])[1][0]
                se = bd.std(ddof=1)
                fe_e.append(f_[0]); sp_e.append(s_[0]); se_e.append(se)
                cov.append(abs(s_[0] - ref) <= 1.959964 * se)
            fe_e, sp_e, se_e, gap_e, rgap_e = map(np.array, (fe_e, sp_e, se_e, gap_e, rgap_e))
            corr_e = sp_e - fe_e
            out.append(dict(outcome=yv, process=name, R=a.R, B=a.B,
                            rho_half1=rho_t[0], rho_half2=rho_t[-1],
                            theta_half1_res=th_t[0] * k, theta_half2_res=th_t[-1] * k, reference_res=ref * k,
                            fe_mean_res=fe_e.mean() * k, spj_mean_res=sp_e.mean() * k,
                            mean_correction_res=(sp_e.mean() - fe_e.mean()) * k,
                            fe_bias_res=(fe_e.mean() - ref) * k, spj_bias_res=(sp_e.mean() - ref) * k,
                            fe_rmse_res=np.sqrt(((fe_e - ref) ** 2).mean()) * k,
                            spj_rmse_res=np.sqrt(((sp_e - ref) ** 2).mean()) * k,
                            spj_sd_res=sp_e.std(ddof=1) * k, mean_boot_se_res=se_e.mean() * k,
                            observed_correction_res=obs_corr * k, share_correction_ge_observed=np.mean(corr_e >= obs_corr),
                            observed_index_gap_res=obs_gap * k, share_index_gap_ge_observed=np.mean(gap_e >= obs_gap),
                            observed_persistence_gap=obs_rgap, share_persistence_gap_ge_observed=np.mean(rgap_e >= obs_rgap),
                            coverage95=np.mean(cov), mcse_coverage=np.sqrt(np.mean(cov) * (1 - np.mean(cov)) / a.R)))
    pd.DataFrame(out).to_csv(os.path.join(a.out, 'spj_simulation.csv'), index=False)


if __name__ == '__main__':
    main()
