"""Information frontier for Figure 1 (article Section 5.1, Figure 1; output mde_frontier.csv).

For the overall index and each outcome, window (2011-2015, 2011-2017, 2011-2019,
deposited 2011-2020), conditioning set (fixed effects only, primary, expanded) and inference procedure (CR1S, two-way),
the script reports the approximate minimum detectable effect (80 percent power, two-sided 5 percent test) per baseline
residual SD, its dependence factor (clustered over conventional standard error), the outcome residual SD and the
concentration of the residualised exposure; it repeats the primary design after removing the three provinces with the
largest shares of the residualised exposure variation. It also provides fwl (the Frisch-Waugh-Lovell residualised
exposure) to other modules.
Usage:  python sensitivity.py --data ../data/dataset.xlsx --out ../output
"""
import argparse, os
import numpy as np
import pandas as pd
from scipy import stats
from analysis import load_and_clean, cleaned_panel, standardise, design, ols_cr1s, twoway_resid_sd, OUTCOMES, EXPOSURES, PRIMARY, EXPANDED
from observed import twoway

T30 = stats.t.ppf(0.975, 30); TZ = T30 + stats.norm.ppf(0.80)
SESOI = 0.01


def fwl(df, y, focal, regs, controls):
    X = design(df, regs + controls); j = list(X.columns).index(focal)
    others = X.drop(columns=[focal]).values.astype(float)
    xf = X[focal].values.astype(float)
    d = xf - others @ np.linalg.lstsq(others, xf, rcond=None)[0]
    return X, j, d


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--data', required=True); ap.add_argument('--out', required=True)
    a = ap.parse_args()
    dd, log = load_and_clean(a.data); c = cleaned_panel(dd, log)
    z = standardise(c, c)
    ratio = {v: twoway_resid_sd(c, v) / c[v].std(ddof=1) for v in EXPOSURES}
    b9 = z[z.year <= 2019].reset_index(drop=True)

    # information frontier for the overall index
    FR = []
    windows = [('2011-2015', z[z.year <= 2015]), ('2011-2017', z[z.year <= 2017]), ('2011-2019 (primary)', b9),
               ('2011-2020 (deposited)', z)]
    for y in OUTCOMES:
        sdy = c[y].std(ddof=1)
        for wl, wdf in windows:
            wdf = wdf.reset_index(drop=True)
            for cl, ctr in (('fixed effects only', []), ('primary covariates', PRIMARY), ('expanded covariates', EXPANDED)):
                X, j, d = fwl(wdf, y, 'dfi', ['dfi'], ctr)
                b, se1, se2, dfy = twoway(wdf, wdf[y].values, X, j)
                r = ols_cr1s(wdf[y], X, wdf.prov_name)
                naive = np.sqrt(np.sum(r['u'] ** 2) / (len(d) - X.shape[1]) / (d @ d))
                sh = pd.Series(d ** 2).groupby(wdf.prov_name.values).sum(); sh = sh / sh.sum()
                for inf, se, crit in (('CR1S', se1, TZ), ('two-way', se2, stats.t.ppf(.975, dfy) + stats.norm.ppf(.8))):
                    mde = crit * se * ratio['dfi']
                    FR.append(dict(outcome=y, window=wl, conditioning=cl, inference=inf, N=len(d),
                                   exposure_sd_ratio=np.std(d) / c['dfi'].std(ddof=1),
                                   inv_herfindahl=1 / np.sum(sh ** 2), top3_share=sh.sort_values(ascending=False).iloc[:3].sum(),
                                   dependence_factor=se / naive, outcome_noise=np.sqrt(np.sum(r['u'] ** 2) / (len(d) - X.shape[1])),
                                   mde_res=mde, mde_outcome_sd=crit * se / sdy, F=SESOI / mde))
            if wl.startswith('2011-2019'):
                X, j, d = fwl(wdf, y, 'dfi', ['dfi'], PRIMARY)
                sh = pd.Series(d ** 2).groupby(wdf.prov_name.values).sum().sort_values(ascending=False)
                drop = list(sh.index[:3]); wd = wdf[~wdf.prov_name.isin(drop)].reset_index(drop=True)
                X2, j2, d2 = fwl(wd, y, 'dfi', ['dfi'], PRIMARY)
                b, se1, se2, dfy = twoway(wd, wd[y].values, X2, j2)
                r = ols_cr1s(wd[y], X2, wd.prov_name)
                naive = np.sqrt(np.sum(r['u'] ** 2) / (len(d2) - X2.shape[1]) / (d2 @ d2))
                sh2 = pd.Series(d2 ** 2).groupby(wd.prov_name.values).sum(); sh2 = sh2 / sh2.sum()
                for inf, se, crit in (('CR1S', se1, stats.t.ppf(.975, wd.prov_name.nunique() - 1) + stats.norm.ppf(.8)),
                                      ('two-way', se2, stats.t.ppf(.975, dfy) + stats.norm.ppf(.8))):
                    mde = crit * se * ratio['dfi']
                    FR.append(dict(outcome=y, window=wl + ', without ' + ', '.join(drop), conditioning='primary covariates',
                                   inference=inf, N=len(d2), exposure_sd_ratio=np.std(d2) / c['dfi'].std(ddof=1),
                                   inv_herfindahl=1 / np.sum(sh2 ** 2), top3_share=sh2.sort_values(ascending=False).iloc[:3].sum(),
                                   dependence_factor=se / naive, outcome_noise=np.sqrt(np.sum(r['u'] ** 2) / (len(d2) - X2.shape[1])),
                                   mde_res=mde, mde_outcome_sd=crit * se / sdy, F=SESOI / mde))
    pd.DataFrame(FR).to_csv(os.path.join(a.out, 'mde_frontier.csv'), index=False)


if __name__ == '__main__':
    main()
