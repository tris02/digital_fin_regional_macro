"""Year-level decomposition of the partial-regression coefficient (overall index, 2011-2019).
theta = sum_t N_t / sum_t S_t, with N_t = sum_i d_it y_it and S_t = sum_i d_it^2, where d is the overall index after
partialling out the primary controls, a constant and the province and year indicators on the full 2011-2019 sample.
For each year the script reports the share of S (exposure variation), the share of N (exposure-outcome covariance),
the within-year slope N_t/S_t, the coefficient with that year's terms removed from N and S holding d fixed, and the
refit coefficient with that year dropped and d re-estimated (as in leave_one_year.csv).
Coefficients are rescaled to baseline residual SD units.
Usage: python influence_2011.py --data ../data/dataset.xlsx --out ../output"""
import argparse, os
import numpy as np
import pandas as pd
from analysis import load_and_clean, cleaned_panel, standardise, design, twoway_resid_sd, PRIMARY


def theta(df, y):
    Z = design(df, PRIMARY).values
    D = df['dfi'].values
    d = D - Z @ np.linalg.lstsq(Z, D, rcond=None)[0]
    return d, d @ df[y].values / (d @ d)


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--data', required=True); ap.add_argument('--out', required=True)
    a = ap.parse_args()
    d0, log = load_and_clean(a.data); c = cleaned_panel(d0, log); z = standardise(c, c)
    k = twoway_resid_sd(c, 'dfi') / c['dfi'].std(ddof=1)
    b9 = z[z.year <= 2019].reset_index(drop=True)
    rows = []
    for y in ('inv_gdp', 'inv_growth'):
        d, th = theta(b9, y)
        Y = b9[y].values; yrs = b9.year.values
        N = d * Y; S = d * d
        for t in range(2011, 2020):
            m = yrs == t
            Nt, St = N[m].sum(), S[m].sum()
            hold = (N.sum() - Nt) / (S.sum() - St)
            _, refit = theta(b9[b9.year != t].reset_index(drop=True), y)
            rows.append(dict(outcome=y, year=t, theta_full_res=th * k, share_S=St / S.sum(), share_N=Nt / N.sum(),
                             within_year_slope_res=Nt / St * k, theta_without_year_d_fixed_res=hold * k,
                             theta_refit_without_year_res=refit * k))
    pd.DataFrame(rows).to_csv(os.path.join(a.out, 'year_influence.csv'), index=False)


if __name__ == '__main__':
    main()
